## 1 COMMIT Unreleased 2026-10-31T10:31:45-07:00

#### Coming From:

Unreleased cc1ce48

#### Purpose:

Open TinyGBA by vendoring nand2mario's GBATang GBA core into the open flow for the Tang Console 138K, get it through synthesis and place-and-route, and build the instruments the first hardware session will need.

#### Outcome:

The repository now carries GBATang at commit `77fd0714a426ada76aee612f1192c704e89762e4`, fetched as the `gbatang` submodule of nand2mario's `tangcore` and vendored verbatim into `fpga/gba/src/` except for the files marked `TinyGBA:` in place; `fpga/gba/tinygba.cst` is GBATang's `src/boards/console138k.cst` with the four clock placements added, and `fpga/gba/tinygba.sdc` re-derives the clock plan for a parser with no `create_generated_clock`. `tools/build_tinygba.sh` is the flow: yosys 0.69+260 with `read_slang --std 1800-2017 --single-unit`, the cell libraries passed both as `-v` and as `--blackboxed-module`, `synth_gowin -family gw5a`, `nextpnr-himbaechel` for `GW5AST-LV138PG484AC1/I0`, an Fmax gate and `gowin_pack`. Getting the design through slang took nine documented changes: the two vendor-style `` `error `` directives became comments; the uninitialised parameters in `gba_dma_module.sv` and `gba_sound_ch1.v` were given inert defaults, every instantiation overriding them; `kbd_data` in `iosys_bl616.v` became a local reg because it was declared `input reg` and assigned procedurally; three mixed blocking and non-blocking assignments and one block-scoped register initialiser were made consistent in `gba2hdmi.sv`, `hdmi.sv`, `packet_picker.sv` and `sdram_gba.v`. `fpga/gba/src/hdmi/` was replaced with TinyTang's copy of hdl-util's transmitter, which already carries those same open-flow fixes and has run on this board, exactly as TinySNES did. `pll_74` was replaced by a hand-written single-output 371.25 MHz `gowin_pll_hdmi.v` with a `CLKDIV` divider making the pixel clock, and both cells are pinned, because the two-output wrapper is the arrangement that produced no picture at all on three TinySNES images. Two findings were worth the cycle on their own. `read_slang` compiles each file as its own unit unless `--single-unit` is passed, so the board defines in `console138k.v` never reached the design and the build silently dropped both USB HID hosts, the 12 MHz PLL and `linebuffer.v`'s M138K block-RAM path. And GBATang's generated IP instantiates 2307 `MUX2` cells and 38 bare `LUT5` cells, which this device cannot place: `tools/cells_behavioral.v` defines both behaviourally and the build shim strips the library copies, so they synthesise to LUT4s. USB HID was then disabled in `console138k.v`, matching TinySNES's own board configuration, which removed a clock domain and two `usb_hid_host` instances and dropped hold violations at seed 1 from 54 to 7. Synthesis passes at 27,888 LUT4 of 138,240, 121 BSRAM, 3 PLL. Place and route does not: hold violations on `clk16` persist at every seed tried. On the initial netlist seeds 1 to 16 gave 54, 15, 17, 43, 25, 19, 14, 11 and 18 among them, and on the USB-less netlist seeds 1 to 8 gave 7, 16, 22, 31, 21, 34, 5 and 22, so no placement is clean and seed 7 at 5 is the best. Post-route Fmax passes everywhere it was read, `clk16` at 18.10 to 18.68 MHz against 16.75, `hclk` at 74.79 to 82.67 against 74.25, `clk50` at 76.15 and `clk67` at 119.80, so the failure is hold and not setup. Every violation has the same shape: about -5 to -6 ns of `clk16` clock skew arriving at a `mem.mem_bios` BSRAM `CLKA` pin, with 2381 `clk16` sinks falling back from dedicated clock routing to general routing, and only two nets in the design routed on global resources. `NPNR_GOWIN_CLK_FIRST=clk16`, the arch's own clock-first knob that TinyNES uses for `bus_clk`, was tried on three seeds and changed neither the skew nor the count, which matches TinySNES's note that it does not take. There is no `BUFG` primitive in the GW5A cell library, so global promotion cannot be forced from RTL. No bitstream exists and nothing was deployed. Separately the SDRAM question was scoped: the module advertises 64 MiB with two W9825G6KH-6 dies while the 40-pin header brings out 38 conductors, which is one die's worth, and GBATang's controller selects between two dies by driving that single CS wire from address bit 25 on every activate, read and write and refreshing each die in turn. `fpga/gba/diag/sdram_probe.v` tests that by writing patterns to the low die, their complements to the high die, and re-reading the low die, so an absent second die cannot pass. `fpga/gba/diag/tb_sdram_probe.sv` drives it against two models under `tools/run_diag_sim.sh` and both directions pass, all sixteen patterns correct against GBATang's 64 MiB `sdram_sim` and eight green followed by eight red against a model whose die select does nothing. Two defects in the probe were found by that testbench rather than by inspection: the transfer counter was conflated with the word index, so the high die was never addressed at all, and the model checked `cpu_addr[23]` where the controller uses `cpu_addr[25]`. `gba2hdmi.sv` and `gbatang_top.sv` carry the diagnostic readout, a colour-bar video proof under `TINYGBA_VIDEO_TEST` and sixteen probe bars under `TINYGBA_SDRAM_TEST`, and all three configurations synthesise, 65 MB production, 61 MB video and 58 MB SDRAM. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and that `.ai/core-reference.md` remains empty rather than being filled with unverified records, and validated this entry as entry 1 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of one against the 100-entry limit.

#### Next Steps:

Clear the hold violations on `clk16`, which is the single blocker between this tree and a bitstream, and do it by understanding the clock distribution rather than by sweeping more seeds, since twenty-four placements have now failed and the best is five violations; the shape to investigate is that 2381 `clk16` sinks take general routing while only two nets in the design get global resources, so the question is which nets nextpnr promotes and whether the four `INS_LOC` PLL sites inherited from TinyNES and TinyTang suit a design whose main clock fans out across the whole die, and the alternative if promotion cannot be influenced is to reduce `clk16`'s fanout by moving the BIOS block RAM or splitting the domain. Then produce two bitstreams and put them on the Tang in this order: `TINYGBA_VIDEO_TEST`, which draws colour bars from `gba2hdmi`'s own raster on `clk50` and therefore tests the PLL and divider topology, the four clock placements, the OSER10 path and the TMDS pair without depending on `clk16` at all, and then `TINYGBA_SDRAM_TEST`, whose sixteen bars answer whether the second 32 MiB die is reachable. A black screen on the first means the video path is wrong and says nothing about the machine. Only after both does the machine itself matter, and RAM, timer and save behaviour are all unverified. Do not reintroduce USB HID without measuring its effect on the clock domains, and do not carry the GPU's `MUX2` and `LUT5` instances back into the build expecting them to place.

#### Files Modified:

- .gitignore
- THIRD_PARTY.md
- fpga/gba/LICENSE-GBATANG-GPL-3.0
- fpga/gba/tinygba.cst
- fpga/gba/tinygba.sdc
- fpga/gba/src/
- fpga/gba/diag/sdram_probe.v
- fpga/gba/diag/tb_sdram_probe.sv
- tools/build_tinygba.sh
- tools/cells_behavioral.v
- tools/fs_to_bin.py
- tools/run_diag_sim.sh
- tools/sweep_tinygba_seeds.sh

#### Status:

- Build: FAIL
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 2 COMMIT Unreleased 2026-10-31T13:00:16-07:00

#### Coming From:

Unreleased 2478ca3

#### Purpose:

Clear the clk16 hold violations that stood between this tree and a bitstream, and produce the production, video-proof and SDRAM-probe images for a first hardware session without deploying any of them.

#### Outcome:

The `clk16` blocker is understood and gone. A PLL output reaches the global clock spine only through a clock-plane wire, `T[LR]PLL<n>CLK<lane>`, and the GW5AST-138C database carries 24 of those wires but only two pips that drive one, both from `CLKOUT0`: `MPLLCLKOUT0 -> TLPLL0CLK0` on the left-edge PLL sites and `MPLLCLKOUT0 -> TRPLL0CLK0` on the right-edge ones. `CLKOUT1` through `CLKOUT6` connect no further than the tile-local `F1..F6` and `CLK1`/`CLK2` lanes, so a clock on a secondary PLL output is a dead end whatever the placer is told to do. `clk16` sat on `pll33`'s `CLKOUT1`, reached none of its 2381 sinks on global resources, and nextpnr fell back to 2381 point-to-point arcs whose skew, -5.38 ns at worst into `mem_bios`'s BSRAM `CLKA`, failed hold on all 24 placements tried. That also explains why `NPNR_GOWIN_CLK_FIRST` changed nothing: priority was never the constraint. Three fixes were tried in a scratch copy before any of this was written to the tree. Dividing by one in a `CLKDIV` to move the net onto an HCLK lane failed, because `CLKDIV_O10` has no path to a spine either. A real `BUFG`, declared as a blackbox so synthesis would keep it, placed but the global router answered "no clock gate reaches both its source and its loads". A spare PLL on `PLL_R[2]` with `CLKOUT0` also failed, because that site's only plane wire is `TRPLL0CLK0` and `clk50` already holds it. What works is giving `clk16` its own PLL, `pll16`, on `PLL_L[0]`, the site whose `CLKOUT0` owns the free `TLPLL0CLK0` wire; `pll33`'s `CLKOUT1` is left unused. A six-seed sweep of the fixed netlist gave zero `clk16` hold violations at every seed, against a previous best of five at seed 7 out of twenty-four placements. Seeds 2 and 6 failed on `clk67` instead, at -1.18 ns of skew from `CLKOUT2`'s 255 failed dedicated routes, which is the same class of defect as `clk16` had but milder; it is recorded as an open limitation because it does not block a bitstream at a clean seed. Two further defects were found on the way. `pll_74` had been removed without reconnecting its 371.25 MHz output, leaving `clk_5x_pixel` undeclared in `gba2hdmi.sv`, so the three `OSER10` serialisers had both `FCLK` and `Q` unconnected and the video-proof image would have drawn a black screen; TinySNES's TCL-006 records this exact failure and the same `X181Y102/FCLKA` route error, and the fix is the shape it documents, a `clk_pixel_x5` input fed from `hclk5`. Separately, `pll_27.v` and `pll_33.v` set their parameters with `defparam`, and because `PLL` is a blackbox every string parameter arrived at the packer as raw ASCII, `FCLKIN` `"27"` showing up as `0x3237` and `CLKOUT0_EN` `"TRUE"` as its four bytes, so both files were converted to `#(...)` parameter style. Producing a bitstream then needed an oracle run, because `pll_33` runs at `FVCO` 1809 MHz (27 x 67) and apicula's charge-pump model covers only 650 to 1300 MHz and refuses to extrapolate. Gowin EDA 1.9.11.03 was made to run headless here, overriding a bundled `libfreetype` that clashes with system `libfontconfig`, and a minimal project reproducing `pll_33`'s operating point was built; the vendor warns `PA1019` and builds anyway, exactly as it did for TinyNES's three above-band points. Its bitstream gives `FLDCOUNT` 16, `A_ICP_SEL` 240, `A_LPF_RES_SEL` R4 and `KVCO` 7, where the ladder would have answered R5 with 137, which continues the above-band pattern already documented for the other three points. A search had already shown the plan admits no in-band alternative: `clk16`, `clk50` and `clk67` all carry the prime 67, so a common `FVCO` must be a multiple of 201, and the only `Fpfd` values inside the measured band are 27, 25 and 50, all coprime to 67, so no configuration is simultaneously in band for `Fpfd` and `FVCO`. The measured point was added to the apicula fork and the packed bitstream was then verified by unpacking it and reading every PLL's derived attributes back: `pll16` and `pll33` both give 16/240/R4, matching the vendor exactly, and `pll27` and `pll_hdmi` still give 190/R4 with `FLDCOUNT` 32 and 16, so the parameter conversion did not disturb the two points that were already measured. Three images were built from the committed tree at seed 1, all with zero hold violations, `clk16` on global resources and every clock passing the timing gate: production `tinygba.bin` SHA-256 `4c88b84cbc4f146be7ede6f50ec2a04d9547345fcb96ee84ed79d13fec23b1f3` with `clk16` 19.57 against 16.75, `clk50` 118.65 against 50.25, `clk67` 111.47 against 67.00 and `hclk` 96.02 against 74.25; `TINYGBA_VIDEO_TEST` SHA-256 `03123f45432358f23e9edc0ca8cff4f0cad9f5a1422349f7dc323427382883f5`; and `TINYGBA_SDRAM_TEST` SHA-256 `c278fa212f32fe3600c934b14cbd1c7fbfcf376e8e3d982f1b30cac3bd09c36a`. Nothing was deployed and the Tang was not connected to, at the user's instruction, and no hardware result exists. The syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, and validated this entry as entry 2 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of two against the 100-entry limit.

#### Next Steps:

Load the three images in the order the diagnostics were designed for and keep the Tang connection behind the user's permission: `TINYGBA_VIDEO_TEST` first, which should draw eight vertical bars with a white top-left marker and a red right edge and tests the PLL and divider topology, the clock placements, the OSER10 path and the TMDS pair without depending on `clk16` or the machine, so a black screen means the video path is wrong and says nothing about the GBA; then `TINYGBA_SDRAM_TEST`, whose sixteen bars answer whether the second 32 MiB die is reachable, eight green followed by eight red meaning it is not; and only then production `tinygba.bin`, where RAM, timer and save behaviour are all unverified and the BIOS block RAM, SDRAM capture and the GPU have never run on hardware in this port. `clk67`'s -1.18 ns of skew on seeds 2 and 6 is the next routing defect of the same kind `clk16` had and should be settled by understanding `CLKOUT2`'s missing plane pip rather than by sweeping seeds, since seed 1 is clean only by placement luck; the fix is likely to move `clk67` onto a `CLKOUT0` of its own once the two free right-edge sites are understood. Do not reintroduce USB HID without measuring its effect on the clock domains, and do not carry the GPU's `MUX2` and `LUT5` instances back into the build expecting them to place.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/pll/pll_16.v
- fpga/gba/src/pll/pll_27.v
- fpga/gba/src/pll/pll_33.v
- fpga/gba/tinygba.cst
- fpga/gba/tinygba.sdc
- tools/build_tinygba.sh

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 3 COMMIT Unreleased 2026-10-31T16:07:43-07:00

#### Coming From:

Unreleased 5b67502

#### Purpose:

Put the first TinyGBA images on the Tang in one-wire mode and read what the hardware actually does, so the video path, the SDRAM and the machine are each answered from the board rather than from the build.

#### Outcome:

The video path works and the machine does not run. The first load was the `TINYGBA_VIDEO_TEST` image, and it produced a locked 720p picture on the bench's capture card with a correct letterbox, which by itself proves the PLL and divider topology, the four `INS_LOC` placements, the `OSER10` serialiser path and both TMDS pairs -- none of which had ever run on this board in this port. What it did not show was the test bars: the active area came back uniformly black at exactly 960 pixels wide, from x=160 to x=1119. That width is `XSTART_O`..`XSTOP_O`, gba2hdmi's overlay window rather than its 1080-wide video window, and the cause is `iosys_bl616.v`'s `reg overlay_reg = 1;`: the OSD overlay powers up asserted and is only cleared by command 0x08 with x[0]=0, which the BL616 menu sends and nothing sends in one-wire mode. The overlay was covering the framebuffer with an empty menu's black, so the test pattern had almost certainly been written correctly the whole time and was simply underneath it. The diagnostic builds now tie `overlay` low through two nested `ifdef`s rather than one `||`, because TinySNES records that slang does not evaluate `elsif A || B` as written, and a third define `TINYGBA_OVERLAY_OFF` suppresses it in an otherwise production build for bench work; production keeps the OSD, since the menu is real functionality on the console and the BL616 closes it in normal use. Reloaded with the overlay off, the bars appeared in the right order with the correct colours -- red, green, blue, white, yellow, cyan, magenta, then grey -- over a 1080-pixel active area centred in the letterbox, full height, with the white 16x16 marker measuring 72 by 72 pixels at the top-left corner, exactly 16 source pixels at the 4.5 scale this mode uses. One anomaly in that picture is the instrument's own: a 104-pixel red band at the right edge where grey should continue, which is `reg [2:0] bar; bar = x / 8'd27;` truncating bar 8 to bar 0 for source x 216 to 239, and 23 source pixels is 104 display pixels to the pixel. That defect is in the diagnostic pattern and not in the core, and it is left recorded rather than quietly fixed so the next reader does not mistake it for a video fault. The `TINYGBA_SDRAM_TEST` image answered worse: the status band read green, so the probe reached `done`, but only patterns 0 and 1 of sixteen read back correctly, bars 0 and 1 green and bars 2 through 15 red, with the low die failing five of its own eight patterns and the high die failing all eight. The probe drives `cpu_be` as 4'b1111 and writes full 32-bit words, so a narrow write is not the explanation, and the pattern set -- walking ones in the low byte, then 0x00010000, 0x10000000, and four multi-bit patterns -- cannot localise which bits fail: the honest statement is that bits 0 and 4 read back and every other pattern tested does not, so the data path is badly broken and a bit-level test is needed before the fault can be named. The production image showed a 960-pixel black window, which is the overlay again and is expected in the shipping configuration on a bench with no menu driving it; a build of the same tree with only `TINYGBA_OVERLAY_OFF` added ran to a 1080-pixel active area that was uniformly black, so the machine itself draws nothing and cannot be said to boot. That is consistent with the SDRAM result, since the GBA's work RAM and cartridge space live there and only the BIOS is in block RAM. `clk67` is the likely connective tissue and the reason this cycle could not get further: the SDRAM clock still misses dedicated routing on all 255 of its sinks, and unlike `clk16` it cannot be moved onto its own clock-plane wire, because the GW5AST-138C database carries exactly two such wires, `TLPLL0CLK0` and `TRPLL0CLK0`, and `clk16` and `clk50` now hold both. Every one of this cycle's placement failures was that same `clk67` hold defect at -1.2 to -1.9 ns and none was `clk16`; the netlist change from the overlay fix moved the clean seeds, so the video image was built at seed 5 with seven of eight seeds clean, and production and the SDRAM probe at seed 2. A stale `build/prod/tinygba.bin` survived the failed seed-1 rebuild and would have deployed the pre-fix image had it been loaded by directory name, so the deploy set was staged under `build/deploy` from explicitly named clean-seed directories with a `SHA256SUMS` file, and the PLL fuses were read back out of the exact production image before loading to confirm 16/240/R4 at 1809 MHz. All three images loaded with `openFPGALoader -b tangconsole` from oss-cad-suite, which is the one-wire path, and the results were read from the capture card as sequences of frames rather than single grabs, because the first frame after a load is usually black while the card has not yet locked. No user test was run: the machine never produced a picture, so there was nothing for the user to accept. The syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, and validated this entry as entry 3 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of three against the 100-entry limit.

#### Next Steps:

The next cycle should settle `clk67` before anything else, because it is the common cause of both remaining faults: the SDRAM reads back almost nothing and the machine never draws, and the SDRAM clock is the one clock in the design that still reaches its 255 sinks on general routing with 1.2 to 1.9 ns of skew. The two clock-plane wires are spent, so the options are to measure whether `CLKOUT2` can reach a spine at all by the oracle method this cycle used for the FVCO point, or to stop giving `clk67` a PLL output and derive the SDRAM clock in the fabric where its skew is at least visible, or to reduce its fanout so general routing carries it with less skew; an oracle bitstream with the SDRAM clock on `CLKOUT0` of a spare site would answer the first in one step. Only after that does the SDRAM itself mean anything: rerun the probe with a pattern set that walks every data bit individually and every address bit, so a failure names a lane instead of a bar, and check `cpu_be` and DQM handling against the 38-conductor header finding already recorded, since this module advertises two 32 MiB dies on a bus that brings out one die's worth. The GBA machine, the BIOS block RAM, timers, saves and the GPU are all still unverified and cannot be judged until SDRAM works. Two smaller items: fix the `reg [2:0] bar` truncation in the video pattern so the right-hand band is grey as documented, and decide whether the shipping configuration should clear the OSD itself rather than depend on the BL616, since a core that shows a black 960-pixel window until a menu command arrives looks broken to anyone who loads it standalone.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---

## 4 COMMIT Unreleased 2026-10-31T17:18:15-07:00

#### Coming From:

Unreleased e4e9859

#### Purpose:

Settle `clk67`, the one clock still reaching its sinks on general routing and the likeliest cause of both the failed SDRAM readback and the absent machine picture, by measuring what a PLL's second output can reach rather than by sweeping more seeds.

#### Outcome:

`clk67` is fixed, and the fix was a missing database entry rather than a design compromise. The question was whether a PLL's `CLKOUT2` can reach the clock plane at all, since apicula's database carried only two pips into the 24-wire plane and both came from `CLKOUT0`. Two vendor builds answered it. The first enabled `CLKOUT0` and `CLKOUT2` on a `PLL` at `PLL_L[0]`, each clocking a fourteen-bit register bank so both had to be clock-routed, and the unpacked bitstream showed `(54,93) SPINE8 <= TLPLL0CLK0` and `(54,93) SPINE10 <= TLPLL0CLK2` in the same build. The second was the control: `CLKOUT0` disabled and only `CLKOUT2` enabled, which still produced `SPINE8 <= TLPLL0CLK2` driving 48 `GB00` sinks. So `CLKOUT2` does reach the plane, on lane 2, and the lane number follows the output number. apicula simply had no pip to say so, which is why `clk67` fell back to general routing on all 255 of its sinks with 1.2 to 1.9 ns of skew and cost several clean seeds on every netlist change. The pip was added to `_gw5a_pll_clk_wires` as `(0, 'CLKOUT2') -> 'TLPLL0CLK2'`, the fork's chipdb was regenerated with `python3 -m apicula.chipdb_builder GW5AST-138C` under `GOWINHOME`, and nextpnr-himbaechel was rebuilt with `~/tools/rebuild-nextpnr.sh`, which exists because the architecture is generated at make time and the option spelling is easy to get wrong. The regenerated database was diffed against the previous one before use: exactly one pip added, none removed, no other tile field changed, and the only node change is that `TLPLL0CLK2` now merges the PLL tile wire at `(27,1)` with the bridge wire at `(54,93)`, which is precisely what the code's own comment says the mapping is for. On the design, `clk67` and its phase-shifted off-chip sibling `clk67_p` moved from `pll33`'s `CLKOUT2` and `CLKOUT3` to the same outputs of `pll16` at `PLL_L[0]`, which is possible because `clk16` and `clk67` share a VCO: 1809 MHz is 108 times 16.75 and 27 times 67, so one loop divides to both. `clk67_p` keeps the 16/7 fine-phase shift `pll_33` gave it, and `pll33` now drives only `clk50`, its other outputs left unconnected on purpose. The result is categorical where the old behaviour was seed-dependent: across seeds 1 to 8 every placement now routes `clk67` on global resources with zero failed dedicated routes and zero hold violations, against three clean seeds of six before, and `clk67`'s Fmax rose to 125 to 141 MHz against a 67 MHz constraint. The production, video-proof, SDRAM-probe and overlay-free machine images were all rebuilt at seed 1 with zero hold violations and every clock passing, and all four now report both `clk16` and `clk67` on global resources. The apicula fork was committed as `495661a`, which also carries the previously uncommitted FVCO 1809 MHz measurement from entry 3's work. Nothing was deployed: the Tang was not connected to, at the user's instruction, so whether the `clk67` fix repairs the SDRAM readback and the absent picture is not known and must not be assumed. The syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, and validated this entry as entry 4 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of four against the 100-entry limit.

#### Next Steps:

Load the rebuilt images in the order the diagnostics were designed for, once the user releases the board: the video proof first, whose result should be unchanged from entry 3 and is only a control for the rebuild; then the SDRAM probe, which is the real question, because the readback failure of entry 3 was measured while `clk67` was on general routing with more than a nanosecond of skew across the SDRAM controller's own registers, and if the data path now reads back correctly the SDRAM fault was the clock all along; and then the overlay-free machine image, where any picture at all would be the first evidence this port has produced of the GBA itself running. If the SDRAM still fails with `clk67` clean, the next step is the bit-level probe entry 3's Next Steps specified, since the current pattern set cannot name which data lane fails and bits 0 and 4 are the only two known to read back. The `reg [2:0] bar` truncation in the video pattern is still unfixed and still makes the right-hand band red instead of grey; it is harmless but should be corrected before the pattern is used as a reference again. `README.md` remains a single heading and documents neither the build nor the deploy, which is a real gap for anyone picking this up cold.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/pll/pll_16.v
- fpga/gba/tinygba.sdc

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---
## 5 COMMIT Unreleased 2026-11-02T00:18:29-07:00

#### Coming From:

Unreleased 1bc4149

#### Purpose:

Put the rebuilt images on the board for the first time, and find out whether clean `clk67` routing repairs the SDRAM readback.

#### Outcome:

The video path works and the SDRAM was never broken. Both results are hardware readings from the Tang Console 138K, deployed one-wire with `openFPGALoader -b tangconsole` from the oss-cad-suite copy.

`01_video` draws eight vertical bars — red, green, blue, white, yellow, cyan, magenta, grey — with the 16x16 white orientation marker at the top LEFT and the wide grey band on the right, in the correct orientation and correctly letterboxed. That is the first picture this port has ever produced, and it proves the whole video chain on this board: the PLL and divider topology, the four clock placements in `tinygba.cst`, the OSER10 serialiser path and the TMDS pair. It also validates entry 4's `clk67` clock-plane fix in the only way that counts.

`02_sdram` then reported two green bars and six red on the low die, all red on the high die. Read against the probe's own pattern table, that fits one explanation: the low halfword of a 32-bit access reads back and the high halfword does not. It is not the memory. `gba_memory.sv` documents a 32-bit SDRAM read as `sdram |rd_lo| wait|rd_hi|ready| data` with `cpu_ready` in the cycle BEFORE the data, so at the ready cycle `cpu_rdata` holds the low halfword just captured beside the PREVIOUS high halfword, and `sdram_probe.v` took its comparison there. Assuming the stale high halfword is whatever the previous pattern wrote predicts all eight bars exactly, including that bars 0 and 1 pass and the other six fail — which is what hardware showed. The fix is two steps in `S_WAIT`: latch on `cpu_ready`, take the data on the following clock, and do not re-test `cpu_ready` in the second step because it is a registered pulse and is gone by then. `sdram_gba.v` is unchanged.

Three instrument faults were found and corrected on the way, and all three had already produced a confident wrong reading. A first lane-mode probe wrote `0xFFFFFFFF` and displayed `cpu_rdata[15:0]` — all sixteen bits green, and it could not have failed for any input, because 0xFF is the one byte a dead, floating or stuck-high lane all produce. The probe sampled one clock early, above. And the first attempt at the sample-point fix latched on `cpu_ready` and then waited for `cpu_ready` to still be high, which never happens.

The bench could not have caught any of this, and that is the finding worth carrying forward. `tools/run_diag_sim.sh` compiles `sdram_sim.v`, a logic-level stand-in that takes `cpu_be` and array-indexes memory, so `sdram_gba.v` — the controller — is never compiled by any testbench and no bug inside it can fail a run. Its PASS lines are true and say nothing about the controller. `fpga/gba/diag/sdram_model.v` and `tb_sdram_controller.sv` were started to close that gap: the model sits at the pins, decodes ACT/READ/WRITE/PRE/MRS/REF off `nCS`/`nRAS`/`nCAS`/`nWE`, honours DQM on write and on read, and holds read data until the next READ as a real part does. It reproduces the controller's own readback but its timing is not yet faithful enough to be an authority, and it is committed as work in progress rather than as a reference. Two things it needed before it could see anything: the controller samples at its own rotate slot rather than at the CL=2 point, so a part that drives for `cas_latency` clocks gives ZZZZ; and `sdram_gba` relies on the device powering its RV-port register to zero — it is only ever cleared, never initialised, and with no reset term iverilog leaves it X, which propagates into `nCS` and `nWE` until the controller issues no read or write at all. That is the same shape as the undriven `PAL` that cost TinySNES two days.

The corrected probe did not reach the board. Place and route ran 26 minutes and 241,000 iterations without converging, oscillating around 8,000 unrouted nets rather than trending down, and failed. The lane-probe build of nearly the same netlist completed the whole flow in 14 minutes, so this is the seed sensitivity the project already records rather than a property of the change. Nothing is lost: the fix is committed and the netlist is reproducible.

#### Next Steps:

Rebuild the corrected `TINYGBA_SDRAM_TEST` image with a different placement seed or through `tools/sweep_tinygba_seeds.sh`, which exists for exactly this, and read the sixteen bars. Sixteen green means the SDRAM is 32 MiB and sound and the two red-die questions are settled; eight green then eight red means the single-CS die select does not work and the module gives 32 MiB, which the GBA can live with for every cartridge that fits. Then `04_machine` with a real cartridge — `tools/load_gba_rom.py` streams one over the core's own UART and is validated against a retail image (Nintendo logo, header byte `$B2`, complement check), sending no header prefix because the GBA core has no 64-byte header handshake and the cartridge header is simply the first bytes of the stream. It has never been run against a live core. Bear in mind when reading the result that `TINYGBA_OVERLAY_OFF` exists because the OSD powers up asserted and its 960-pixel window hides the framebuffer behind an empty menu's black; a production build without that define will look black in one-wire mode and that is not a machine fault. `README.md` still documents neither the build nor the deploy.

#### Files Modified:

- fpga/gba/diag/sdram_probe.v
- fpga/gba/diag/sdram_model.v
- fpga/gba/diag/tb_sdram_controller.sv
- tools/load_gba_rom.py
- .ai/core-log.md

#### Status:

- Build: PASS for 01_video, 02_sdram, 03_prod, 04_machine; the corrected SDRAM probe FAILED place and route at seed 1 after 26 minutes
- Deployment: one-wire, 01_video 33c639b1, 02_sdram 960e2ae0
- User Test: PASS video chain, eight bars in correct orientation; SDRAM result requires the rebuild above

---

## 6 COMMIT Unreleased 2026-11-02T09:27:00-07:00

#### Coming From:

Unreleased ce62d6d

#### Purpose:

Give this port the two instruments the sibling SNES project only acquired after fifty cycles -- a clock-plane gate and a gate-level readout of the shipped netlist -- and make the first cartridge a discriminator rather than an experiment, without touching the Tang.

#### Outcome:

Three findings changed what this project can claim, and one of them contradicts a result already on record. The first is that every image this project has flashed had `clk67` crossing no clock-plane bridge pip at all, which is the condition core-log entry 4's fix was supposed to have removed: resolving `build/deploy/SHA256SUMS` to the routed netlists it was packed from, `build/vsweep_5`, `build/psweep_2`, `build/machine_s5` and `build/diag_sdram_s2` all show `clk16`, `clk50` and `hclk` on bridge pips and `clk67` on none, yet all four passed the hold check and the Fmax gate. So the SDRAM reading in entry 5 was taken on an image whose SDRAM clock was on general routing, and the eight-red-die result cannot be attributed to the probe fix until the corrected probe is flashed on an image whose `clk67` is on the plane. `tools/clock_plane_report.py` now reads this out of `netnames[<clock>].attributes.ROUTING` and `tools/build_tinygba.sh` runs it as a gate that fails on a dead pip or on a required clock crossing no pip; the pip table is inherited from TinyNES DEV-009 and DEV-017 through TinySNES and every entry names its origin, with this project's own hardware results separated into their own table and `clk67` at `TOP2` marked `partial` because the SDRAM probe clocked its own few hundred flip-flops on it and nothing has clocked 2381 sinks on it. The second is that the `syn_keep` marks on `gba_memory.sv`'s port list were inert. Measured on this exact flow with five identically shaped nets across four attribute spellings, only `(* keep *)` survives `read_slang` plus `synth_gowin` and the other three spellings are deleted, and the attribute must precede the declaration or elaboration fails outright. With the comment syntax, 0 of 13 fetch-path names survive in the netlist; with the attribute, 13 of 13 survive at honest widths, checked by `tools/gatelevel_report.py`, which reports per named net whether it exists and whether every bit has a driver. The conversion is a change of auditability and not of behaviour, and saying otherwise would have been the easy mistake: the netlist has the same 4734 flip-flops and the same set of 322 undriven wires before and after, and the cell count moves a few percent because ABC sees a different optimisation boundary. The remaining 99 comment attributes in 14 other files are still inert and are left as an open item rather than swept in the same cycle. The third is that `TINYGBA_OVERLAY_OFF` currently has no buildable machine image. Six seeds of that configuration all fail the `clk67` Fmax gate at 33.6 to 36.0 MHz against 67.0, on a 26-stage 29.77 ns path running from `cpu_mem_rdata` through `mem.rom_data`'s read muxes and `cpu.cmd` back into `sdram.SDRAM_BA`. That is not this cycle's doing and not a bad seed: the tree as it stood before any of these changes, synthesised fresh and routed at seed 5, fails the same gate at 38.76 MHz, while the same tree without the define passes at 171.26 MHz at the same seed with a 5.84 ns path, and the netlist from Oct 31 re-routed at seed 5 passes at 154.01 MHz. So the trigger is the machine configuration itself and it is open. What did build: `TINYGBA_SDRAM_TEST` at five clean seeds, all with zero hold violations, every clock passing, `clk67` on `SPINE27/TOP2` at 208 to 256 MHz and `clk16` at 19.4 to 20.0 against 16.75, seed 5 the best on both; the Oct 31 sweep's seeds 1, 2 and 7 were stopped part-way and are not reported as results. Seeds 1, 2 and 7 of that SDRAM sweep were terminated by a `pkill -f nextpnr-himbaechel` intended for them alone, which also killed a concurrent TinySNES build belonging to another agent; that build was restarted by its owner and lost one placement run, and the lesson -- cancel a job by its own task id or its own pid, never by a pattern that matches every build on the machine -- is recorded here because the same mistake would take out someone else's work again. `tools/make_gba_test_rom.py` assembles a 4 KiB ARM cartridge from source embedded in the script and verifies its own output: header, complement check, entry branch and the three read-back constants, all eight checks hand-disassembled. It forces blank, checks three constants at three cartridge offsets, writes and reads back IWRAM, EWRAM and VRAM with two individual byte lanes, draws mode 3 green for a pass or red with one yellow column per failed check, and blinks a square so a capture separates a running CPU from one that wedged; it enables no interrupt and writes no `WAITCNT`, so a pass says nothing about either, which is the distinction that cost the SNES project several cycles. The logo region is zero-filled because this core's BIOS is Cult-of-GBA built with `NO_LOGO` and branches straight to `0x08000000`. Nothing was deployed and the Tang was not connected to, at the user's instruction. Three records were added to `.ai/core-reference.md` -- TCL-007 on attribute syntax, TCL-008 on nextpnr printing its hold count only when it is non-zero, and BRD-004 on a clock passing both gates while crossing no bridge pip -- and `README.md` gained the two gates, the test cartridge and the machine-image blocker under Known gaps. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 5 were not rewritten and that the three new records carry unique ids and the canonical field order, and validated this entry as entry 6 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of six against the 100-entry limit.

#### Next Steps:

Settle the `clk67` failure in the `TINYGBA_OVERLAY_OFF` configuration before anything else, because it is the only thing between this tree and a cartridge on the board and it is demonstrably not a seed: the path is 26 logic stages from `cpu_mem_rdata` through `gba_memory`'s read muxes and `cpu.cmd` into `sdram.SDRAM_BA`, the same tree without the define is 5.84 ns, and the two independent syntheses that have it were built from trees differing only in `gba_memory.sv`'s attributes. The question to answer first is whether suppressing the OSD restructures the memory read mux into a deep chain or whether the machine configuration was always this close and the Oct 31 builds were lucky, and the instrument is a read of the two netlists rather than more placements: compare the logic feeding `sdram.SDRAM_BA` between the two configurations in `tools/gatelevel_report.py`'s terms, and if the depth is genuinely configuration-dependent, find which cone the overlay removal changed. Only then produce a machine image at a clean seed and stream the test cartridge at it, expecting the green screen and the blink, and reading a red screen's yellow columns as the check that failed. Separately, `02_sdram` must be rebuilt with `clk67` on the plane and flashed before entry 5's sample-point conclusion can be called a hardware result, since every image that conclusion rests on had `clk67` on general routing. Do not report an `clk16` hardware result without saying which pips it used: it lands on unmeasured `*/TOP3` at every seed, never on the `TOP2` pips that drew the verified video picture, and `TINYGBA_CLOCK_PLANE_STRICT=1` exists to make that a refusal when the project is ready to lose the builds it currently costs. Do not sweep more seeds for the machine configuration until the depth question is answered.

#### Files Modified:

- README.md
- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/memory/sdram_gba.v
- tools/build_tinygba.sh
- tools/clock_plane_report.py
- tools/gatelevel_report.py
- tools/make_gba_test_rom.py
- .gitignore

#### Status:

- Build: FAIL
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 7 COMMIT Unreleased 2026-11-02T09:45:53-07:00

#### Coming From:

Unreleased 0363af6

#### Purpose:

Explain why the `TINYGBA_OVERLAY_OFF` machine configuration failed its `clk67` Fmax gate at every seed, which entry 6 left open and named as the only thing between this tree and a cartridge on the board.

#### Outcome:

The configuration was never broken and the gate was measuring the wrong thing. nextpnr-himbaechel's SDC parser implements exactly six commands -- `get_ports`, `get_cells`, `get_nets`, `get_pins`, `create_clock` and `set_false_path` -- refuses anything else with `Unsupported SDC command`, has no `set_multicycle_path` at all, and logs `does not do anything(yet)` and returns without effect for `set_false_path`. Every path is therefore timed as one cycle. Upstream GBATang's `gbatang.sdc`, which this port replaced with a file that drops every relaxation, heads one constraint with the comment `# sdram.cpu_dout through the CPU back to sdram: 4 cycles` and relaxes `clk16`-to-`clk67` and `clk67`-to-`clk16` by four and `clk16`-to-`clk50` by three. Those allowances are correct for the design rather than a workaround: one `clk16` period is exactly four `clk67` periods, so a path that leaves an SDRAM register, crosses logic clocked at `clk16` and returns to a `clk67` register has 59.70 ns of budget, not 14.92. The failing path is that one exactly -- `cpu_mem_rdata_DFFRE_Q_34` to `sdram.SDRAM_BA_DFFRE_Q`, 29.77 ns, which nextpnr reported as 33.59 MHz against 67.00 and refused. Six seeds failing at 33.6 to 36.0 was not seed sensitivity and not a change: the three controls that would have implicated one all passed, the tree before this cycle's edits giving 38.76 MHz at seed 5, the same tree without the define giving 171.26 MHz with a 5.84 ns same-domain path, and the Oct 31 netlist re-routed at seed 5 giving 154.01 MHz. The combinational depth into `sdram.SDRAM_BA_DFFRE_Q_D` is 57 in both configurations, so the logic was never restructured; what differs is only which path is worst. That matters more than the fix, because it means the six failing seeds and the passing ones were the same design measured two ways, and a single-cycle analysis is wrong in both directions at once: it also never reports the cross-clock paths, so `--timing-allow-fail` would have let a slow `clk16`-to-`clk67` path through with no measurement at all. `tools/timing_gate.py` now judges the build instead of nextpnr, and it is deliberately narrow: every path is held to a single cycle except the four documented pairs, the readback allowance requires both endpoints -- the path must start at `cpu_mem_rdata` and end in `sdram.` -- so an unrelated slow path cannot borrow it, the hold count is gated because nextpnr prints it only when it is non-zero, and every relaxation applied is printed with the upstream line it came from. Five checks stand behind it: the machine configuration passes with one printed relaxation, the same tree without the define passes with none, the SDRAM-probe build at seed 5 passes with none, `build/prod` with its one hold violation fails on hold, and two mutations of the machine build's `timing.json` -- moving the 29.77 ns path's source to an unrelated register, and lengthening the `clk16`-to-`clk67` path past 59.70 ns -- both fail as they must. nextpnr is now always run with `--timing-allow-fail` so that it writes `timing.json` and the routed netlist for the gate to read; it must not be the judge, and this cycle showed both ways it errs. Two records were added to `.ai/core-reference.md`, TCL-009 on the SDC command set and the multicycle contract and BRD-005 on the failure being an analysis artefact, and `README.md`'s known-gaps entry now says the machine image builds but its timing is judged rather than proven. The machine image was then built end to end at seed 5 with zero hold violations: `build/c6_machine_ok/tinygba.fs`, SHA-256 `2ebaaf33b338f39df0fbfdee0cf4dfe8b072a73a828713adcd05f9c476363ad7`, the only relaxation applied being the documented readback one, so a cartridge now has an image to run on for the first time. Nothing was deployed and the Tang was not connected to, at the user's instruction. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 6 were not rewritten and that the two new records carry unique ids and the canonical field order, and validated this entry as entry 7 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of seven against the 100-entry limit.

#### Next Steps:

Put a cartridge on the board, which is now finally possible and is the only thing that can confirm the lesson: load `build/c6_machine_ok/tinygba.fs` one-wire, stream `tools/make_gba_test_rom.py`'s cartridge with `tools/load_gba_rom.py`, and read the screen. A green field with a blinking white square means the CPU fetched through the ROM path, ran, and wrote VRAM and both work RAMs, and that the four-cycle readback allowance holds on silicon; red with yellow columns names the failing check by column; a frozen picture means the CPU wedged after the checks; a black 1080-pixel field means nothing ran or the framebuffer never reached the video window, which `01_video` separates. Do this before rebuilding `02_sdram`, because a booting machine answers the memory question more directly than sixteen bars, and entry 5's sample-point conclusion still needs a `clk67`-on-the-plane image before it is a hardware result. If the machine does not run, the readback allowance is the first suspect and the instrument is the same `timing_gate.py` with `--allow-hold` absent plus a narrowed allowance that requires the endpoints to be tighter, not a wider one. Two things remain over-constrained and should be settled before the next timing conclusion is drawn from this design: `build/prod` still fails on one hold violation and so production is not buildable at any seed tried, and the SDC still declares the four clocks flat with `create_clock` because the parser cannot name clocks, so the `clk16`-to-`clk50` three-cycle allowance upstream makes is not applied and those paths are held to one cycle of `clk16`, which is conservative rather than wrong. Do not treat a passing timing gate as evidence the machine runs, and do not sweep more seeds for a configuration that failed: check which path is worst and whether the contract relaxes it before concluding anything about a seed.

#### Files Modified:

- README.md
- tools/build_tinygba.sh
- tools/timing_gate.py

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 8 COMMIT Unreleased 2026-11-02T10:12:00-07:00

#### Coming From:

Unreleased 2ee5b8a

#### Purpose:

Put the machine image and the corrected SDRAM probe on the board for the first time since the timing gate was corrected, and find out whether the black machine picture is a memory fault.

#### Outcome:

The SDRAM is good and the machine still does not boot, which is the most useful pair of answers this project has had. The machine image `build/c6_machine_ok/tinygba.fs` drew a black field 1080 pixels wide flanked by the grey pillarbox bars, with HDMI synced: by the two widths recorded for this core that is the video window with an empty framebuffer, not the 960-pixel OSD window, and the OSD was independently ruled out rather than assumed absent -- the machine netlist has no `iosys.disp.menu_mem` and no overlay net at all, because `TINYGBA_OVERLAY_OFF` ties `overlay` to `1'b0` in logic and synthesis deletes the whole block, against 98 OSD and menu nets in the same tree built without that define. The cartridge was streamed with `tools/load_gba_rom.py` and the core accepted 4096 bytes in 0.6 s with no error, so the picture is a machine that is not running rather than a stream that failed. The first attempt at the SDRAM probe then showed the same black field, which cannot be that bitstream: the probe writes its sixteen bars from its own raster and takes no input from the GPU, the CPU or the cartridge, so an identical picture meant the load had not taken. That is the fourth recorded occurrence of the silent-load failure in BRD-003 and the second in this session, and it is now recorded in BRD-006 as the way to read that image: reload before concluding anything. Reloaded onto a rebooted console, the probe drew a green status band and sixteen green bars with only its own grey margin beyond x=232, which is its full pass: 64 MiB, both dies, all sixteen patterns read back. That settles the SDRAM, the two-die single-CS question and every memory hypothesis, and it supersedes both earlier readings -- entry 3's two green and fourteen red, and entry 5's eight-red high die -- because both were taken from images whose `clk67` crossed no clock-plane bridge pip (BRD-004) and neither had the corrected probe on the board. The working instrument for the remaining fault is now a sticky status probe, `TINYGBA_STATUS_TEST`, added this cycle and built at seed 5 as `build/c6_status/tinygba.fs`, SHA-256 `87fba5cff2863adfd94f20fc755bac5da0028e4becd6c3c0a4c9e939b87b390b`, zero hold violations and the same single documented relaxation. It latches six facts that never clear -- whether `gbaon` rose, whether `rom_en` ever asserted, whether `cpu_mem_ready` ever rose, whether `loader_do_valid` ever rose, whether the GPU ever wrote a pixel, and whether `halt` asserted -- and draws them as sixteen bars beside a live `rom_addr[27:18]`, with the band green once `gbaon` is high. Its bits are held low while `resetn` is low and only then allowed to set, which is the trap TinySNES hit when two of its history bits were unarmed and self-set at reset. It has not been on the board. Two things were checked offline and one hypothesis was withdrawn. The controller testbench `fpga/gba/diag/tb_sdram_controller.sv` still reports `xxxxffff` and then `zzzz`, and the trace shows `dq` as `Z` at the controller's sample slot, so it remains unable to see the controller as hardware sees it -- the same limitation entry 5 recorded, still open, and it is now explicitly not an authority. And an inspection of the status netlist initially read the sticky bits' data input as `joypad.reg_dout` and their enables as unrelated signals, which looked like a miscompiled probe; tracing the drivers showed bit 1515 is driven by a `VCC` cell, so it is constant 1 exactly as written, and the netname attached to it was a stale alias. That is the third time in two cycles that reading netnames rather than drivers produced a wrong conclusion, and it is why `tools/gatelevel_report.py` reads drivers. Nothing was deployed as the cycle closed and the Tang was handed back to the operator. BRD-006 was added to `.ai/core-reference.md`, `README.md`'s status now records the SDRAM as verified, and the diagnostic table gained `TINYGBA_STATUS_TEST`. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 7 were not rewritten and that BRD-006 carries a unique id and the canonical field order, and validated this entry as entry 8 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of eight against the 100-entry limit.

#### Next Steps:

Load `build/c6_status/tinygba.fs` and read the six sticky bits, because SDRAM is now exonerated and the remaining fault is a chain of four links that this build separates in one picture: a green band means `gbaon` rose and the loader released the machine, bit 1 means the CPU issued a cartridge fetch, bit 2 means the controller answered a request, bit 3 means cartridge bytes reached the loader at all, bit 4 means the GPU drew a pixel, and bit 5 means the CPU took a halt. Read the band first, then the low six bars left to right, and read the top ten as the region `rom_addr` is in rather than as a number. The most likely reading, and the one to look for, is a green band with bit 3 clear, which would mean the bytes never reached the loader even though the stream reported success -- that would put the fault in the `0x07` loader write path rather than in the CPU, and the next instrument is a counter of loader writes shown beside the same bits. If bit 3 is set and bit 1 is clear, the cartridge is in memory and the CPU is not fetching it, which points at `gbaon` and the reset sequencer rather than at memory. Do not re-test the SDRAM: it is verified and a fifth memory test would add nothing. Do not trust the controller testbench until its DQ drive window is aligned with the controller's own sample slot, and do not read any netlist by netname -- trace drivers, because a stale alias has now produced three wrong conclusions in two cycles. The production configuration still fails on hold and remains unbuildable, which should be settled by finding the path rather than by sweeping seeds.

#### Files Modified:

- README.md
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gba2hdmi.sv

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 9 COMMIT Unreleased 2026-11-02T14:03:08-07:00

#### Coming From:

Unreleased a69a20a

#### Purpose:

Put the long-dormant machine on the board at last, find why it draws nothing, and replace the hand-built probe whose readings had already been mis-decoded three times with one generated from a single field list.

#### Outcome:

The machine runs the BIOS and stops on a halt it can never be woken from, and the answer was reached only after this session's instruments were made trustworthy. Three findings stand, each confirmed by more than one instrument. SDRAM is good: the corrected probe drew a green status band and sixteen green bars with only its own grey margin, which is 64 MiB with both dies and all sixteen patterns, and that supersedes both earlier probe readings because both came from images whose `clk67` crossed no clock-plane bridge pip. The GPU raster is alive: `DISPSTAT`'s V-Blank and H-Blank flags both arrive and the scanline counter advances, so the display timing is not the fault -- this refuted the cycle's own opening prediction and is why the probe moved from the IRQ outputs to the status flags, since `IRP_VBlank` and `IRP_HBlank` are gated by IRQ-enable bits the CPU must write and a CPU that never gets that far guarantees them low. And the CPU executes the official BIOS and stops at a real halt: the latched fetch address decoded to `0x344`, which disassembles in the official image to `strb r3, [ip, #769]` with `ip` = `0x04000000`, the write to `HALTCNT`, and the probe reads one halt entry, never cleared, with the V-Blank IRQ enable clear. That closes into a single missing write rather than a dead subsystem: `halt` clears when any `IRPFlags` bit sets, `IRPFlags[0]` needs `IRP_VBlank`, and `IRP_VBlank` needs the `DISPSTAT` enable that only the CPU can write. The machine is not broken in four places; it halts one instruction too early to ever be released. Two operational results matter for the next session. The official BIOS was wired in without entering the repository, through a `TINYGBA_BIOS_HEX` build define that takes a quoted absolute path, with the image converted to a hex file under the ignored `build/` directory; the in-tree default stays the open-source Cult-of-GBA image. And a logo-bearing test cartridge was generated with `--logo-from` splicing the 156-byte logo out of a local retail image, because the official BIOS validates the logo and hangs on a cartridge that lacks it, which would have looked exactly like a machine fault. The silent-load failure recurred three more times, once showing the previous bitstream's picture after a flash of a different one, and each time the correct response was a reload rather than an investigation; the probe image writes its bars from its own raster and cannot legitimately draw the machine's black field, which is what made it identifiable. The larger result of the session is instrument discipline. Five of this project's own readings were wrong in this session before being caught -- a reversed bar order that bit-reversed a displayed address, a halt latch that required `halt` and `rom_en` in the same cycle and so could never fire, IRQ-gated probe bits that were provably constant under synthesis, a live signal labelled as latched, and a multi-byte count read MSB-first from an LSB-first field -- and every one produced a plausible number rather than an error. The sibling SNES project's correction of its entry 62 showed the same class recurring there four times, so the fix applied here is structural: `tools/probe_map.py` holds one declarative field list and generates both the RTL packing, as `fpga/gba/src/probe_bits.vh`, and the host decoder, and `tools/build_tinygba.sh` refuses a build whose include does not match the list. The guard measures `$bits` of the packing expression rather than restating the generator's own arithmetic, and it was verified by deliberately mismatching the bus width and watching elaboration fail with `unknown module`, which is the only reliable elaboration-time failure on this flow since slang rejects `$error` and yosys drops a blackboxed module silently. An earlier version of that guard compared a constant against itself and could never have fired. The list also carries a short id, emitted as `PROBE_MAP_ID` and printed by the decoder, because a generated decoder cannot be trusted against a capture from a different layout: bar 3 changed meaning between two builds in this session. Two records were added, BRD-007 for the halt finding and TCL-010 for the generating rule, and `README.md` now says the machine runs the BIOS and halts rather than that it was never booted. Nothing was deployed after the readout was taken. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 8 were not rewritten and that the two new records carry unique ids and the canonical field order, and validated this entry as entry 9 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of nine against the 100-entry limit.

#### Next Steps:

Latch `gb_bus_adr` and `gb_bus_din` at the first write to `0x04000004` and read whether the BIOS writes `DISPSTAT`'s V-Blank IRQ enable at all, because that single question separates the two remaining explanations and everything else is measured: if no write to that address ever occurs, the BIOS halts before reaching the instruction that enables it, and the next step is to find which branch it took instead, with the halt-address latch already built and its trigger now known to work; if a write occurs with bit 3 clear, the BIOS is enabling a different source and the suspects become the interrupt master enable at `0x04000208` and the interrupt enable word at `0x04000200`; and if the write occurs with bit 3 set and `DISPSTAT[3]` is still clear, the write is not reaching `gba_gpu_timing` and the fault is in that decode path. Add the field to `tools/probe_map.py` and regenerate rather than hand-editing the packing, and check whether `REG_DISPSTAT_V_Blank_IRQ_Enable` is driven at all in the netlist first, because the sibling project's `PAL` and `GSU_TURBO` faults were both an undriven term folded to a constant by `synth_gowin` and that class has now cost two projects several cycles. Do not re-measure SDRAM, the raster, the clock plane or the timing contract; all four are settled and recorded. Do not decode a probe frame by hand, and do not trust a capture without checking that its map id matches the build it came from. Treat any flash that shows the previous bitstream's picture as a reload, not a result, and prefer `tools/probe_map.py --decode` over reading bars from a screenshot.

#### Files Modified:

- README.md
- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/probe_bits.vh
- tools/build_tinygba.sh
- tools/probe_map.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 10 COMMIT Unreleased 2026-11-02T15:04:12-07:00

#### Coming From:

Unreleased 2fbfef6

#### Purpose:

Build the core under Verilator so it can be asked whether it is correct rather than only what state it is in, after six hardware cycles produced one word per flash.

#### Outcome:

The core simulates for the first time in this port's history, and it boots and renders, which makes the hardware failure a divergence rather than a mystery. Upstream GBATang ships a complete Verilator harness at `verilator/sim_main.cpp` with an SDL window, FST tracing and audio capture, and this port had never carried it, so every result on record had come from a 16-pixel bar strip on a capture card with nothing to compare against. The harness needed three repairs before it built, and each is evidence it had never been run against this revision: `memory/gba_eeprom.sv` carries two `ifdef VERILATOR` `$display` statements that index `mem`, an array whose declaration is commented out in the same file at lines 83 to 98, so the vendor's own simulation build cannot elaborate; upstream's source list omits `gpu/linebuffer.v` and `memory/mem_eeprom.v`, both of which are instantiated unconditionally; and `mem_eeprom.v` still instantiates `MUX2`, `DFFRE` and `DPB` under `VERILATOR`, which only the vendor cell library defines, so `tools/sim/gowin_cells_sim.v` carries exactly those three with `specify` blocks removed. With those fixed, `tools/sim/build_gba_sim.sh` verilates, compiles and runs, and the simulation renders frames, writes audio and plays the Cult-of-GBA BIOS visibly. The decisive comparison is that the official BIOS, which halts on the board at the `HALTCNT` write and never wakes, **boots and renders eleven frames in simulation** with the same cartridge. So the RTL is not the fault: something the simulation does not model is. The simulation clocks `clk50:clk16` at exactly 3:1 from a single counter, which matches the board's 50.25:16.75 MHz, so it is a fair reference for logic and an unfair one for anything depending on how two clock domains relate -- and on the board `clk16` and `clk50` come from different PLLs, `pll16` and `pll33`, while in simulation they come from one counter. That difference is now the leading candidate and was not testable before this cycle. Two smaller findings came with it. `dispstat_dbg` was declared inside the probe `ifdef` and therefore used unconnected outside it, which this project's own synthesis builds silently tolerated as an implicit net and Verilator refused; it is now declared unconditionally. And a comment line beginning `// Verilator` is parsed as a pragma directive and fails elaboration, which is worth knowing before writing RTL comments. The user also reports that nand2mario's focus was the 60K board with the 138K secondary, and that a slow CPU could show up in audio before it shows up in display, since the GBA's CPU drives audio directly; that is recorded as a lead rather than acted on, because the simulation now gives a way to measure cycles per frame directly. Nothing was deployed. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 9 were not rewritten, and validated this entry as entry 10 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of ten against the 100-entry limit.

#### Next Steps:

Find what differs between the simulation and the board, because the simulation is now a reference and the question has changed shape: the official BIOS boots in simulation and halts on hardware, so the fault is in something the model does not reproduce. Work the difference list in order of how much each can affect the halt. First the clock relationship: in simulation `clk16` and `clk50` are one counter at an exact 3:1 ratio with fixed phase, while on the board they are `pll16` and `pll33` with no guaranteed phase, and `gba_gpu_timing` takes its register writes from `mclk` while running its state machine on `fclk` -- so instrument the register path across that boundary before assuming the DISPSTAT write that the probe saw on the bus actually lands in the register. Second the SDRAM: the simulation substitutes `sdram_sim.v`, a zero-latency array, for the real controller, so any behaviour that depends on `cpu_mem_ready` arriving late is invisible there. Third, memory waitstates: measure `clk16` cycles spent with `cpu_en` low as a fraction of total in simulation, then compare against what the hardware probe implies, because a CPU that stalls far more than real hardware would explain both a slow boot and the slow audio the user reports, and the GBA's CPU drives audio directly. Do not rebuild and reflash the same netlist hoping for a different result, and do not add more probe fields until the simulation has been used to answer one of those three questions -- the simulation costs minutes and exposes every signal, while a hardware probe costs a build and a flash for one word. Keep the harness's limits in view whenever using it to explain a board result: it has no SDRAM controller, no HDMI, no BL616 link and no PLL phase relationship, so it can prove logic wrong and cannot prove a board right.

#### Files Modified:

- README.md
- THIRD_PARTY.md
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/memory/gba_eeprom.sv
- tools/sim/build_gba_sim.sh
- tools/sim/gowin_cells_sim.v
- tools/sim/sim_main.cpp

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: N/A

---

## 11 COMMIT Unreleased 2026-11-02T16:13:36-07:00

#### Coming From:

Unreleased 565c8b5

#### Purpose:

Find why the board halts where the simulation does not, and build the gate that would have caught it without a session of hardware work.

#### Outcome:

The whole machine failure was one undriven wire, and the project now has a build gate that detects the class. `gb_bus_rst` is an output of `gba_memory` that every `eProcReg_gba` instance reads as `if (gb_bus_rst) Dout_buffer <= register.def;`, and it is assigned nowhere -- in this tree or in upstream GBATang at `77fd0714`, where the vendor flow must simply tie it low. Measured on this flow with a minimal reproducer: `synth_gowin` folds such a wire to constant 1, makes the reset branch unconditional, deletes the write branch, and leaves the register driven by a single GND cell. At scale that removed roughly 4,500 flip-flops from a 9,100-register design -- every MMIO register in the machine -- while the design went on to elaborate, place, route, pass Fmax, pass the hold check and pack a bitstream. The two counts are the measurement: 4,631 registers with the wire undriven, 9,100 with `assign gb_bus_rst = 1'b0;`, from otherwise identical sources, block RAM unchanged. That single fact explains every hardware reading in entries 8 to 10 without exception: the probe saw writes to `0x04000004` carrying `din[3]`, to `0x04000200` and to `0x04000208`, while the live `DISPSTAT` V-Blank IRQ enable stayed 0, because no register existed to hold it; `IRP_VBlank` could therefore never assert, `IRPFlags` could never set, and `halt` could never clear, which is why the CPU stayed stopped on the `HALTCNT` write at `0x344` that the address latch had already named. The GPU raster and the SDRAM were never implicated and remain verified. The reason the simulation disagreed is now precise rather than mysterious: Verilator treats an undriven wire as 0, so the model contained the registers the bitstream did not, and the fold is exactly the difference between them -- which means no simulation of this design could ever have found this fault. The gate is `tools/synth_parity.py`: it compares a netlist's flip-flop and block-RAM population against a recorded baseline for its configuration, fails on a loss beyond ten percent, and prints the `used but has no driver` wires synthesis reported, grouped by instance. It was tested against the two builds this cycle produced -- the pre-fix netlist fails at 49.1 percent loss and the fixed one passes at 0.0 -- and all three exit codes were exercised, including the `2` that reports a missing baseline rather than passing silently. Recording a baseline from a build whose correctness is known is deliberate: absolute comparison between RTL and netlist does not work on this design, because techmapping expands one RTL register into several cells and the netlist then legitimately carries more than the source implies, which was measured at 7,435 against 9,100 and would have made a direct comparison meaningless. The gate is wired into `tools/build_tinygba.sh` as stage 1b, keyed on the configuration's `TINYGBA_*` define names with `TINYGBA_BIOS_HEX` excluded, because that define selects which bytes are loaded into the BIOS block RAM and changes no logic. Three smaller things came with it. The harness exited its step budget by falling through into the SDL event loop and spinning at 100 percent of a core with the window frozen, which reads on screen as a hang or as someone having paused it; it now exits with a message and idles with `SDL_Delay` when paused. Frame dumping was added to the harness, `-p PREFIX -pe N`, writing PPMs straight from the framebuffer, because capturing the SDL window depends on the window being findable and unoccluded and the first attempt grabbed the entire desktop instead. And the simulation was confirmed to render a retail cartridge through the official BIOS, reaching the Game Boy Advance boot logo, with the CPU spending only 2.2 percent of cycles waiting on memory and 76.4 percent halted in the BIOS's own idle loop. The fixed image was built and gated but not deployed: `build/c6_fixed/tinygba.fs`, SHA-256 `5cfea671aa842c4169ceed0a5fa4b675b066744b64a215c80202185875b194d3`, seed 5, zero hold violations, one documented multicycle relaxation, clock plane clean. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 10 were not rewritten and that the two new records carry unique ids and the canonical field order, and validated this entry as entry 11 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of eleven against the 100-entry limit.

#### Next Steps:

Deploy `build/c6_fixed/tinygba.fs` with the status probe and the logo-bearing cartridge, and expect `vblank_irq_en` to assert and `halt_cleared` to set -- which would be the first time the BIOS has ever passed its boot halt on this port, and the first hardware evidence that the fix is real rather than merely synthesised. Read it with `tools/probe_map.py --decode` and check the map id matches, not by eye. If `halt_cleared` sets and `cart_fetched` goes high, the machine is running and the remaining work is retail-game compatibility in the simulator, which is where the effort belongs now: every question about correctness is minutes there against a build and a flash here, and the user's plan to perfect the simulator first and spot-check hardware periodically is the right shape for this project once the gate above closes the one gap the simulator structurally cannot. Re-take every register-dependent measurement from entries 8 to 10 on the fixed build before relying on it, because all of them describe a machine whose registers were absent; the measurements that do not involve MMIO writes -- SDRAM contents, raster flags, the halt address, fetch-region history -- stand as recorded. Record baselines for the production and SDRAM-test configurations once each has been boot-tested, since a baseline from an unverified build certifies nothing. Do not treat a passing parity gate as proof the design is correct: it catches a loss of registers, not a wrong one. Do not revert the `gb_bus_rst` assignment to match upstream, and if upstream is ever updated, check whether the vendor tool still ties the wire low before assuming it.

#### Files Modified:

- README.md
- fpga/gba/src/memory/gba_memory.sv
- tools/build_tinygba.sh
- tools/sim/sim_main.cpp
- tools/synth_parity.py
- tools/synth_baseline.json

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: N/A

---

## 12 COMMIT Unreleased 2026-11-02T16:25:27-07:00

#### Coming From:

Unreleased b0ce2cb

#### Purpose:

Put the `gb_bus_rst` fix on the board and find out whether the machine's boot halt finally clears.

#### Outcome:

The halt clears, and the machine executes its boot halt loop for the first time in this port's history. The deployed image, `build/c6_fixed/tinygba.fs` at SHA-256 `5cfea671aa842c4169ceed0a5fa4b675b066744b64a215c80202185875b194d3`, carries 9,100 registers against the 4,631 of the previous build, and the status probe reads `0xFFFE` under field map `1dce3f01`: the `DISPSTAT` V-Blank IRQ enable asserts, `halt` clears after having been seen, and the halt counter saturates at fifteen. The previous build entered exactly one halt and never left it, so the difference is the whole interrupt path working end to end -- the CPU writes `DISPSTAT` bit 3, `IRP_VBlank` asserts, `IRPFlags` sets, and `halt` clears -- which is precisely what BRD-008 predicted and what entries 8 to 10 could not have seen, because the registers those writes landed in did not exist. The rest of the reading is unchanged and self-consistent: the scanline advances, VBlank and HBlank arrive, writes to `0x04000004`, `0x04000200` and `0x04000208` all occurred, and `halt` is live at the sampled instant, which is expected since the BIOS spends most of a frame halted between VBlanks -- the simulator, which showed 76 percent of cycles halted, predicts exactly that. Two captures eight seconds apart are identical, so this is a steady state and not a transient. One thing did not change: the CPU has still never fetched from the cartridge, since `rom_addr[27:24]` non-zero has never been observed, and the machine has now run at least fifteen complete halt-and-wake cycles without reaching `0x08000000`. That is the next fault and it is a different one from this cycle's. The measurement method is worth recording because it is the first hardware reading in this project that was decoded by a tool rather than by eye: `tools/probe_map.py` generated the RTL packing and the decode from one field list, and the bar interpretation came from that rather than from reading a screenshot, which is the discipline TCL-010 calls for after four consecutive mis-decodes on the sibling project. The capture device was held by OBS for part of the cycle and one capture attempt failed with `Device or resource busy`; the fix is to take the reading when the device is free rather than to work around it. Nothing remains deployed beyond the tested image. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 11 were not rewritten and that BRD-009 carries a unique id and the canonical field order, and validated this entry as entry 12 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twelve against the 100-entry limit.

#### Next Steps:

Find why the CPU runs fifteen halt-and-wake cycles without ever fetching from `0x08000000`, and do it in the simulator rather than with another probe, because the board has now given the same six-bar answer twice while the simulator can show every fetch. The specific question is what the BIOS is waiting for after its halt loop: the official image boots to the logo and then reads the cartridge header at `0x08000004`, so a machine that never touches `0x08000000` is either still in pre-logo initialisation or has diverged before the header check. Instrument the simulator to log the first fetch from each region and compare that sequence against the board's fetch-region history, which is already recorded and sticky. If the simulator also never reaches the cartridge with this cartridge image, the difference from the earlier successful run is the image, since the earlier run that reached the logo used a retail cartridge and this reading streams `build/test/test_logo.gba`; re-run the simulator with the same test cartridge before concluding anything about the board. Do not re-measure the halt path, the raster, the SDRAM or the register writes -- all are now measured and working -- and do not build another probe until the simulator has answered. Record baselines for the production and SDRAM-test configurations once each is boot-tested, since a baseline from an unverified build certifies nothing.

#### Files Modified:

- README.md

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 13 COMMIT Unreleased 2026-11-02T17:36:15-07:00

#### Coming From:

Unreleased 416cf14

#### Purpose:

Turn the newly working Verilator model into the project's primary instrument, and find out what the core can actually do with it.

#### Outcome:

The core runs retail and diagnostic cartridges correctly in simulation, and an independent hardware test suite says so. Upstream GBATang ships a complete Verilator harness with an SDL window, FST tracing and audio capture, and this port had never carried it, so every result on record had come from a sixteen-pixel bar strip on a capture card with nothing to compare against. The harness needed three repairs before it built at all, each evidence it had not been run against this revision: two `ifdef VERILATOR` `$display` statements in `gba_eeprom.sv` index an array whose declaration is commented out in that same file, upstream's source list omits `gpu/linebuffer.v` and `memory/mem_eeprom.v` which are instantiated unconditionally, and `mem_eeprom.v` still needs the `MUX2`, `DFFRE` and `DPB` primitives, carried in `tools/sim/gowin_cells_sim.v` with `specify` blocks removed. Three additions made it usable as an instrument rather than a demo: deterministic frame dumping to PPM straight from the framebuffer, since capturing the SDL window depends on it being findable and unoccluded and the first attempt grabbed the whole desktop; CPU stall accounting, which reports cycles with `cpu_en` low and the halt fraction; and fetch-region history, mirroring the hardware probe's sticky OR of `rom_addr[27:21]` so the two can be compared without translation, plus a data-region counter over `ram_addr`, because cartridge data reaches the controller on a different bus from instruction fetches and the hardware probe tracks only the latter. The results are stronger than expected. Super Mario Advance boots: the BIOS animation completes, the first instruction fetch from the cartridge occurs at sim_time 452,974,016, execution is later seen in `0x08000000`, `0x0C000000` and `0x06000000`, and the game reaches its own save-data check and reports 'The saved data is corrupt', which is correct behaviour because the harness fills cart RAM with `0xff` and models no save hardware. RetroRegen GBA Test v1.5 goes much further and is the result that matters: it reports `CPU: ARM7TDMI @ 16.78 MHz`, `SET: ARM v4T (ARM+THUMB)`, `BIOS SUM: 0xBAAE187F`, `AGB BIOS: GBA/SP/MICRO`, bus timing `IWRAM 1190`/`EWRAM 1702`/`ROM 1702` cyc per 256 reads all `OK`, `WAITCNT: 0x0000`, cart SRAM `OK (64K RANGE)`, and `MEMORY TEST -- RESULT: ALL REGIONS PASS` across IWRAM 32K, EWRAM 256K, VRAM 96K, PRAM 1K and OAM 1K; the LCD solid, LCD ramps and GPU scene checks also passed by eye and the GPU stress test ran, with audio and buttons skipped deliberately. That is the first independent third-party confirmation of the machine side of this port and it is far better evidence than any probe built during this session, because it is a suite judging the core rather than the core's own instrument reporting on itself. Its limit is stated in the same breath and must travel with it: the model substitutes `sdram_sim.v`, a behavioural array, for the real controller and does not compile `sdram_gba.v` at all, so `EWRAM` and `ROM` passing establishes that the CPU asked the right addresses and the decode is right and establishes nothing about the physical controller or its timing. Two methodological corrections came out of this cycle and both were mine. Frame dumps at fixed intervals can be byte-identical across several samples while the picture is merely static by design, and a static screen is not a hang; more seriously, I drew conclusions from runs I had cut short, reporting that the simulator never fetched from the cartridge when in fact the first cartridge fetch is around frame 500 and my samples stopped at 177 -- conclusions drawn from a run that has not finished are not measurements. Scripted controller input was added, `-press BIT@FRAME[:DURATION]`, so a boot test does not depend on a human and a window having focus, and it was confirmed working by a scripted START advancing the splash screen; manual driving was still faster for exploring the diagnostic menu, and the operator took over. The 177-frame and 605-frame samples also show the CPU doing real work rather than idling: the halt fraction falls from 80.9 percent in the BIOS loop to 37.2 percent running the diagnostic ROM, with 49.8 percent of cycles issuing cartridge fetches. Nothing was deployed this cycle. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 12 were not rewritten and that the two new records carry unique ids and the canonical field order, and validated this entry as entry 13 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirteen against the 100-entry limit.

#### Next Steps:

Run RetroRegen on the Tang, because it is now the sharpest instrument this project has and the one question the model cannot answer is the physical memory path: the same ROM on the board will report the same ten facts in one screen -- CPU identity, BIOS checksum, per-region bus timing, and the memory verdict -- and either match the simulation or name exactly where hardware diverges, which is worth more than any probe built this session. Build the production machine image with the `gb_bus_rst` fix at a clean seed, gate it, and stream the diagnostic cartridge at it; expect the BIOS logo, then the RetroRegen splash, and note that it needs START to leave it. Treat the memory test as the decisive line: `IWRAM` and the graphics regions are block RAM in both model and bitstream and should match, while `EWRAM` and `ROM` go through `sdram_gba.v` on the board and an array in the model, so a difference confined to those two regions is the SDRAM controller and a difference anywhere else is something new. Do not re-measure what the diagnostic suite has already settled in simulation, and do not build another bespoke probe before this ROM has run on hardware. Independently of the board, two gaps in the model are worth closing because they gate whole classes of retail testing: the save hardware is a `0xff` fill rather than a model, so every game that checks its save stops at a message, and `sdram_gba.v` is absent entirely, so nothing the model does can exercise the controller. Do not draw a conclusion from a simulation run that has not reached its step budget, and record the step budget and frame count with any result taken from it.

#### Files Modified:

- README.md
- tools/sim/build_gba_sim.sh
- tools/sim/gowin_cells_sim.v
- tools/sim/sim_main.cpp
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/memory/gba_eeprom.sv

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: PASS

---

## 14 COMMIT Unreleased 2026-11-02T19:28:00-07:00

#### Coming From:

Unreleased 4f679cd

#### Purpose:

Compile the real SDRAM controller into the Verilator model, so that what the simulation says about memory stops describing an array and starts describing the 534 lines of `sdram_gba.v` that run on the board.

#### Outcome:

The controller now loads a cartridge byte-perfectly and services the CPU at the same stall rate as the behavioural array, and getting there required finding two acknowledgement losses in the memory FSM that had never been visible because no bench had ever run the controller. The infrastructure cost four repairs before a single line of controller logic executed: the model and the controller both drive a tristate from a `reg`, which this simulator refuses and which is fixed by copying to a wire first; a `z`-valued register initialiser is the same construct and becomes `16'h0000` behind a `dq_oen` that is already high; the harness clock could not express the 4:3:1 relationship at all, since its six-step counter yielded only `clk16` and `clk50` and the controller needs `clk67` at exactly four times `clk16`; and the loader began writing before the controller had finished its 200 microsecond initialisation, 13,424 `clk67` cycles, so the first writes went into a part that was still programming its mode register. With those fixed the controller accepted exactly one request and then stopped, which is what led to the real finding. `sdram_gba` acknowledges a CPU request at its `cycle[3]` slot, three `clk67` after the slot counter is re-seeded by a `clk16` edge, and holds `cpu_ready` for exactly one `clk16` period. Because the slot always falls inside the `clk16` period that issued the request, the acknowledgement is visible on the very next `clk16` edge and on no other -- measured, and invariant across all twelve relative phases of the two clocks, which was checked by sweeping them rather than argued. The ROM path reaches `REQ1_WAIT` on that edge and works. The loader's `REQ1_START` and the second request's `REQ2_START` each add one `clk16` hop, so their first `REQ1_WAIT`/`REQ2_WAIT` sample lands one edge after the window has closed and they wait forever; a counter in the consuming FSM confirmed `sdram_ready` was never sampled high in any wait state. Why this was never seen is the part worth carrying forward: `sdram_sim.v` runs on `clk16` and acknowledges a request two `clk16` after it, one cycle later than the controller does, so the FSM's extra hop was free against the array and is fatal against the real part. The array was not a weaker version of the controller; it was a different timing contract. Three edits restore it, each marked `TinyGBA:` -- the loader goes straight to `REQ1_WAIT` as the ROM path does, `REQ2_START` consumes the acknowledgement and falls back to `REQ2_WAIT` for the 32-bit case that acknowledges a cycle later, and `cpu_en`'s concurrent rom+ram term is widened to `REQ2_START` because it would otherwise read low through the acknowledgement it was just taught to accept; the first attempt at the second edit omitted that third and stalled the CPU instead, which is worth recording as the reason the three travel together. Measured after: the loader writes all 4,096 bytes of the test cartridge and a dump of the memory die matches the file halfword for halfword, `ldrWrites` wrapping to exactly zero being 16 times 256 and therefore itself evidence the load completed; the memory FSM stops stalling, and on RetroRegen the controller build reports 2.5 percent CPU stall against the array's 2.5 percent over the same run; boot reaches the built-in BIOS splash and animates through it. What is not established, and must not be read into the above: the cartridge's own code has not been seen to execute under the controller. The run reaches frame 500 with no instruction fetch from `0x08000000` while the controller's request counters freeze, the picture stops on the BIOS logo, and the array build on the same ROM has already drawn RetroRegen's own splash by frame 100. Two candidate causes remain and neither is excluded: the cartridge read path returning data the CPU does not accept, which is unverified in a way the write path is not, or the BIOS choosing not to hand off. Both are reachable with the instruments now in the tree. One earlier conclusion was withdrawn during this cycle: a screen that does not change is not evidence of a hang, and equal frame hashes across samples were twice explained by static-by-design content before the request counters showed which runs were actually idle. Nothing was deployed.

#### Next Steps:

Localise the divergence to the read path before touching anything else, because the write path is proven and the read path is not: dump the first cartridge reads the BIOS performs, address and sampled `dq_in` at the controller's collect point, and compare them against the same offsets in the ROM file, which distinguishes a wrong word from a right word at the wrong time. If the words are right, the fault is timing or handoff and not data, and the next instrument is the CPU's view: whether `cpu_en` and the read data are presented on the cycles the ARM7TDMI samples them, which the array model's one-cycle-later acknowledgement hides. Do not conclude anything about cartridge execution from a run that has not reached at least frame 500, and treat the request counters rather than the picture as the evidence for whether the machine is idle. Once the read path is settled, re-run RetroRegen on the controller and require the same ten facts entry 13 obtained from the array -- CPU identity, BIOS checksum, per-region bus timing and `ALL REGIONS PASS` -- because a memory test that passes through a real controller is the first result in this project that speaks about the board's memory rather than a model of it. The `sdram_model.v` used here is the sibling project's part and models no refresh, no timing violations and not the second die's physical timing, so even a perfect run bounds logic and sequencing only. One known latent defect is deliberately left alone: the DMA path still enters `REQ1_START` and will lose its acknowledgement the same way the loader did, and nothing has exercised DMA yet.

#### Files Modified:

- fpga/gba/diag/gba_sdram_rtl.v
- fpga/gba/diag/sdram_model.v
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/memory/sdram_gba.v
- tools/sim/build_gba_sim.sh
- tools/sim/sim_main.cpp

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: PENDING

---

## 15 COMMIT Unreleased 2026-11-02T21:20:00-07:00

#### Coming From:

Unreleased b3f55fc

#### Purpose:

Put the sticky status probe on the board and get a hardware answer to a question a black screen cannot answer: how far does the machine actually get?

#### Outcome:

The machine gets further than any record in this project has ever claimed, and stops at one specific place: it never fetches from the cartridge. `TINYGBA_STATUS_TEST` was built at seed 5, packed clean (`clk67` 131.2 MHz against 67.0, zero hold violations, no relaxation needed) and loaded, and three states were read off the board with the generated decoder. With no cartridge: every bit zero and the status band blue, which is the correct "still loading" baseline and also proof the probe is not self-setting. With the 4 KiB test cartridge: scanline, VBlank and HBlank all arrive, the CPU writes DISPSTAT, DISPSTAT-with-IRQ-enable, IE and IME, it halts and wakes seven times, and `cart_fetched` stays low. With RetroRegen: the same alive signals and the same four register writes, but the CPU halts exactly once and never wakes, and `cart_fetched` is still low. So on hardware the video timing runs, the CPU executes, and the interrupt registers the BIOS needs are all written -- and no cartridge instruction is ever fetched in any configuration. That is the first time the boot path has been narrowed to a single stage on the board rather than inferred from a black picture. Two corrections belong with the result and are not incidental to it. The first is that a decode of these same captures was initially read against a hand-written bit list in the RTL comment, which a later edit to the map had left behind, and that stale list put `cpu_mem_ready`, `rom_en`, `pixel_out_we` and `loader_do_valid` at bits that are actually `vblank_arrived`, `scanline_run`, `vblank_irq_en` and `halt_live`. A "the SDRAM controller answered on hardware" claim was stated to the operator from that decode and is withdrawn here: the generated map has no such field, and the board has not been shown to answer a memory request. The comment has been replaced with a pointer to `tools/probe_map.py --list` so the prose copy cannot drift again. The second is that two earlier cycles concluded from a black screen that cartridge bytes were not reaching the core; the actual cause was the capture card returning black at 1280x720 whatever the board drew, recorded as BRD-012, and the loader was working the whole time. The picture is still black with a real cartridge loaded, and that is now the open question rather than the finding, with the probe having ruled out the stages before the fetch. Nothing was deployed beyond this diagnostic image, and the machine image was flashed and reloaded several times during the readings.

#### Next Steps:

The gap is between the loader accepting bytes on the host side and the CPU fetching from `0x08000000`, and it has two candidate halves that the current probe cannot separate: whether the cartridge bytes land in SDRAM at all, and whether the CPU's fetch path reaches the controller once they do. Add a probe bit or two rather than reasoning: a sticky `loader_do_valid` (the byte actually entered the loader, not the host's belief that it sent it) and a sticky `cpu_mem_ready`, both of which exist as wires in `gbatang_memory`'s interface and neither of which is in the current map, then read them under the same three conditions. If `loader_do_valid` never sets, the fault is in the loader-to-memory path and `tools/load_gba_rom.py`'s baud and framing are the instruments. If it sets and `cpu_mem_ready` does not, the fault is the acknowledged-request loss already fixed in simulation and the fix has not reached the board. Also worth one cycle: with the test cartridge the CPU halts and wakes seven times, which is the boot halt loop the simulation shows, while RetroRegen halts once and never wakes -- that difference is not explained and may be the larger cartridge or the save-data check rather than a fault. Do not read a black picture as evidence about the machine: pin the capture format and quote the histogram, as BRD-012 requires.

#### Files Modified:

- .ai/core-log.md
- .ai/core-reference.md
- fpga/gba/src/gbatang_top.sv

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PENDING

---

## 16 COMMIT Unreleased 2026-11-02T21:40:00-07:00

#### Coming From:

Unreleased e46fe86

#### Purpose:

Put the two signals that separate "the bytes never arrived" from "the controller never acknowledged" onto the probe wire, and close a hole in the decoder that made reading a capture depend on luck.

#### Outcome:

The probe now carries `loader_valid` (`loader_do_valid` rose) at bit 14 and `mem_ready` (`cpu_mem_ready` rose) at bit 15, which are the two facts BRD-013 left unresolved: `cart_fetched = 0` is consistent with the cartridge bytes never entering the loader and with them entering a controller that never acknowledges, and nothing on the wire could tell those apart. Both signals already existed as sticky latches in `st_bits[2]` and `st_bits[3]`; they had simply never been exposed, so this is a map change rather than new capture logic. Two bits had to come off to keep the sixteen-bar geometry that the renderer and the decoder both assume, and `scanline_run` and `hblank_arrived` were the ones removed: both are already recorded as VERIFIED in BRD-013, and `vblank_arrived` still proves the video timing runs, so nothing that has been relied on is lost. The map id moves from `1dce3f01` to `b7850627`, which is the mechanism working: every field above bit 1 moved, so an old capture is not readable under the new map. Building this exposed a defect in the decoder that was worse than the thing being built. `--decode` printed the *current* map id and then decoded regardless, so a capture taken under one map was silently rendered with another map's field names -- demonstrated by decoding the BRD-013 RetroRegen capture under the new map, which reported `vblank_arrived = 1` where the bit was actually `scanline_run`. The docstring claimed "a capture decodes only under the map that built it" and that claim was false in the code, which is the same class of defect as the stale comment in entry 15: a plausible output with no enforcement behind it. It mattered more here, because the tool exists specifically to stop this, and a session that trusted it would have gotten a confident wrong answer. The fix is mechanical rather than advisory: `tools/build_tinygba.sh` now records the map id in `$out/probe-map.id` at build time, `tools/cap_tang.sh` copies that into a `<capture>.png.map` sidecar when it flashes and captures, and `--decode` exits 3 with both ids shown when the sidecar disagrees while marking a capture with no sidecar UNVERIFIED rather than decoding it quietly. The ids are derived from the build that produced the bitstream, not from whatever the tree contains at decode time, so a capture cannot be re-labelled after the fact. `tools/cap_tang.sh` is new and also pins the capture format, because the 1280x720-black trap in BRD-012 was previously avoided only by remembering to type the format by hand. The image built clean: seed 5, `clk67` 153.5 MHz against 67.0, cross-domain 21.4 and 41.5 ns against 59.7, zero hold violations, no relaxation, SHA-256 `23903d61b10f97f12d191d1cdac5fc8d930a7b117dbf1a1175dc85070db62a57`. Nothing was deployed, at the operator's instruction.

#### Next Steps:

Flash `build/tang_status2` and read the same three conditions BRD-013 used -- no cartridge, the 4 KiB test cartridge, RetroRegen -- because the two new bits make that comparison decisive: `loader_valid = 1` with `mem_ready = 0` means the bytes reach the memory path and the controller never acknowledges, so the simulation-verified fix has not reached the board; `loader_valid = 0` means the fault is upstream of memory and `tools/load_gba_rom.py`'s framing and baud are the instruments; both set with `cart_fetched = 0` would move the question to the CPU's fetch path rather than the loader or the controller. Capture with `tools/cap_tang.sh` rather than by hand, so the format is pinned and the sidecar is written. Keep the remaining unexplained difference in view: with the 4 KiB cartridge the CPU halts and wakes seven times, and with RetroRegen it halts once and never wakes, which nothing in this cycle accounts for and which may be the image size or the save-data check rather than a fault. Do not decode any capture without checking the map id, and do not treat the absence of a sidecar as agreement.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/probe_bits.vh
- tools/build_tinygba.sh
- tools/probe_map.py
- tools/cap_tang.sh

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: PENDING

---

## 17 COMMIT Unreleased 2026-11-02T23:05:00-07:00

#### Coming From:

Unreleased eadc31a

#### Purpose:

Find out what actually stalls the machine, after two decoder defects had made the previous hardware conclusions unreliable.

#### Outcome:

The memory controller is exonerated and the fault is the GPU not producing a VBlank, but reaching that answer required finding two independent bugs in the tool that was supposed to make decoding trustworthy. The first was geometry: `--decode` divided the measured field into sixteen equal bands, while the renderer computes `dbg_bits[x / 15]` for `x < 232`, so bar 15 spans 15 source pixels except the last, which is truncated to 7, and the field is not a multiple of sixteen. Every bar centre was therefore slightly wrong and the last bar was sampled roughly one bar to the left, reporting one field's value under another field's name -- the precise failure `tools/probe_map.py` exists to prevent, committed by the tool itself. The second was classification: `is_field` excluded the grey margin by exact match against a short list of greys, and the capture card's MJPEG encoder renders the 135-grey margin as `(134,134,134)` at some columns, so a strip of margin counted as field, the field edge was inflated by about forty display pixels, every centre shifted again, and the last bar was sampled inside the margin and read as zero. Both are now fixed by replicating the renderer's arithmetic and by classifying near-neutral pixels by tolerance rather than by membership in a list. The second bug was caught only because its output was impossible: a clk16-domain latch of `cpu_mem_ready` read 1 while a clk67-domain latch of the same signal read 0, and clk67 is four times faster, so that cannot happen. That contradiction was the most useful measurement of the cycle, and the lesson is to check decode output for internal consistency before believing any of it. With both fixed, the corrected picture is flatly different from the previous report and that report is withdrawn. On a fixed bitstream the board is bimodal across power cycles -- six runs alternating `0xFFFF, 0xF1F4, 0xFFFF, 0xFFFF, 0xF1F4, 0xFFFF`, identically for a 4 KiB and a 284 KiB cartridge. The good state has VBlank, fifteen or more halt entries, and a cartridge fetch. The bad state has `mem_ready = 1`, `mem_ready_clk67 = 1`, `clk67_alive = 1`, DISPSTAT written including the V-Blank IRQ enable, IE and IME written, `halt_entries = 1`, `halt_cleared = 0`, `vblank_arrived = 0` and `cart_fetched = 0`. So in the bad state the CPU configures the V-Blank interrupt, halts once, and waits forever for a VBlank that never arrives; the memory path, the clk67 clock distribution and the CPU are all demonstrably working. The black picture is a consequence, not the fault. The claim in the previous entry that the controller never acknowledges was a decoder artefact and is withdrawn here. A lead was found by reading the timing generator while the build ran and is recorded as a lead and not a result: `cycles` advances only on `if (mclk & ~mclk_r)`, and `mclk_r` is one of two registers in `gba_gpu_timing.v` that the reset branch does not assign (the other is `pixelpos`); if that edge detector never fires, `cycles` never reaches its per-state thresholds, `linecounter` never advances, no VBlank is raised and the CPU stays halted -- which is the observed state exactly. Why this was missed for several cycles is worth carrying: the status probe draws its bars from `gba2hdmi`'s own raster, not from the GBA's GPU, so a perfect picture proves the display path and says nothing whatever about the GBA timing generator, and treating the picture as evidence about the GPU is what hid a frozen GPU behind a working screen. The discriminator build itself (`build/tang_scan`, seed 5, `clk67` 130.5 MHz, zero hold violations, no relaxation, SHA-256 `e6731802d0fe9093f747798a0de601499882368548e46209e7a13b58c8e06500`, map `8c589e34`) puts `scanline_run` on bit 14, replacing `clk67_alive` which had read 1 in every run, so the raw VCOUNT separates "GPU not running" from "GPU running and the flag path broken". Nothing was deployed, at the operator's instruction.

#### Next Steps:

Flash `build/tang_scan` and read the bimodal pair, because `scanline_run` decides between the two remaining causes in one capture: if it is 1 in the failing state the timing generator is advancing and the fault is the DISPSTAT flag or probe path, and if it is 0 the generator is frozen and the unreset `mclk_r`/`pixelpos` lead becomes the primary suspect. Run each condition until both states have been observed rather than reading a single capture, since six runs were needed to see both and a one-shot read has a coin-flip chance of naming the wrong state. Then fix with mechanism rather than prose: assign `mclk_r` and `pixelpos` in the reset branch so the timing generator has no power-up-dependent state, and re-run the same alternating sequence to show the bimodality is gone. Every capture from here should come from `tools/cap_tang.sh` so the format is pinned and the map sidecar is written, and decode output should be checked for internal contradictions before it is quoted.

#### Files Modified:

- tools/probe_map.py
- tools/build_tinygba.sh

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: PENDING

---

## 18 COMMIT Unreleased 2026-11-03T00:55:00-07:00

#### Coming From:

Unreleased 332840e

#### Purpose:

Localise the frozen GPU inside the timing generator, and leave a clean, reproducible state for a handoff after the interruptible build was stopped at the operator's request.

#### Outcome:

The GPU's stall is now located one level deeper than before, and the cycle produced a third decoder defect that matters more than the findings it would otherwise have supported. Taps added behind `TINYGBA_STATUS_TEST` in `gba_gpu_timing.v`, plumbed through `gba_gpu.v` to the top, latched on `clk50` and synchronised into `clk16`, expose four rungs of the generator: reset released, state machine left VISIBLE, cycle counter reached 100, cycle counter reached 1008. The non-diagnostic build is unaffected, checked by building the Verilator model, which does not define the tap. The first capture with these taps decoded as `gpu_released=1`, `[1]=0`, `[2]=1`, and the field map labelled `[1]` as `cycles_100` and `[2]` as `cycles_1008`. That was one rung low: `DBG_gt` packs `{cycles>=1008, cycles>=100, left_visible, released}`, so `[1]` is `left_visible` and `[2]` is `cycles>=100`, and `[3]` — the top rung — was not on the wire at all. Relabelled and widened, the reading is that the cycle counter reaches 100 and the state machine never leaves VISIBLE, which is a specific fault rather than "frozen" and points at a reset that keeps returning: the counter restarts from zero often enough to pass 100 and never often enough to complete a 1008-cycle line. `gbaon` drives that reset, so a `gbaon` that falls again after rising would produce exactly this signature, and a `gbaon_fell` bit was added to test it directly. This is the third decode defect found in one session and the pattern is the important part: the first was bar geometry, where `--decode` divided the field into sixteen equal bands while the renderer draws 15-pixel bars with the last truncated to 7 pixels; the second was grey classification, where exact membership in a short list of greys failed against the capture card's MJPEG rendering the margin as `(134,134,134)`, inflating the field edge by about forty display pixels; the third was hand-written bit indices in the new map, one rung off the RTL packing. All three produced plausible output rather than an error, all three were caught by evidence rather than inspection — the first two by an impossible combination (`mem_ready=1` from clk16 while `mem_ready_clk67=0`, impossible because clk67 is four times faster), the third by the ladder's own internal ordering — and none would have been caught by a width check. Two conclusions from earlier in the session are withdrawn and must not be revived: that the SDRAM controller never acknowledges (it does; `mem_ready` and `mem_ready_clk67` are both 1 in the failing state), and that the fault is a memory-path problem at all. The memory path, the clk67 clock distribution and the CPU are all demonstrably working in the failing state; what fails is the GPU's raster. Every capture taken through the unpinned ffmpeg path is void per BRD-012, and every capture decoded before the geometry and grey fixes is suspect for bit 15 at minimum. The bitstream `build/tang_gb` was stopped during routing at the operator's instruction and is not complete: synthesis finished at 79,460,697 bytes, the register-parity gate passed, and nextpnr was killed at iteration 207,000 with 30,875 nets still unrouted. Nothing was deployed after `build/tang_scan`, whose map `8c589e34` is what produced the discriminating `scanline_run=0`.

#### Next Steps:

Rebuild `build/tang_gb` from the current tree (synthesis is cached and the netlist is intact; `TINYGBA_STAGE=pnr` then `pack`), flash it, and cycle loads until the bad state is caught, because the board is bimodal across loads and a single capture has a coin-flip chance of naming the wrong state — six cycles were needed earlier. Read `gbaon_fell` in the failing state: if it is 1 the loader's release is not stable and the fix is to make `gbaon` latching rather than a level, which would explain the bimodality, the single halt entry and the missing fetch from one cause; if it is 0 the reset theory is wrong and the next instrument is the `mclk` edge detector inside the generator, since `if (mclk & ~mclk_r) cycles = cycles + 1` is the only path that advances the counter and `mclk_r` is one of two registers in `gba_gpu_timing.v` that the reset branch does not assign, the other being `pixelpos`. Fix with mechanism, then demonstrate the bimodality is gone by cycling loads under the same conditions rather than by observing one good run. Capture with `tools/cap_tang.sh` so the format is pinned and the map sidecar is written, decode with `tools/probe_map.py --decode`, and check every decode for internal contradictions before quoting it — that check is what caught two of the three decoder defects. The Verilator model cannot reproduce this class of fault because it never fails to boot, so a fix must be validated on the board or by deliberately perturbing the model's reset timing; do not claim a fix is verified from simulation alone.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gpu/gba_gpu.v
- fpga/gba/src/gpu/gba_gpu_timing.v
- tools/probe_map.py
- fpga/gba/src/probe_bits.vh

#### Status:

- Build: NOT RUN (build/tang_gb stopped during routing)
- Deployment: PASS (build/tang_scan, map 8c589e34)
- User Test: FAIL (black screen, grey pillarbox, HDMI synced)

---

## 19 COMMIT Unreleased 2026-11-03T13:00:32-07:00

#### Coming From:

Unreleased 67e60ad

#### Purpose:

Settle whether the board's frozen GPU raster comes from a metastable loader release or from a defect inside the timing generator, by simulating the generator directly and then putting the best-supported configuration on the board.

#### Outcome:

The generator's reset was genuinely broken, fixing it produced the best timing this port has ever recorded, and the board still draws nothing -- and the cycle's durable results are that defect, a negative result about clock phase, and the first simulation of a BIOS screen in this project's history. The defect is in `gba_gpu_timing.v`: the reset branch sets `cycles_reg <= 0`, but the same always block ends with an unconditional `cycles_reg <= cycles;` where `cycles` was loaded from the pre-edge value, and in Verilog the last non-blocking assignment in a time step wins, so the zero was destroyed and the counter survived reset. Measured in a standalone Verilator model of the module: assert reset at `cycles_reg` 206 and it stays 206. Moving that assignment inside the non-reset branch makes reset do what it says (206 to 0) and leaves frame generation untouched (2 VBlanks in 40 ms, linecounter sweeping 0 to 227, 405 lines). The consequence is larger than the bug: all five seeds of the corrected design now pass `clk67` at 154.012 to 163.747 MHz against a 67.002 MHz constraint with no multicycle relaxation at all, where every earlier build needed the documented four-cycle readback allowance to scrape past at 31 to 36 MHz, so the dead assignment had been masking the real critical path from `cpu_mem_rdata` into `sdram.*`. Two things were established with the Verilator harness rather than the board. Built with the operator's official BIOS and the logo-bearing test cartridge, the model renders the BIOS boot screen -- 240x160, 22 colours, a white `(252,252,252)` field with the logo lettering -- which is the first time this project has reproduced that picture anywhere; and because the harness draws its screenbuffer straight from `pixel_out_we`, `pixel_out_x/y` and `pixel_out_data`, and because `video.mem_portA_we` traces through `mem_portA_we_DFF_Q` to `gpu.igba_gpu_colorshade.pixel_out_we` in the routed netlist, both the GPU's pixel stream and its handoff into the framebuffer are sound. A phase sweep then refuted entry 10's leading candidate outright: with `clk50` and `clk16` at 3:1 and the `clk16` edge moved across twelve offsets from 0 to 55 ns, the raster completed two frames at every one, so the difference between the model's single counter and the board's two PLLs does not matter. Three mechanisms were proposed and withdrawn in the course of this. The first was that `gbaon` was toggling, which the probe had already refuted by reading `gpu_released=1` in the failing state; the sticky release built on it was reverted rather than carried. The second was `TINYGBA_GBAON_ALWAYS`, which ties the release high and failed on hardware because it starts the machine before the loader has written the cartridge, an ordering the model does not have. The third was re-examining the OSD, which is absent from the netlist by construction: zero nets matching overlay, menu, textdisp or cursor. The deployed image was `build/rf_4/tinygba.fs`, SHA-256 `752d933ee7bfa62410f954f5c0e19143650fe7e8a805f2d1051f9aaf3ff9ad19`, built at seed 4 and flashed one-wire, and the operator reports the same picture as every previous attempt: black centre with the grey pillarbox, HDMI synced. One operational fact cost time and is recorded so it does not again: three separate USB disappearances this session, twice taking the FT2232 and both serial ports and once producing a `TinyTang CDC` device instead, were all the console sitting in two-wire mode rather than a cable or driver fault, and the board flashes normally once it is returned to one-wire. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 18 were not rewritten, and validated this entry as entry 19 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of nineteen against the 100-entry limit.

#### Next Steps:

Add `gba2hdmi` to the Verilator build, because the model and the board now agree about everything the model contains and disagree only on the picture, and the one block the model does not compile is the framebuffer, the scaler and the TMDS path -- compiling it turns the last untested link into something a simulation can fail. The question to answer first is whether the GPU still produces a pixel stream once the model carries the framebuffer, and the second is what `x/y` coordinates those pixels land on, since a stream writing outside `pixel_y * 240 + pixel_x` would leave the frame empty while looking perfect upstream. Do not re-derive what this cycle settled: the reset assignment defect, the phase-independence result, the BIOS render in the model, and the absence of the OSD from the netlist are all measured and recorded. Treat the two-way split honestly -- the board has still never been shown to write the framebuffer, so a build that holds the GPU in reset while driving `mem_portA` from a known pattern would separate "no pixels are generated" from "pixels are generated and not displayed" in one flash, and that is the cheaper experiment if the simulation path stalls. Keep `TINYGBA_GBAON_ALWAYS` in the tree as a documented diagnostic even though it failed here, because it isolates the loader from the machine and will be wanted again once the picture works; do not enable it expecting a picture.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gpu/gba_gpu_timing.v

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: FAIL

---

## 20 COMMIT Unreleased 2026-11-03T21:56:28-07:00

#### Coming From:

Unreleased 071e49f

#### Purpose:

Prove on the board whether the GPU's raster actually runs after the counter-reset fix, and if it does, follow the fault down to the stage that stops producing pixels, while building instruments that cannot report a plausible wrong answer.

#### Outcome:

The raster is proven running on the board and the fault is now localised to the drawer, and reaching that took four instrument defects, each of which produced a confident wrong reading first. The raster result is the session's durable one. A diagnostic build carrying the timing generator's ladder across the framebuffer read `white white white black white white white black` under `TINYGBA_PIXTEST`: reset released, state machine left VISIBLE, counter passed 100, unreachable 1008 rung black as designed, `mclk` edge detector fired, counter passed 400 and 700, and `gbaon` never fell. Every rung that a healthy raster sets was set, and the rung that cannot light by construction stayed dark, which is also a check on the instrument. That supersedes BRD-014's `left_visible=0`/`scanline_run=0`, which came from `build/tang_gpu` built before commit `071e49f`, so the dead `cycles_reg <= 0` in `gba_gpu_timing.v` was the raster fault and fixing it closed that record. The next build moved one stage down and read `white white black white white white black white`: `drawline` fires, `hblank_trigger` fires, and `pixel_out_we` never does, so the timing generator hands lines to the drawer and the drawer never emits a pixel. That chain is now the whole open question. Bimodality was also confirmed rather than assumed: two loads of the same bitstream `build/drw2_6/tinygba.fs` gave an all-black strip and then the good reading, which is BRD-014's warning arriving on schedule and which invalidates every single-sample conclusion taken earlier in the session. Four instrument defects are recorded because each one would have supported a wrong finding. First, the initial eight-band build wired `DBG_gt` live rather than latched; because the counter sweeps 0 to 1007 continuously, a live sample reads "below 100, in VISIBLE" about nine times in ten even on a healthy raster, so six of its eight bands were a coin flip, and the build was replaced with a sticky-OR latch. Second, tap registers placed inside `gba_gpu_drawer.v` were removed entirely by synthesis, because `pix_drawer` was their only consumer and sat on no path to a displayed output; the fix is to export raw signals and latch at the top level, where they reach `dbg_bits`. Third, an `assign` referencing `drawstate` before its declaration silently created an implicit wire, and the comparison folded to a constant. Fourth, a band computed as `busy_allmod == 8'h00` folded to the constant-zero net and would have read black for ever; it was replaced with individual busy bits. A fifth defect ended the session without an answer: the latest build's read `white black black black black white white white` is internally contradictory, because band 0 says the machine reached WAITHBLANK and band 3 says `drawline` never fired, and reaching WAITHBLANK requires `drawline`. The cause is that `drawstate` has no reset anywhere in `gba_gpu_drawer.v`, so it powers up in an arbitrary state, and sticky latches cleared by `~resetn` immediately begin sampling uninitialised values the moment reset releases. For a machine that is stuck rather than transient, a live level is the correct instrument and the latch is what introduced the ambiguity. One timing observation belongs with the handoff and is not explained: the drawer-ladder builds pass `clk67` at 32 to 38 MHz where the preceding family passed at 144 to 164, always inside the 59.70 ns multicycle budget and never a gate failure, with 1,683 fewer LUTs and 24 more flip-flops, which fits ABC choosing a different optimisation boundary as core-log entry 6 recorded rather than a design regression. Nothing is committed from the two seeds that were still routing; both were stopped by pid. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 19 were not rewritten, and validated this entry as entry 20 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty against the 100-entry limit.

#### Next Steps:

Rebuild `TINYGBA_PIXTEST` with live levels instead of sticky latches, because the machine is stuck and its steady state is the answer while the latch is what produced the contradictory reading: bands 0 and 1 should show `drawstate` in binary directly, bands for `drawline`, `hblank_trigger` and `pixel_out_we` should be live levels, and two bands should show `busy_allmod[7]` and `busy_allmod[6]` individually along with an OR of the whole vector, so a stuck-DRAWING state names the busy module by bit position. Take every reading across at least three loads before believing it, since two loads of one bitstream have already disagreed, and treat a strip whose bands contradict each other -- reaching WAITHBLANK without `drawline` is impossible -- as a bad sample rather than a finding. Do not re-derive what this cycle settled: the raster runs, `drawline` and `hblank_trigger` fire, and `pixel_out_we` never asserts. Do not widen the search back to memory, clocks or the OSD. If the drawer turns out to be stuck in DRAWING with a busy drawer named, the memory path that the drawers read through `gba_memory`'s GPU ports is the next suspect, because those ports have never been exercised on this board while the simulator substitutes plain arrays, and that is the same model-versus-hardware gap that hid the `gb_bus_rst` fold. `TINYGBA_GPU_TAPS` now gates every GPU tap and is set by both `TINYGBA_STATUS_TEST` and `TINYGBA_PIXTEST`; a new diagnostic that needs the taps must set it explicitly and must declare it before the first `ifdef` that reads it, since preprocessor order silently swallowed an earlier attempt. The console's FT2232 disappears whenever it is in two-wire mode (BRD-015) and this recurred three times; check `lsusb | grep 0403:6010` before concluding anything about a load failure.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gpu/gba_gpu.v
- fpga/gba/src/gpu/gba_gpu_drawer.v
- fpga/gba/src/gpu/gba_gpu_timing.v

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: FAIL

---

## 21 COMMIT Unreleased 2026-11-04T09:58:58-07:00

#### Coming From:

Unreleased 105543b

#### Purpose:

Build the instrument that can say where inside the GPU drawer a line stops, after entry 20 left a self-contradictory strip because it latched a stuck machine, and inherit the one build gate the sibling SNES project wrote in the same cycle that turned its coprocessor on.

#### Outcome:

The instrument is rebuilt as sixteen bands that separate steady state from history, the gate is ported and proven, and nothing has been deployed. The instrument change answers the defect that ended entry 20 without an answer. That build latched every band, and because `drawstate` has no reset anywhere in `gba_gpu_drawer.v` the latches began sampling arbitrary power-up values the instant reset released, which produced a strip reporting WAITHBLANK reached while `drawline` was clear -- an impossible pair. The correction is to stop latching at all for the questions the machine's steady state answers, and to keep latching only for the controls a healthy machine must have produced. Bands 0 to 4 are now live levels re-sampled every `clk50`: `drawstate[1:0]` (0 IDLE 1 WAITHBLANK 2 DRAWING 3 MERGING), `busy_mode345`, and `vramfetch[1:0]` (0 IDLE 1 STARTREAD 2 WAITREAD 3 FETCHDONE). Bands 5 to 10 are sticky ever-true history, cleared on reset: a VRAM fetch reached FETCHDONE, `pixel_out_we` asserted, `drawline` fired, the OBJ drawer reported busy, some drawer reported busy, and `gbaon` rose. Bands 11 to 15 carry live `gbaon` and four unused zeroes. The timing generator's ladder is deliberately dropped from this frame: its answer is already recorded in BRD-017 and carrying it would cost half the bands the drawer needs. The renderer moved from eight bands of 30 source pixels to sixteen of 15, which is 67 display pixels each at the 4.5 scale this mode uses. One hypothesis died on the way and is recorded so it is not re-run: the VRAM read latency is not a model-versus-hardware asymmetry, because `gpu/vram_lo.v` instantiates `DPB` with `READ_MODE0 = 1'b0` (one clock) and `common/sim_dpram_be.sv` does `doutb <= mem[addrb]`, also one clock. What survives as a candidate, and is not promoted past a candidate, is narrower and inside `gba_drawer_mode345.v`'s `tFetchState_WAITREAD`: that branch spends a two-cycle `vram_readwait` countdown BEFORE it examines `VRAM_Drawer_valid_Lo`/`_Hi`, so a one-cycle strobe arriving inside the window is discarded and the poll then waits for a pulse that has already gone. `busy` only clears when a fetch reaches FETCHDONE, so such a stall parks the drawer in DRAWING for ever and no pixel is merged out, which is the observed symptom. The new bands are what would name it: `busy_mode345` high with `vramfetch` in WAITREAD. The second result is the gate. `tools/clock_edge_check.py` is ported from TinySNES, where it is build step `1b` and where its absence cost a whole cycle. On GW5A `synth_gowin` keeps only a plain negedge flop as a true `DFFN` and legalises every negedge flop with an enable or reset into a posedge `DFFRE` behind a LUT1 inverter of the clock, so the two halves clock a few ns apart with no hold check between them; that deadlocked the SuperFX on the board while an ideal-clock bench ran it. The port is wired as build step `1c`, immediately after the register-parity gate, and it was proven rather than assumed. A minimal module carrying the construct -- one plain negedge flop plus negedge flops with an enable and with a reset -- synthesises under `synth_gowin -family gw5a` and the gate exits 1 naming the clock, the true negedge flop and the inverter; today's tree exits 0; a missing file and a missing argument both exit 2. TinyGBA had no gate for this class and its netlists had never been checked for it. Measured here on 2026-11-04: zero `DFFN` cells in a routed netlist, and no flop or block RAM clock pin driven by LUT, MUX or inverter fabric, so the tree is clean and the gate is insurance rather than a fix -- which is exactly the kind of property that rots when it is only ever a one-off grep. The third result is a firm negative about the clock plan, and it is the one that constrains how any future hardware reading may be worded. `tools/clock_plane_report.py --strict` refuses both `build/drw3_1` and the new `build/pix16_s1`: no placement this tree produces puts all four clocks on pips measured good on this board. `clk16` sits on six `*/TOP3` pips with no record at any seed, `clk50` on three unmeasured ones, `clk67` on `SPINE19/TOP2` unmeasured plus `SPINE27/TOP2` only `partial`, and `hclk` on two unmeasured. Only six clock-plane paths are measured-good here, all `clkdiv` or `pll` on `BOTTOM2`/`TOP0`/`TOP1`, and none of them carries `clk16`. That makes the TinySNES BRD-005 variable live on this port: there, the identical netlist booted or left the cartridge depending only on which spine the master clock took, with every build passing Fmax and none reporting a hold violation. The build itself is clean and reproducible. `TINYGBA_PIXTEST` at seed 1 completed in 14 minutes 48 seconds with zero hold violations, every clock passing (`clk16` 19.732 against 16.750, `clk50` 89.071 against 50.251, `clk67` 117.633 against 67.002, `hclk` 98.707 against 74.250), cross-domain paths 19.44 and 39.78 ns against a 59.70 ns budget, and no multicycle relaxation needed, which is the first PIXTEST configuration to reach a bitstream without one. `tinygba.fs` is SHA-256 `454a5dde2ac200fd8a5768e82bd772b84b67cf2138a9a5e6fb9119e3242cdab2` and `tinygba.bin` is `1f6aec923dfcf74af87481d2082d4689a4ef17413b37268eb33667bff6e0c568`, 11,535 flip-flops and 148 block RAM. The taps were verified to have survived synthesis rather than assumed: `tools/gatelevel_report.py` reports `pix_live` 7 bits and `pix_hist` 6 bits all present and all driven, and a backward trace from `video.mem_portA_wdata_DFFRE_Q` reaches both, which is the TCL-013 requirement that a diagnostic register sit on a path to a displayed output. A default-configuration synthesis was run as a regression control and elaborates at 11,574 flip-flops and 149 block RAM with the clock-edge gate clean, so the non-diagnostic build is unaffected; `DBG_vf` is inside `TINYGBA_GPU_TAPS` at both the drawer and the GPU level. No parity baseline was recorded for either configuration, because `.ai/core-log.md` entry 11's rule is that a baseline from a build whose correctness is unknown certifies nothing, and neither build has been booted. Nothing was deployed and the Tang was not connected to, at the operator's instruction, so there is no hardware reading from this cycle and the drawer bands remain unread. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 20 were not rewritten, and validated this entry as entry 21 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-one against the 100-entry limit.

#### Next Steps:

Deploy `build/pix16_s1/tinygba.fs` when the operator releases the board, take at least three loads because BRD-014 measured the machine bimodal across loads of one fixed bitstream, and capture with `tools/cap_tang.sh` so the format is pinned per BRD-012 and the map sidecar is written. Read bands 0 to 4 as "where is it now" and bands 5 to 10 as "did the machinery ever work". The discriminating pair is band 2 against bands 3 and 4: `busy_mode345` white with `vramfetch` reading WAITREAD names a VRAM fetch that accepted an address and never collected the data, which makes the `vram_readwait` countdown in `tFetchState_WAITREAD` the first thing to examine and the fix a re-timed poll that cannot discard a strobe -- either dropping the countdown or latching `VRAM_Drawer_valid_Lo`/`_Hi` across it. `busy_mode345` black with `drawstate` reading IDLE means the drawer never started and the search goes back up one level to the `drawline`-to-`WAITHBLANK` transition and its `linesDrawn < 160` term. Stuck in DRAWING with `vramfetch` IDLE names a drawer other than mode345, and band 8's OBJ history says whether that one ever ran. Treat a strip whose controls are black -- `drawline` never fired, `gbaon` never high -- as a bad sample rather than a finding, exactly as entry 20's contradictory strip was. Do not re-derive what is recorded: the raster runs (BRD-017), the line reaches the drawer (BRD-018), and the VRAM read latency matches the model, so the model-versus-hardware gap is not there. Separately, and before any hardware result from this tree is worded as a statement about the design, settle the clock plan: `--strict` refuses every placement, `clk16` has never been on a measured-good pip on this board, and the only pips that drew the verified picture are the `TOP2` ones. The route to closing it is not another build but a measurement -- a diagnostic that exercises a wide `clk16` domain and is read on the board, so the pip acquires a record -- because the tool can only gate on facts the reference library already holds. Do not switch `TINYGBA_CLOCK_PLANE_STRICT=1` on permanently until that measurement exists, or every build is refused for a reason no one can act on. Record parity baselines for `TINYGBA_PIXTEST` and the default configuration once each has been boot-tested, not before.

#### Files Modified:

- README.md
- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gpu/gba_drawer_mode345.v
- fpga/gba/src/gpu/gba_gpu.v
- fpga/gba/src/gpu/gba_gpu_drawer.v
- tools/build_tinygba.sh
- tools/clock_edge_check.py

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 22 COMMIT Unreleased 2026-11-04T15:38:23-07:00

#### Coming From:

Unreleased bfd0b31

#### Purpose:

Replace the PIXTEST bands that the 2026-11-04 hardware reading could not be trusted to answer, after establishing that a live sample of the per-line fetch state cannot distinguish a frozen machine from a capture landing at the same line phase.

#### Outcome:

The instrument is corrected and rebuilt at a clean seed, and the correction withdraws the standing of last cycle's live-band reading rather than adding to it. Entry 21's bands 3 and 4 were live samples of `vramfetch`, a register that cycles every line, and 48 identical frames across eight seconds were read as a freeze. That inference was unsafe: `clk50` and the pixel clock are locked, so the capture can land at the same line phase every frame and a live sample of a cycling register cannot separate the two cases. This is the aliasing class BRD-014 and TCL-010 already record, and it was my error to sign off on the reading without ruling it out; the sticky bands 5 to 11 of that build are unaffected because a sticky bit cannot alias. The fix asks the fetch questions as sticky facts. Bands 7 to 10 now record whether `vramfetch` ever reached STARTREAD, WAITREAD, FETCHDONE, and returned to IDLE after a line started, and those four are armed on the first `drawline`, because before a line is drawn the machine legitimately sits in IDLE and an unarmed latch would record the reset value -- the arming trap TCL-013 records. The discriminator is band 10 against band 9: a fetch machine that cycles normally sets both, while one frozen at FETCHDONE sets band 9 and never band 10, and neither bit can clear so no capture artefact can fake it. The live bands narrowed to registers that either never move or answer a mode question: `drawstate`, `busy_mode345`, `DrawState`, and all three bits of `BG_Mode` read from the drawer's own register rather than from `DISPCNT`. That last one is aimed at the contradiction the previous cycle left open, because `tFetchState`'s `WAITREAD` is only reachable when the drawer decodes mode 4 while the test cartridge writes `DISPCNT` `0x0403`, which is mode 3, and band 6 alone separates those. `DrawState` is two bits wide but takes only 0 and 1, so synthesis folds its high bit to GND; rather than ship a band that is black by construction the bit was spent on `BG_Mode[0]`, and that fold is recorded because it is exactly the kind of always-black band TCL-013 warns will read as a finding. The memory path the cycle was authorised to investigate was traced instead to a conclusion that removes it as a suspect. The VRAM is not shared with the CPU: `vram_lo` and `vram_hi` are instantiated inside `gba_gpu_drawer.v` at line 838, port A is the CPU on `mclk` and port B the drawer on `fclk`, both `CE` and `OCE` tied high, `READ_MODE0` `1'b0`, and the Verilator build substitutes `sim_dpram_be` with the same one-clock ports. There is no arbitration, no acknowledge and therefore no model-versus-hardware gap in that path, and `vram_blocked` is a non-signal for it. What the measured facts do form is a closed loop: `busy_mode345` clears only when `vramfetch` is IDLE and `DrawState` is NEXTPIXEL, and `vramfetch` leaves FETCHDONE only when `DrawState` is NEXTPIXEL, so every band observed is consistent with `DrawState` being stuck away from NEXTPIXEL. The build cost more routability than its flip-flop count suggests and that is recorded as a toolchain fact rather than a complaint. Synthesis went from 11,535 to 11,538 flip-flops, three registers, but LUTs rose 40,778 to 41,294 and routing arcs from 220,272 to 228,317, about 8,000 arcs, because the added logic includes a wide vector reduction in `gpu_ds[9:2] != 8'h00`. Seed 1 failed place and route after 32 minutes and 368,000 iterations, plateauing near 20,000 unrouted nets, so the netlist was placed at four further seeds in parallel: seeds 3, 4 and 5 were still oscillating at 42 minutes and were stopped by exact pid, and seed 2 completed with zero hold violations, every clock passing (`clk16` 18.990 against 16.750, `clk50` 88.676 against 50.251, `clk67` 118.259 against 67.002, `hclk` 86.333 against 74.250), cross-domain paths 18.23 and 37.26 ns against a 59.70 ns budget, and no multicycle relaxation. That is one clean seed of five attempted, which is on the poor side of the range this project records and is attributed to the arc increase rather than to a broken change. `build/pix17_s2/tinygba.fs` is SHA-256 `226cfe64a6dc56892168ab46a1d39f5ee22ff6de2d2ff11c898fed0e68ffe3e1` and `tinygba.bin` is `d637c1fd2b0b6ff4839e402c470af138a70b9e515a0c2f507ad7520f0a62ad89`. The taps were verified rather than assumed on the routed netlist: `pix_live` 7 bits, `pix_hist` 9 bits and `pix_armed` 1 bit are all present and all driven by their own `DFFRE`, `dbg_bits` carries sixteen bits with no GND padding at all, and a bounded backward trace from `video.mem_portA_wdata_DFFRE_Q` reaches the band word, which is the TCL-013 requirement. One process error is worth recording because it cost a cycle: the first correction was re-synthesised into the same build directory, the build reused the cached netlist, and the resulting GND on a tap bit was misread as the fix having failed. Nothing was deployed and the Tang was not connected to, at the operator's instruction, so this cycle produced no hardware reading and the corrected bands are unread. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 21 were not rewritten, and validated this entry as entry 22 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-two against the 100-entry limit.

#### Next Steps:

Deploy `build/pix17_s2/tinygba.fs` when the operator releases the board, and read bands 9 and 10 first, because they decide whether entry 21's freeze was real or an aliasing artefact and neither can be faked: both white means the fetch machine cycles normally every line and the live reading of last cycle was an artefact; band 9 white with band 10 black means a genuine freeze at FETCHDONE, which bands 3 and 4 then have to explain. Band 6 settles the mode contradiction in the same picture, because white means the drawer decodes mode 4 or 5 and black means mode 3, and `tFetchState`'s WAITREAD is only reachable from mode 4. Take at least three loads, since BRD-014 measured the machine bimodal and the previous cycle observed two states in three cycles, and treat a strip whose controls are black -- band 12 `drawline` ever, band 15 `gbaon` ever -- as a bad sample rather than a finding. Do not re-derive the memory path: the drawer's VRAM is a private dual-port block RAM clocked by the drawer's own `fclk`, not `gba_memory`'s arbiter, so contention and backpressure cannot be the fault and `vram_blocked` is not a signal to chase. If band 6 reads mode 3 and band 9 reads white with band 10 black, the contradiction is in `tFetchState`'s entry condition rather than in the mode register and the next instrument is `DrawState` plus the `drawline` and `vramfetch == FETCHDONE` terms that gate its transition. Separately, this instrument costs about 500 LUTs and 8,000 routing arcs more than entry 21's, which dropped the clean-seed yield from one of one to one of five; if the diagnostic frame is ever to be grown again, prefer individual bit terms over a wide vector reduction, since that reduction is what moved the arc count. Do not re-synthesise into an existing build directory when testing a logic change: the cached netlist is reused and the result is a stale reading of the previous design.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gpu/gba_drawer_mode345.v
- fpga/gba/src/gpu/gba_gpu.v
- fpga/gba/src/gpu/gba_gpu_drawer.v

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 23 COMMIT Unreleased 2026-11-06T18:34:12-07:00

#### Coming From:

Unreleased c81eef1

#### Purpose:

Remove the board-only faults that kept the machine from drawing a picture, from the two-PLL clock split through to the GPU drawer hang that the PIXTEST bands exposed.

#### Outcome:

The GPU now draws on the board, and the fault that blocked it for entries 18 to 22 was synthesis, not logic. The cycle began on the clocks. `clk16` and `clk50` came from two PLLs with no phase relationship while the GPU samples `clk16` state in `clk50` and the SDRAM samples `mclk` raw in `clk67`, so all GBA clocks were moved onto one PLL, `pll16` at `PLL_L[0]`, from a 1809 MHz VCO: `CLKOUT0` divide 36 for `clk50`, `CLKOUT1` divide 27 for `clk67`, `CLKOUT2` divide 108 for `clk16`, and `CLKOUT3` divide 27 for the SDRAM pin clock. A `TINYGBA_CLKTEST` build proved every clock alive and on frequency on the board, but the boot test `pll1ov_s3` stayed black, and a PIXTEST seed sweep then showed the one-PLL move had pushed `clk67` onto general routing, because apicula carries no plane pip for `CLKOUT1`, with hold misses on `sdram.rst_cnt`. Vendor probe builds showed the vendor reaches the plane from `CLKOUT1` and `CLKOUT3` through centre-bridge muxes apicula does not model, so instead `CLOCK_LOC "clk67" BUFG;` was added to `fpga/gba/tinygba.cst`, which makes the nextpnr fork route `clk67` through a `BUFG` and a logic-to-clock gate onto `SPINE16/TOP0` and `SPINE25/TOP1`, both measured good; `clk67` went back into `tools/clock_plane_report.py`'s `REQUIRED_PLANE`, and the finding is TCL-018. `build/bufg_pix_s3` (`.fs` SHA-256 `8566e3e1585f90df75f3b46a2d1822a2cb657dc8fbbdb7bf8d188a508681fc5b`) passed with zero hold violations and on the board held `drawstate` at DRAWING in every capture with `pixel_out_we` never asserting. A new instrument, `build/obj_pix_s3` (`19dde6b5f69d945eec7856c301bcb4ed745d80b31435b4b63bdf539d0927f71d`), added an always-present `DBG_ob` tap of the OBJ drawer's `OAMFetch` and `PIXELGen` states and remapped the sixteen bands to `drawstate`, each drawer's `busy`, the OBJ states, `DISPCNT` OBJ enable, CPU `halt`, a sticky cartridge-fetch bit and `gbaon`. It read every drawer busy, including both affine drawers and mode 3-5 while in BG mode 0, and every drawer busy before the CPU had even been released, which no `drawline` could have caused. The netlist explained it: the upstream RTL leaves `busy`, `vramfetch` and `palettefetch` without reset or initialiser and relies on the vendor flow's power-up at 0, while yosys treats them as undefined, folded `busy_mode2_2 | busy_mode2_2_hd0 | busy_mode2_2_hd1` to a `VCC` cell so that `busy_allmod` could never reach 0, and mapped the other `busy` flops to `DFFSE`, which powers up at 1. `tools/build_tinygba.sh` now runs `setundef -zero -init` before `synth_gowin`, recorded as TCL-017 with the earlier `gb_bus_rst` fold of TCL-011 as the same class. `build/fix_pix_s3` (`.fs` `9c4fe8900f3be710b9be31671d52f9c37203e2ab6fc7dcc4d0c3466492effc81`, `.bin` `e3a648ae55b397b3e7a7b4e082c52faf4c047d4bdafe293af6b2f1b52b7b50bc`) passed with no relaxation and zero hold violations (`clk16` 19.725, `clk50` 80.769, `clk67` 103.210, `hclk` 98.678 MHz) at 48,247 LUTs, 12,038 flip-flops and 226,079 routing arcs, every drawer `busy` is now `DFFRE`, and the 86 remaining `DFFSE` all come from explicit initialisers or reset values of 1. On the board it reads all-zero bands before release, and after the cartridge loads `drawstate` cycles, the bands flicker as the operator saw, and the GBA field is a uniform grey instead of black, which also explains BRD-018. The machine still does not boot: across 48 frames over 12 seconds from reset the field never changes, `halt` toggles so the BIOS is taking V-Blank interrupts, and the cartridge-fetch bit never sets, which is BRD-020. The overlay-off reseeds behaved as TCL-009 predicts and exposed one limit of the `BUFG` route: `build/fix_ov_s1` (`.fs` `ed96667551e0a512a5c99a5d1cc29484b05c19164c0b8a85d1561a66b3f5a9bb`) and `fix_ov_s3` both built with zero hold violations but pass `clk67` only through the documented GBATang four-cycle readback path, at 36.8 and 37.7 MHz, while `fix_ov_s2` routed but was refused by the clock-plane gate because `clk67` fell back to general routing at that seed, so the `BUFG` route is a per-placement result rather than a guarantee and the gate is what catches it. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 22 and the existing reference records were not rewritten, and validated this entry as entry 23 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-three against the 100-entry limit.

#### Next Steps:

Find why the BIOS executes and takes interrupts but neither draws its logo nor jumps to the cartridge. The next instrument should replace the GPU-internal bands, which have answered their question, with what the BIOS is doing to the display: live `DISPCNT` BG mode, forced blank and the four BG enables, the `BLDCNT` effect bits, and `halt`, plus sticky bits for the CPU having written palette RAM, VRAM and OAM and for the cartridge fetch. Those decide between a BIOS that never loads its graphics and one that loads them but is stuck in its fade or blend state. Build from a fresh build directory, take at least three loads, and check every tap against the netlist for constant or undefined drivers before reading the board, since TCL-017 shows a band can be folded without the source looking wrong. When `fix_ov_s1` is wanted as an uninstrumented boot image it is the clean one of the three overlay-off seeds; `fix_ov_s2` must not be deployed. Do not remove `setundef -zero -init` from the build: every register this tree leaves unreset depends on it.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gpu/gba_drawer_obj.sv
- fpga/gba/src/gpu/gba_gpu.v
- fpga/gba/src/gpu/gba_gpu_drawer.v
- fpga/gba/src/pll/pll_16.v
- fpga/gba/tinygba.cst
- fpga/gba/tinygba.sdc
- tools/build_tinygba.sh
- tools/clock_plane_report.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: FAIL

---

## 24 COMMIT Unreleased 2026-11-06T19:18:37-07:00

#### Coming From:

Unreleased 1e4e3a8

#### Purpose:

Find out what the BIOS does to the display after the `setundef` fix, and whether it reaches the cartridge.

#### Outcome:

The machine boots the official BIOS on the board for the first time, and the fault has moved to the cartridge. The PIXTEST band map in `fpga/gba/src/gbatang_top.sv` was replaced with live `DISPCNT` BG mode, forced blank and BG0 to BG3 enables, the `BLDCNT` special-effect bits and CPU `halt`, plus sticky bits for palette RAM, VRAM and OAM writes and for a cartridge instruction fetch, which clear while `gbaon` is low so they describe only the current load, and `gbaon`; a new always-present `DBG_dc` tap carries the `DISPCNT` and `BLDCNT` fields out of `gba_gpu_drawer.v` through `gba_gpu.v`, and the `gba2hdmi.sv` legend was rewritten. `build/dbg2_pix_s3` (`.fs` SHA-256 `af620647481fe950ce7322f885b3d17aaeeba5b1aeac87a0539c12ed64a39021`) passed with no relaxation and zero hold violations (`clk16` 19.502, `clk50` 79.580, `clk67` 145.285, `hclk` 97.069 MHz), and every one of the sixteen band flops traced in `build/dbg2_pix_s3/tinygba.json` to a `DFFRE` with a non-constant driver. While reviewing the legend it became clear that the PIXTEST frame writes its own grey below the bands, so entry 23's uniform grey field and BRD-020's reading that the BIOS never completed its intro were measurements of the instrument, not the machine. `build/fix_ov_s1` was therefore deployed as the first overlay-off image since the fix, and with `test_logo.gba` it played the complete BIOS intro, the GAME BOY and Nintendo marks, between about 1.5 and 5.5 s after release and then held solid white. `build/dbg2_pix_s3` then read the intro from the registers and showed the sticky cartridge-fetch band set from about 6.5 s, so the BIOS accepts the header and jumps, but the cartridge's first store, `DISPCNT` 0, never lands: the register holds BG mode 0, forced blank and all four BG enables, a value the cartridge never writes, with `halt` at 0. The operator then asked for a retail cartridge from the MiSTer image, and Super Mario Advance (USA, Europe), 4 MiB loaded at 2 Mbaud in 21.7 s, failed the same way, holding the BIOS handover value of forced blank with nothing enabled, and on `build/fix_ov_s1` the operator watched the intro end on white, so the test cartridge is not the cause. These are recorded as BRD-021, which supersedes BRD-020's intro reading, and BRD-022. One discrepancy is unexplained: `build/fix_pix_s3` read its cartridge-fetch band as 0 throughout while the identical latch reads 1 here. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 23 and the existing reference records were not rewritten, and validated this entry as entry 24 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-four against the 100-entry limit.

#### Next Steps:

Measure what the CPU fetches after the BIOS hands over. The next instrument should latch the first cartridge instruction fetches after `gbaon` rises, recording each `rom_addr` and the `rom_data` word the memory path returns for it, and draw them so they can be compared against the bytes of `test_logo.gba` at the same offsets; a wrong word at `0x080000C0` or a fetch that never completes names the instruction-fetch path from the cartridge SDRAM, while correct words would move the search to execution and the IO write path. Running the same cartridge in the Verilator model gives the reference fetch sequence to compare against. Build from a fresh build directory and check the taps against the netlist before reading the board. Keep `build/fix_ov_s1` as the uninstrumented boot image and do not remove `setundef -zero -init` from the build.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gpu/gba_gpu.v
- fpga/gba/src/gpu/gba_gpu_drawer.v

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: FAIL

---
## 25 COMMIT Unreleased 2026-11-06T20:01:48-07:00

#### Coming From:

Unreleased c1fa94d

#### Purpose:

Build an instrument that records what the CPU fetches and accesses after the BIOS hands over to the cartridge, so the BRD-022 failure can be placed in the instruction-fetch path or beyond it.

#### Outcome:

A new diagnostic configuration, `TINYGBA_FETCHTRACE`, was added and built but not deployed, because the operator stopped the cycle after the build for an agent handoff. In `fpga/gba/src/gbatang_top.sv` a clk16 recorder starts at the first completed CPU memory cycle whose fetch address is `0x08000000` or above, a completed cycle being `(rom_en | ram_cen) & cpu_en & ~halt`, and stores sixteen consecutive completed cycles as four 32-bit words each in `tr_flat`: word 0 is `{rom_en, thumb, 2'b00, rom_addr[27:0]}`, word 1 is `rom_data` sampled on the following clk16 edge where gba_memory presents it, word 2 is `{ram_cen, ram_wen, ram_be, ram_addr[27:24], ram_addr[21:0]}` and word 3 is `ram_wdata` for a write or `ram_rdata` sampled on the following edge for a read, with a per-entry valid bit; the record clears while `gbaon` is low so each cart load records afresh, and the configuration also turns the OSD overlay off. In `fpga/gba/src/gba2hdmi.sv` the new `tr_sel`, `tr_word` and `tr_valid` ports feed a framebuffer writer that draws each word as one row of 32 bit cells, bit 31 on the left, 7 by 5 source pixels per cell, white for 1 and dark grey or black for 0 in address words and dark blue for 0 in data words, alternating shade per nibble, four rows per entry and eight entries per page, with an entry-valid strip at x 224 to 231 and a page strip at x 232 to 239 that is black for entries 0 to 7 and white for 8 to 15, flipping every 2^26 clk50 cycles, about 1.34 s; outside the configuration `tr_sel` is tied to zero and `tr_word` and `tr_valid` to zero. `build/ftr_s3`, seed 3 from a fresh directory with `TINYGBA_DEFINES` set to `-DTINYGBA_FETCHTRACE` and `-DTINYGBA_BIOS_HEX` given the quoted absolute path of `build/test/official_bios.hex` (an unquoted path fails elaboration in `gba_memory.sv`), passed synthesis with no new warnings in the edited files, the clock-edge gate, the clock-plane gate with every clock on dedicated lanes and `clk67` on measured-good spines, and timing with no relaxation and zero hold violations (`clk16` 20.215, `clk50` 65.334, `clk67` 115.768, `hclk` 100.695 MHz); its `.fs` SHA-256 is `341c31ab1bc12c458213e2471b1e95f7b2979dc2d47d8a715eaeccbb1edca73c`, and the register-parity gate had no baseline for this configuration. In `build/ftr_s3/tinygba.json` all 2,048 `tr_flat` bits, the 16 `tr_vld` bits and the five `tr_n` bits are `DFFRE` cells, and every `tr_flat` flop in all four word positions has a non-constant D and clock enable. The board was left running `build/fix_ov_s1` with Super Mario Advance loaded, in one-wire mode.

#### Next Steps:

On the operator's explicit deploy, flash `build/ftr_s3/tinygba.fs` with `openFPGALoader -b tangconsole`, load `build/test/test_logo.gba` over `/dev/ttyUSB1` with `tools/load_gba_rom.py`, and capture both pages from `/dev/video0`, then decode the rows against the cartridge bytes. The expected start is a fetch of `0x08000000` returning `ea00002e`, probably followed by pipeline fetches of `0x08000004` and `0x08000008` before the branch takes effect, then `0x080000C0` returning `e3a0b301`, `0x080000C4` returning `e3a00000` and `0x080000C8` returning `e1cb00b0`, and the `strh` to `DISPCNT` at `0x04000000` with data 0 arriving in the same memory cycle as a later cartridge fetch, which is the first use of gba_memory's concurrent SDRAM-fetch-plus-data path through `rom_rdata_new`, since the BIOS executes from block RAM. A wrong instruction word, a missing or misaddressed `DISPCNT` write, or a stall names the fault; a correct trace moves the search to the IO write path into the GPU. Write a decoder for the capture before reading it by eye, keep `build/fix_ov_s1` as the uninstrumented boot image, and do not remove `setundef -zero -init` from the build.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---
## 26 COMMIT Unreleased 2026-11-06T21:09:12-07:00

#### Coming From:

Unreleased b362039

#### Purpose:

Deploy the cartridge fetch trace that entry 25 built but never flashed, and answer whether the BRD-022 failure lies in the instruction-fetch path from cartridge SDRAM or past it.

#### Outcome:

The fetch path is exonerated and the fault has moved to the last store the cartridge executes. `build/ftr_s3/tinygba.fs`, whose `.fs` SHA-256 was re-verified as `341c31ab1bc12c458213e2471b1e95f7b2979dc2d47d8a715eaeccbb1edca73c` before flashing, was deployed one-wire with `test_logo.gba` streamed over `/dev/ttyUSB1`, and all sixteen recorded cycles decoded: every cartridge instruction fetch returns exactly the word in the ROM file, fifteen of fifteen, running `0x08000000` to `0xEA00002E` and `0x08000004` to `0x51AEFF24` before the branch, then `0x080000C0` through `0x080000F0` returning `E3A0B301`, `E3A00000`, `E1CB00B0`, `E3A0A000`, `E59F61D8`, `E59F51D8`, `E5964000`, `E1540005`, `138AA001`, `E59F61CC`, `E59F51CC`, `E5964000` and `E1540005`. The single apparent mismatch was entry 10, which is a data-access cycle with `rom_en` clear whose word 1 holds the previous entry's data, so it is not a fetch and not an error. Data reads are correct for the same reason: the literals at `0x080002B0` through `0x080002BC` return `0x08000400`, `0xA5A50001`, `0x08000800` and `0xA5A50002`, and the first `ROMCHK` read at `0x08000400` returns `0xA5A50001`, so that check passes on the board. The `DISPCNT` write is issued too, which is the part BRD-022 got wrong: the fetch of `0x080000C8` is followed two cycles later by a completed cycle carrying `ram_cen=1`, `ram_wen=1`, `be=0011`, `ram_addr=0x04000000` and `ram_wdata=0`, concurrent with the fetch of `0x080000D0`, which is the SDRAM-fetch-plus-IO-write path through `rom_rdata_new` that had never been exercised. Because that instrument could not say whether execution reached the end of the cartridge, the cycle was extended rather than stopped, and the extension is the four-page version of the same readout: `build/io_s3` at seed 3, `.fs` SHA-256 `58a911881cdb88974e7d574c3b511b9e86e488a503cc2c9e3353a7ce39536c5b`, `.bin` `0a7d41c459619fc43aa4ef139886be5cec4823c1eab70a87a91e1e49ab860599`, zero hold violations with no relaxation, `clk16` 20.094, `clk50` 83.689, `clk67` 119.303 and `hclk` 85.778 MHz, 14,200 flip-flops against the previous 13,673 and block RAM unchanged at 148, every tap verified in the netlist as a distinct `DFFRE` with no undriven bits before the load. On pages 0 and 1 it reproduced the same fifteen correct fetches. Page 2, an eight-entry ring of completed CPU writes into `0x04000000` to `0x04FFFFFF` with VRAM, palette and OAM excluded so the fill loops cannot bury the answer, shows the `DISPCNT<=0x0000` store arriving as `0x04000000 <= 0x00000000 be=0011`. Page 3 carries the GPU drawer's own `DISPCNT` registers beside sticky bits, and reads `forced_blank=1`, `BG0` to `BG3` all set and `BLDCNT` none, stable across every settled frame, which reproduces BRD-022's register reading independently and shows that reading was not an instrument artefact. What page 3 does not show is the second write: the sticky `DISPCNT<=0x0403` bit never sets in any frame of three spanning about four seconds, so the cartridge's final `strh` is never reached or never executes, while forced blank remains set and the picture stays solid white. One entry of the ring carries `0x04000000` with `ram_wdata=0xFFE0FFE0` and `be=0011`, a halfword store replicated across both bus halves as the ARM7TDMI does; `0xFFE0` is the colour the cartridge writes to VRAM for its failure columns and `0xFFE0` in `DISPCNT` sets exactly the forced-blank and BG0-BG3 bits observed in the register, so a VRAM store reaching IO space would explain both symptoms from one cause. That is recorded as a lead and not a finding, because it rests on one ring entry with no established provenance and the DMA and sound writes appearing beside it are not accounted for. The new decoder `tools/decode_fetchtrace.py` was written before any capture was read, as entry 25 required, and it immediately earned that discipline by producing a wrong answer of its own: it reassembled `ram_addr[27:24]` at bit 22 instead of bit 24 and turned the `DISPCNT` write into a plausible `0x01000000`, which was caught because the address is impossible for the instruction being fetched and because a synthetic frame rendered from known words then disagreed with the decode. Two further instrument limits are recorded rather than rounded off: the ring's `io_n` counter is three bits, so the entry count reads modulo eight and this build reports `7 entries written, wrapped` rather than a total, and the status page's counters are `clk16` registers read combinationally into the `clk50` renderer with no synchroniser, so the first frame after a page change tears and showed `trace 0 of 16` beside a settled `ring 3`; every later frame agreed and the torn one was discarded. The clock-plane gate again refuses to certify `clk16`, which sits on six `*/TOP3` pips this board has never measured (BRD-019), so this result is attributable to the design only with that caveat stated. Two records were added, BRD-023 for the fetch result and TCL-019 for the page-classification and tearing rules, and the machine was left running `build/io_s3` with `test_logo.gba` loaded, white and stable, for the handoff. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 25 and the existing reference records were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 26 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-six against the 100-entry limit.

#### Next Steps:

Confirm or kill the misrouting lead, because it is the only mechanism on the table that explains both the stuck `DISPCNT` and the white screen from one cause, and the current ring cannot see it: the ring keeps the latest eight IO writes and a stray VRAM store appears in it only if it is one of the last eight things the CPU did, which is why one entry carries `0xFFE0FFE0` and nothing establishes when or why. The next build should replace the three-bit `io_n` with a full wrap counter so the write total is known rather than modulo eight, add a sticky bit for a VRAM-region store seen carrying `0xFFE0` or a `0x0400xxxx` address, and add a small ring of the low address bits of the last VRAM stores, so the question becomes whether the cartridge's fill loop ever addresses outside `0x06000000` rather than whether one ring entry looks odd. If a VRAM store is shown carrying an IO address, the fault is in the address path between the CPU and `gba_memory` and the suspect is the `strh` address decode rather than anything in the GPU; if no VRAM store ever misaddresses, the misrouting lead dies and the alternative is that the CPU wedges before the final `strh`, in which case the next instrument is the tail of the cartridge's own execution rather than its head, and the cheapest form is a sticky counter of completed cartridge fetches drawn beside the existing page, since the head trace already proves the first sixteen and the question would become whether the count keeps rising after them. Note that the fill loop writes 38,400 halfwords and the blink loop never terminates, so the ring's exclusion of VRAM is what keeps the two IO writes visible and any new instrument must preserve that property. Do not re-test the fetch path, the BIOS handover, the SDRAM, the raster or the clocks; all five are measured. Do not draw a conclusion from the first frame after a page change, and classify every capture by its page strips before reading a row (TCL-019). One gap is left open on purpose: only the `TINYGBA_FETCHTRACE` configuration was built this cycle, so the default and production configurations have not been re-elaborated since `tr_sel` widened from six bits to seven, and a default-configuration synthesis is the control to run before the next instrument is trusted. Keep `build/fix_ov_s1` as the uninstrumented boot image and do not remove `setundef -zero -init` from the build. The `clk16` clock-plane question is still open and still bounds how any hardware result here may be worded.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gba2hdmi.sv
- tools/decode_fetchtrace.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 27 COMMIT Unreleased 2026-11-07T14:44:20-07:00

#### Coming From:

Unreleased c24b10b

#### Purpose:

Find what the corrected MMIO ring says the cartridge actually does with its stores, after entry 26 read a ring whose word packing was wrong, and settle whether the fault lies in the memory path or past it.

#### Outcome:

The memory and IO paths are exonerated and the fault is past everything the instrument can see, but reaching that required finding three more defects in the instrument itself and one in my own reasoning. The first defect was in the packing: the ring concatenated 108 bits into a `+:` 128-bit slice, so Verilog zero-extended it, every field shifted down by 20 bits, and every word decoded as a slice across two fields. Entry 26's claim that the cartridge wrote `0xFFE0` into `DISPCNT` came from that garbage and is withdrawn. The first repair was 144 bits into the same 128-bit slice, which truncates instead, and was caught by recomputing the widths before the build finished rather than by a tool. The second defect was the entry stride: the write side indexed `{mm_n, 6'd0}`, which is `mm_n * 64`, while the read side used `{tr_ent, 7'd0}`, which is `ent * 128`, so every odd entry was half-overwritten by its successor and the ring decoded as a blend of two writes. The marker caught that one, which is what it was added for. The third was a decode error of mine: a concatenation packs its leftmost term into the most significant bits, so word 0 of the entry is the rightmost source term, and I had read the words in source order, inverting every field. Three of these are now enforced by mechanism rather than by care. `tools/check_ring_width.py` counts every concatenation against its `+:` slice width and every `{name, K'd0}` index against its slice size as build step `0b`, refuses to pass on a symbol it cannot resolve rather than guessing, exits 2 when it matched no packings so a gate that checks nothing cannot report success, and was mutation-tested both ways -- four stray bits gives `concatenation is 132 bits, slice is 128 bits` and a one-bit stride slip gives `index {mm_n, 6'd0} strides by 64 but the slice is 128 bits`. The RTL carries a `0xA5C3` marker in the spare 16 bits of word 0 so a misaligned packing is detectable in the data, and the decoder raises on a missing marker or on a ring entry whose CPU address is outside IO space, which the latch condition guarantees cannot happen. The build was also trimmed: the 2,048-bit boot trace moved behind its own `TINYGBA_BOOTTRACE` define because it answered its question in BRD-023 and cost 2,064 registers, taking the configuration from 14,851 flip-flops to 12,744. That paid off immediately in place and route -- synthesis fell from 17 minutes to 11, and `build/gx_s4` passed every gate with no multicycle relaxation at all for the first time in this project, `clk16` 19.145, `clk50` 85.056, `clk67` 133.476 and `hclk` 93.694 MHz with zero hold violations and `clk67` on both measured-good spines. Of four seeds, two passed both gates and two were refused, one by the clock-plane gate for `clk67` on general routing and one by a hard `hclk5` to OSER10 `FCLK` route abort, which is recorded as BRD-024. On the board, `build/gx_s4` (`.fs` SHA-256 `ad3bc68d8635f54a6743b9f87b21eb17fa6655b8b07da691a00305e6dc9c227f`) and `build/gx_s2` (`9c1655b45662d7725b1f0871f827d4bbc51e2b916dbecd1fa2709bf401c760bf`) were both deployable, and `gx_s4` was flashed. With the ring correct, all eight slots carry the marker and every entry reads `same cycle`, and the cartridge's IO writes are all correct -- DISPSTAT at `IO+0x084`, the window registers at `0xA0` to `0xAC`, and `DISPCNT <= 0` at slot 3. Super Mario Advance was then run and reaches 84 cartridge instruction fetches before issuing `WAITCNT <= 0x40144014` and a DMA3 transfer from `0x080000FC` to `0x03001190` with `DMA3CNT <= 0x85001F00`, which is the game copying itself into IWRAM and executing from there; an earlier reading in this cycle that called that a freeze was wrong, because a counter of cartridge fetches cannot see IWRAM execution and a frozen counter is not a hang. Four purpose-built cartridges then measured the paths in isolation without a single FPGA rebuild, which was the point of building them: `litprobe` loaded three literals in a known pool order and wrote them to four registers, all correct, which refuted the hypothesis that the CPU computes a PC-relative literal address one word early; `threecase` confirmed literals load correctly with nothing preceding them, after a cartridge read and after an IO read; `shiftpool` loaded three adjacent pool words with no shift; and `repread` read one cartridge address eight times consecutively, all eight correct. Against all that, two cartridges reported the opposite -- `readf8` read `0x080000F8` correctly as data and returned zero for a literal load targeting the same address, reproduced across frames and reloads -- and no variable was found that separates those two from the three that pass. That contradiction is recorded as BRD-026 with lead status and is explicitly not a finding, because the likeliest explanation is a defect in those two test cartridges: both place a literal where the code tail also sits, and every attempt to force the pool to a chosen address was relocated by the assembler. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 26 and the existing reference records were not rewritten, confirmed the four new records carry unique ids and the canonical field order, and validated this entry as entry 27 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-seven against the 100-entry limit.

#### Next Steps:

Resolve the `0x080000F8` contradiction before drawing any further conclusion about the machine, because it is the only measurement this cycle that disagrees with the others and it is recorded as a lead rather than a finding: build one more cartridge that places a literal at exactly `0x080000F8` with no code within several words of it, verify the assembled address by disassembly before loading rather than trusting the source, and read it through the ring. If it returns the constant, the two failing cartridges were defective and BRD-026 should be withdrawn; if it returns zero, the machine has an address-dependent read fault that every other test in this cycle missed, and the instrument to find it is the Verilator model with a watchpoint on `rom_addr`, not another ring. Then take up the display question with the paths the ring has now cleared: cartridge fetches, data reads, literal loads, IO decode, DMA and WAITCNT are all measured correct, so the fault is in whatever the cartridge does immediately before enabling the display, and the instrument that can see it does not exist yet -- the ring only records writes to `0x04000000` to `0x04FFFFFF` and the counter only counts cartridge fetches, which goes blind the moment a game like Super Mario Advance copies itself to IWRAM. Add a sticky record of the last few IWRAM instruction fetches alongside the existing counter, since `0x03000000` execution is where the retail cartridge actually goes, and check whether a thumb-mode immediate-offset store computes a different address from the same store reached by a different route. Do not re-test the memory path, the fetch path, the literal path, the IO decode, the clock plan or the SDRAM; all six are measured and recorded. Do not decode a capture without the marker present in all eight slots, and do not trust a ring reading from any build before `build/gx_s4`, because every one of them carries at least one of the three packing defects above. Keep the packing-width gate in the build: it found nothing on the corrected tree but it is the only thing standing between a silent width slip and another confident wrong reading, and it now checks strides as well as widths. One instrument limit remains from entry 26 and is still open: the status page's `clk16` counters are read combinationally into the `clk50` renderer, so the first frame after a page change tears and must be discarded.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gba2hdmi.sv
- tools/build_tinygba.sh
- tools/check_ring_width.py
- tools/decode_fetchtrace.py
- tools/make_literal_probe_rom.py
- tools/make_mask_report_rom.py
- tools/make_repeat_read_rom.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: FAIL

---
## 28 COMMIT Unreleased 2026-11-07T14:53:40-07:00

#### Coming From:

Unreleased 8524905

#### Purpose:

Settle the one measurement from entry 27 that disagreed with the others, so the cycle can close with a consistent evidence base instead of an open contradiction.

#### Outcome:

The contradiction was in the instrument and is withdrawn: the literal-load path is correct at `0x080000F8`, and BRD-026's lead does not describe the machine. Entry 27 left two cartridges returning zero for a literal load targeting that address while a data read of it returned the correct constant, and named the isolation test that would settle it. That test is `tools/make_addr_probe_rom.py`, and it avoids the failure mode which spoiled the earlier pair: it uses explicit `ldr Rd,[pc,#imm]` offsets rather than `ldr Rd,=value`, so no literal pool is emitted and the assembler cannot relocate the target, and it puts three words of distance between the last instruction at `0x080000EC` and the first target at `0x080000F8`. The build script decodes each instruction back out of the finished image and refuses to write a cartridge unless every load targets the address and constant it claims, which matters because the earlier failures were exactly a case of an instrument not doing what its source said; the result was then confirmed independently with `objdump`, which showed the three loads at `0x080000CC`, `0x080000D0` and `0x080000D4` reaching `0x080000F8`, `0x08000104` and `0x08000110`. On the board all three returned their constants, `0x11112222`, `0x33334444` and `0x55556666`, each to its own ring slot, and a ten-second capture across all four pages showed no variation in any of them. So BRD-026 is superseded by BRD-027 and must not be cited as evidence of an address-dependent read fault. With that closed, every path this cycle can measure now agrees: cartridge instruction fetches are byte-exact, cartridge data reads are correct including repeat and adjacent reads, literal loads are correct at every address tested, IO register decode separates DISPCNT, DISPSTAT, VCOUNT and BLDCNT, and DMA and WAITCNT are observed working on Super Mario Advance. No cartridge completes its display-enable, so the fault lies past everything the MMIO ring can observe. Two operational faults in my own procedure cost time this cycle and are recorded as TCL-021. The first is that a power cycle clears the bitstream: after the console was switched off for a mode change and back on, a cartridge was loaded without a reflash and three capture cycles were spent examining a design that was not running, with an empty ring and all sixteen frames on page 0 -- which is impossible in a running design, because the page advances every 0.67 s, and that inconsistency was the only thing that revealed it. `tools/cap_tang.sh` flashes and captures together for exactly this reason, and calling the loader directly on a board of unknown configuration state is the mistake. The second is smaller and was caught by reading the ring rather than the screen: an early attempt to read the `addrprobe` results filtered on the three expected IO offsets and found nothing, because the ring holds the newest eight IO writes and the BIOS had already pushed the probe's writes out of it; the fix was to dump every slot rather than the ones the test expected, which is the same mistake as assuming a page rather than reading the page strip. Nothing was deployed as an artifact of this cycle: `build/gx_s4` was already the deployed image from entry 27 and was reflashed unchanged, `.fs` SHA-256 `ad3bc68d8635f54a6743b9f87b21eb17fa6655b8b07da691a00305e6dc9c227f`. The board was left running it with `build/test/addrprobe.gba` loaded and was then returned to two-wire mode by the operator. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 27 and the existing reference records were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 28 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-eight against the 100-entry limit.

#### Next Steps:

Build the instrument that can see past the ring, because the ring has now been checked against every path it can observe and all of them are correct. The specific gap is IWRAM execution: the ring records only writes into `0x04000000` to `0x04FFFFFF` and the counter counts only cartridge instruction fetches, so both go blind the moment a cartridge copies itself to `0x03000000` and runs from there, which is what Super Mario Advance does after its DMA3 transfer and is where a retail game spends most of its time. The next readout should latch the first few completed instruction fetches with `ram_addr[27:24] == 3` alongside the existing cartridge counter, and a sticky record of whether `0x03000000` execution was ever seen at all, so the question becomes whether a cartridge reaches its own IWRAM code and what it fetches there. Before spending a build, run the same cartridges in the Verilator model with a watchpoint on `ram_addr` and on `DISPCNT`, because the model can single-step and the board cannot; its known limit must travel with any result, since it substitutes an array for the SDRAM controller and, with this cartridge, does not boot it at all. Do not re-test the memory path, the fetch path, the literal path, the IO decode, the clock plan or the SDRAM, all six of which are measured and recorded. Do not cite BRD-026. Do not decode a capture without the marker present in every slot, and do not read a capture from a board whose configuration state is unknown -- reflash first, and prefer `tools/cap_tang.sh`, which does both. One item remains open from earlier cycles and is unaffected by this one: `clk16` still reaches its sinks on pips this board has never measured (BRD-019), so every hardware result remains contingent on that caveat until a build lands on a measured-good spine.

#### Files Modified:

- tools/make_addr_probe_rom.py

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: FAIL

---
## 29 COMMIT Unreleased 2026-11-07T21:16:05-07:00

#### Coming From:

Unreleased fffc072

#### Purpose:

Make the real SDRAM controller usable in the simulation, so the memory path that runs on the board can be debugged in a model that can be single-stepped instead of only through a bitstream and a capture card.

#### Outcome:

The real-controller model now boots the cartridge, and reaching that required finding a defect in the model itself rather than in the design. The starting point was the previous cycle's conclusion that the real controller reproduced the board's failure; that conclusion was wrong and is withdrawn. What the model was actually doing was returning zero for every cartridge read. The cause is in `fpga/gba/diag/sdram_model.v`: the read path has a shift register `rd_pipe` with a companion `rd_valid_pipe`, and the tri-state enable was computed from `rd_valid_pipe[cas_latency-1]` while the data register `dq_out` was loaded from `rd_pipe[cas_latency-1]` in a later `if` that tested the same index. The two are written a clock apart relative to the shift, so the bus was enabled one cycle before its data arrived and presented the previous word. The controller samples DQ in its own DAT slot, so it captured a stale or high-impedance bus and `cpu_rdata` came out as a clean zero rather than as an error. The write path was never in doubt: the die dump showed `cart[0..3] = 002e ea00 ff24 51ae`, exactly the image's first eight bytes, so the loader, the part and the controller's write sequencing were all correct and only the read capture was wrong. Both the enable and the data now use stage 0, and the result is categorical: all 112 cartridge data reads in a run match the ROM file under byte, halfword and word interpretation, and the model boots the cartridge with 18,375,892 cartridge fetch cycles and `fetch regions` `0x00000040`. The investigation also cost two of my own errors worth recording. I first claimed the real-controller build reproduced the board's stall, which it did not -- the frames I read were a machine holding an unreadable cartridge; and before that I read a run of 900 million steps as evidence of a stall when the same ROM under this controller needs about 3000 million to reach the cartridge, which is the third time this project has drawn a conclusion from a simulation that had not run long enough and the reason BRD-028 records the budget with the result. On the board the fault is unchanged and now reproduced in the model: the BIOS intro plays, the screen goes black, `DISPCNT` receives the cartridge's first `0x0000` store and then only the BIOS's own `0x1002`, and no cartridge read ever reaches the self-checks at `0x08000400`, `0x08000800` or `0x08000C00`, while the same ROM under `sdram_sim` boots to green. Nothing was deployed and the board was not touched: every change in this cycle is simulation-only, and a bitstream built from this tree would be identical to `build/gx_s4` from entry 27, because `sdram_model.v` is never compiled by `tools/build_tinygba.sh` and the harness is not part of the design. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 28 and the existing reference records were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 29 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of twenty-nine against the 100-entry limit.

#### Next Steps:

Single-step the model from the cartridge's literal load to its first self-check read, because that is now the whole remaining distance and it is the only place the two models differ. The specific comparison is the array build, which boots green, against the real-controller build, which stalls: the cartridge loads `0x08000C00` from the pool at `0x080002C4`, and the next thing it should do is read `0x08000400`, and that read never appears in the trace. Run both under the same step budget with a breakpoint on `ram_addr == 0x08000400` and record what the CPU is fetching and what `cpu_en` and `ram_cen` do in the cycles around it, since the difference between the two builds is the controller's acknowledgement timing and not the data. Do not re-test the write path, the die contents or the literal pool: all three are measured correct and recorded in TCL-022 and BRD-028. Do not conclude anything from a run shorter than 3000 million steps with this ROM under the real controller; that limit has now cost three separate wrong readings in this project and is the reason the budget is recorded beside every result. One limit of the model must travel with anything found in it: `sdram_model.v` is a model of a part and not the part, so a fault found here is evidence about the controller's logic and sequencing and not about this board's signal integrity or clock skew, and the board remains the only instrument for those. The board itself is in two-wire mode with `build/gx_s4` and `build/test/addrprobe.gba` loaded from entry 27, and no change in this cycle warrants flashing it.

#### Files Modified:

- fpga/gba/diag/sdram_model.v
- tools/sim/sim_main.cpp

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---
## 30 COMMIT Unreleased 2026-11-08T00:02:15-07:00

#### Coming From:

Unreleased f6574f3

#### Purpose:

Build the readout that can see a cartridge executing from IWRAM, because every instrument this project has used so far goes blind at the point a retail game leaves the cartridge, and find out whether Super Mario Advance reaches its own code at all.

#### Outcome:

The board answers that a retail cartridge writes and reads IWRAM in volume and never executes a single instruction there, which is a narrower and more useful result than anything the display-side instruments had produced. The readout is `build/iw_s5` (`.fs` SHA-256 `b4f5a0800dd1520ae2576e5a1b9edfd2c8c5a7543c67201832a0f6c9096da695`), built at seed 5 with the real controller taps and the official BIOS, passing both gates at `clk16` 18.980, `clk50` 85.727, `clk67` 32.864 under the documented GBATang four-cycle allowance with a 30.43 ns worst path against a 59.70 ns budget, and `hclk` 79.327 MHz, zero hold violations, `clk67` on both measured-good spines. Page 1 gained entry 4: a sticky IWRAM-execution bit with the last IWRAM fetch address, plus full-width counters of IWRAM instruction fetches, IWRAM data writes and IWRAM data reads, all gated on `rom_addr[27:24] == 4'h3` and `ram_addr[27:24] == 4'h3` respectively. The page-1 validity mask moved from `0x0F00` to `0x1F00` because it had been setting bits 8 to 11 only, which would have left entry 4's validity strip dark and made a live entry look absent -- caught before the build by reading the mask arithmetic rather than the picture. All five new registers were confirmed live in the synthesised netlist before flashing: `iw_fetch` 32 bits, `iw_wr` and `iw_rd` 24 each, `s_iw` 1, and `last_iw_addr` 27 with bit 0 folded, which is correct because ARM instruction addresses are word-aligned. On the board, with Super Mario Advance loaded, every page-1 frame over a 16-second capture agrees: IWRAM execution seen 0, IWRAM instruction fetches 0, IWRAM data writes 513204, IWRAM data reads 669827, cartridge fetches 84, halt 1. So the DMA transfers land, IWRAM is written and read heavily, and the CPU never fetches from `0x03000000` even once. This supersedes entry 27's statement that Super Mario Advance copies itself into IWRAM and executes from there: that was inferred from a frozen cartridge-fetch counter and was wrong, though the count of 84 it reported is reproduced exactly. The earlier reading treated the frozen counter as consistent with a game running elsewhere; the direct measurement shows the game never gets anywhere. Of four seeds staged for place and route, seed 5 finished first and cleanly, and seeds 2, 3 and 4 were still routing when this cycle closed at the operator's request for a handoff. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 29 and the existing reference records were not rewritten, confirmed the new record carries a unique id and the canonical field order, and validated this entry as entry 30 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty against the 100-entry limit.

#### Next Steps:

Find why control never transfers into IWRAM, because that is now the single question and it is upstream of everything the display-side instruments were chasing. The data path is proved: 513,204 writes and 669,827 reads mean the DMA lands and the region works, so the fault is in the handover -- the DMA's completion signalling, the branch, or an exception taken at the transfer. Take it to the model, which is the right instrument now: `build/sim_v` or `build/sim_fix2` with `-DTINYGBA_SDRAM_RTL` boots the cartridge and can be single-stepped, and the comparison that matters is Super Mario Advance under the array build, which is the known-good reference, against the same ROM under the real controller. Watch `ram_addr`, `rom_addr`, `cpu_en` and `halt` across the DMA3 completion and record the first instruction the CPU fetches after `cart_fetch` stops rising. The `DISPCNTWRITE` trace already in `tools/sim/sim_main.cpp` is the wrong instrument for this and should be replaced rather than extended. Two measurement traps cost this project real time and must not be repeated: a run shorter than 3000 million steps with this ROM under the real controller reports no cartridge fetches and means nothing, and a frozen counter of cartridge fetches says nothing about IWRAM execution, which is the whole reason this entry exists. Do not re-test the memory path, the fetch path, the literal path, the IO decode, the DMA transfer itself, the clock plan or the SDRAM; all are measured. Do not attempt a fix on the board before the model explains the handover; the board is the only instrument for signal integrity and clock skew, and neither is implicated yet. One standing caveat is unaffected: `clk16` still reaches its sinks on pips this board has never measured (BRD-019), so hardware results remain attributable to the design only with that stated.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- tools/decode_fetchtrace.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: FAIL

---

## 31 COMMIT Unreleased 2026-11-08T09:29:57-07:00

#### Coming From:

Unreleased 2b0e20d

#### Purpose:

Reproduce the board's blank display on demand under the real SDRAM controller and localise the cartridge read-path fault that the array model does not share.

#### Outcome:

The failure now reproduces on demand in the model and is bounded to a single cycle, but its mechanism is not established and no fix was shipped. Two builds of the same tree, same ROM and same 3000-million-step budget differ categorically: with the behavioural array, `build/test/test_logo.gba` renders its pass screen as two colours at a mean of 85, and RetroRegen reaches its menu at 3,420 colours; with `-DTINYGBA_SDRAM_RTL`, both cartridges render one colour for all 889 frames, `test_logo` white at a mean of 252, and RetroRegen white at a mean of 252 against 139,636,806 cartridge fetch cycles in the array build. The controller build reports 18,375,892 cartridge fetch cycles, the identical figure BRD-028 records from the deployed board image, so the model and the board are the same fault. A cycle-level contract trace at the read of the literal-pool word `0x080002B0` records the only difference found: at the cycle the acknowledgement is visible, the array presents `sdram_rdata` `08000400` while the controller presents `e1540400`, and one cycle later both builds present `08000400` in `sdram_rdata` and `ram_rdata` with the same next address, so the divergence is confined to the ack cycle and does not survive its own trace. That convergence is why the mechanism is recorded as a lead rather than a finding, and why the patch the evidence first suggested was reverted rather than shipped: delaying the controller's 32-bit read acknowledgement until the high halfword is collected does make `sdram_rdata` correct at the ack, but `ram_rdata` remained stale because `gba_memory` only sources `sdram_rdata` when the FSM is in `MAIN`, so the frames changed from white to black and the cartridge fetch count rose from 18,375,892 to 26,185,631, which is a different broken behaviour and not progress. Reading the source also confirmed that entry 14's deliberately deferred DMA defect is still present, since the DMA path still enters `REQ1_START` and `dma_done` is gated on the single-cycle `sdram_ready` pulse, but `test_logo` issues no DMA, so it cannot be this blocker. One instrument defect was found and fixed: `tools/sim/sim_main.cpp` capped the `CARTREAD` log at 200 entries, so a truncated log read as a request stream that stopped, and the cap is now 4000. Three of this session's own analytical failures are worth carrying forward because all three were confident conclusions drawn from an instrument that had not been validated: a stale-read claim was withdrawn on the strength of a 1500-million-step run that never reached the literal pool and then reinstated when the 3000-million-step run did, a capped log was read as a stall, and a contract trace stalled because this build's redirected stdout is block-buffered, which was fixed by writing to a file with `$fflush`. Nothing was deployed and the Tang was not connected to; it is in two-wire mode and enumerates as `ffff:5454 TinyTang CDC`. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 30 and the existing reference records were not rewritten, confirmed the three new records carry unique ids and the canonical field order, and validated this entry as entry 31 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-one against the 100-entry limit.

#### Next Steps:

Trace the assembly path rather than the controller handoff, because the contract trace shows the two builds converge one cycle after the acknowledgement and therefore cannot explain a permanent difference from the ack cycle alone: instrument `double_req`, `rom_rdata_new` and the `rom_data`/`ram_data` output mux across a concurrent rom-and-ram access in both builds, since that is the logic that differs between them and the only place a wrong word could be latched into the CPU without appearing at the raw controller interface. Do not re-run the array-versus-controller A/B or re-derive the reproduction; it is measured and recorded. Do not patch `sdram_gba` or `gba_memory` again until a trace survives its own test, because the one attempted patch produced a different failure (white frames becoming black and fetch cycles rising to 26,185,631) while its own probe showed only a partial correction, and it was reverted for that reason. Every simulation in this cycle that carried weight ran to 3000 million steps; a shorter run does not reach the cartridge handover for this ROM under this controller and has already produced two wrong conclusions in this project. When the assembly path is settled, require the array-equivalent result before anything else: two colours at a mean of 85 for `test_logo` and 3,420 colours for the RetroRegen menu. Only then build a bitstream, and note that the board is in two-wire mode and must be returned to one-wire before it can be flashed. The DMA `REQ1_START` defect remains open as its own change and is not on this path, and every hardware result remains attributable to the design only under BRD-019's unmeasured-`clk16`-pip caveat.

#### Files Modified:

- tools/sim/sim_main.cpp

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 32 COMMIT Unreleased 2026-11-08T11:59:55-07:00

#### Coming From:

Unreleased 654017e

#### Purpose:

Replace the cartridge-read instrument that produced three contradictory conclusions with one calibrated against the ROM, and settle whether the controller really returns the wrong word.

#### Outcome:

The controller really does return the wrong word, and the instrument that now says so is validated against the ROM rather than against an assumption about where the CPU samples. The previous harness printed `ram_rdata` on the `cpu_en` edge and asserted in a comment that this was the value the CPU received, which was never checked; that single unexamined assumption is what let a stale-read lead be stated, withdrawn and reinstated across three cycles. `tools/sim/sim_main.cpp` now logs the address with both candidate words, the one visible on the `cpu_en` edge and the one visible on the previous edge, and `tools/check_cartread.py` reads the ROM image, translates the GBA address to an image offset by subtracting `0x08000000`, masks each word by the byte enables and scores both columns. On the array build, which produces a working machine, `data_now` reproduces 184 of 184 captured reads exactly and `data_prev` reproduces 11, so the pairing is established by evidence and the same column can be applied to the controller with confidence. On the controller build, 112 of 4,000 captured reads match the ROM and 3,888 do not, and the mismatches are a consistent one-word lag: `0x080002B0` returns `e154e154` where the image holds `08000400`, `0x080002B4` returns `08000400`, `0x080002B8` returns `a5a50001` and so on through the literal pool. The runs were 3000 million steps each and the frames say the same thing: the array draws two colours at a mean of 83 to 85, which is its pass screen, and the controller draws one colour at a mean of 0 for all 889 frames, with 18,375,892 cartridge fetch cycles against the board's identical figure. The root cause is not established and no fix ships. Two attempts were made and both were reverted unshipped: delaying the controller's 32-bit read acknowledgement until the high halfword is collected made `sdram_rdata` correct at the acknowledgement while `ram_rdata` stayed stale because the output mux only sources the bus in `MAIN`, and adding that mux change as well still left the frames black and the reads one word stale, so neither moved the symptom and neither is retained. An assembly-path trace of `double_req`, `rom_rdata_new`, both raw SDRAM ports and both output ports showed the two builds delivering the identical correct word for the self-check read of `0x08000400` within their own windows, which is why the remaining divergence is now recorded as being in the latch or ordering of the double-request path rather than in the controller's data, and why no third patch was attempted on inference. One further instrument defect was fixed: `tools/check_cartread.py` recognises that a capture read while a run is still writing can end mid-line and skips the incomplete tail rather than aborting, which is the hazard TCL-023 records. Nothing was deployed and the Tang was not connected to; it remains in two-wire mode. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 31 and the existing reference records were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 32 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-two against the 100-entry limit.

#### Next Steps:

Find where the cartridge word is latched rather than whether it is wrong, because that question is now answered and quantified: instrument the double-request path's latch and ordering in both builds on the same address, tracing when `rom_rdata_new` is written relative to the acknowledgement and which cycle the output mux is sampled by the consumer, since the assembly trace showed both builds holding the right word at the self-check read and yet only one of them executes correctly. Do not re-derive the staleness itself and do not re-run the array-versus-controller A/B; both are measured, calibrated and recorded. Do not patch `sdram_gba` or `gba_memory` again until a trace explains why the two reverted attempts left the symptom unchanged, because both were motivated by a correct observation of the lag and both failed to move it, which means the lag is being absorbed somewhere not yet instrumented. Keep using `tools/check_cartread.py` for every cartridge-read claim from now on: it calibrates the sampling column against a build whose machine works and then judges the failing build with the same column, and a claim that has not been through it is the class of claim that cost this project three cycles. Every simulation that carries weight must run to 3000 million steps, since shorter runs do not reach the cartridge handover for this ROM under this controller. When the latch is settled, require the array-equivalent result before anything else: two colours at a mean of 85 for `test_logo` and the RetroRegen menu, and only then build a bitstream. The board is in two-wire mode and must be returned to one-wire before it can be flashed, the DMA `REQ1_START` defect remains open as its own change and is not on this path, and every hardware result remains attributable to the design only under BRD-019's unmeasured-`clk16`-pip caveat.

#### Files Modified:

- tools/sim/sim_main.cpp
- tools/check_cartread.py

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 33 COMMIT Unreleased 2026-11-08T12:27:26-07:00

#### Coming From:

Unreleased 295b769

#### Purpose:

Compare this port against the upstream GBATang checkout to find how upstream crosses the memory boundary this project is stuck at, and correct the record where that comparison showed a recorded claim to be wrong.

#### Outcome:

The comparison withdraws a claim this project has been resting on, and it is a claim I made rather than one the log already contained: the model does not reproduce the board's fault. Entries 31 and 32 and records BRD-030 and BRD-032 assert that the controller build's 18,375,892 cartridge fetch cycles are the same figure as the deployed board image, and they are not. BRD-028 is a simulation record; the board record is BRD-029, which measures 84 cartridge fetches on Super Mario Advance. The model therefore gets far further than the board, executing eighteen million cartridge fetches where the board executes eighty-four, so the Verilator reproduction is an instrument for the controller's logic and not a reproduction of the board's failure, and every conclusion that leaned on that equivalence has to be re-read accordingly. The upstream checkout at `/run/media/vash/GIT/tangcore/gbatang` is confirmed at the pinned `77fd0714a426ada76aee612f1192c704e89762e4`. Three structural differences were found in it. First, upstream never compiles `sdram_gba.v` under Verilator at all: `gbatang_top.sv` instantiates the real controller behind `ifndef VERILATOR` and the behavioural array behind `else`, so nand2mario's simulation has never crossed this boundary and the real controller has only ever run on vendor-built Gowin hardware; entry 14's changes exist because this port chose to compile the controller in simulation, which upstream deliberately does not. Second, `sdram_gba.v` is upstream's apart from slang-required cosmetic changes and the documented `[31:15]` to `[31:16]` repair, so its acknowledgement timing is upstream's and the port did not diverge there. Third, upstream generates all four GBA clocks from one `pll_33` at 27 MHz with `clk50` on `CLKOUT0`, `clk16` on `CLKOUT1`, `clk67` on `CLKOUT2` and `clk67_p` on `CLKOUT3`, while this port moved `clk67` to `CLKOUT1` and `clk16` to `CLKOUT2` on `pll16` and added `CLOCK_LOC "clk67" BUFG`, a reordering forced by apicula modelling plane pips only for `CLKOUT0` and `CLKOUT2` and not measured against upstream's assignment on hardware. One suspect was tested and eliminated rather than left as a theory: reverting the two entry-14 changes in `gba_memory.sv` to upstream's exact semantics, `REQ2_START: state <= REQ2_WAIT` and `cpu_en = state == REQ2_BRAM | state == REQ2_WAIT & sdram_ready`, made the design worse rather than better, giving a white field for all 889 frames with zero cartridge reads, so that change is load-bearing in this port and is not the cause. A fourth difference is recorded for the next cycle rather than acted on: upstream's `build.tcl` sets `GW5AST-LV138PG484AC1/I0` with `-device_version B` on every 138K board, while this port targets device revision C. Nothing was deployed and the Tang was not connected to, at the operator's instruction. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 32 and the existing reference records were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 33 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-three against the 100-entry limit.

#### Next Steps:

Test upstream's exact clock assignment rather than continuing to reason about it, because it is the one structural difference from upstream that sits on this boundary and that upstream validated on hardware: move `clk16` back to `CLKOUT1` and `clk67` back to `CLKOUT2` on the PLL, drop `CLOCK_LOC "clk67" BUFG`, and see whether the cartridge reads come back correct, noting that the vendor flow reaches the plane from `CLKOUT1` through the centre-bridge muxes TCL-018 describes and that this will therefore build only if the clock-plane gate is satisfied by those pips or the gate is run non-strict. Treat a simulation-only run as insufficient for this question, because the harness generates all clocks from one counter and so cannot show a phase relationship that the real PLL output assignment decides; if the simulation result is unchanged, that is evidence the difference is not phase and the test must move to a bitstream and the board. Correct the record first in any later cycle that cites the reproduction: BRD-030 and BRD-032 both overstate it, and BRD-028's 18,375,892 is a model figure with no board counterpart, the board's being BRD-029's 84. Do not re-test the entry-14 revert, which is measured and eliminated. Do not patch `sdram_gba` or `gba_memory` again without a trace that explains why the three reverted attempts left the symptom unchanged. Keep every cartridge-read claim going through `tools/check_cartread.py`, keep simulations that carry weight at 3000 million steps, and note that the board is in two-wire mode and must be returned to one-wire before it can be flashed.

#### Files Modified:

None.

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 34 COMMIT Unreleased 2026-11-08T13:37:54-07:00

#### Coming From:

Unreleased b984fd8

#### Purpose:

Narrow the cartridge read fault to a single stage by measuring the SDRAM bus itself, after the failure was localised to byte reads of one address.

#### Outcome:

The part, the bus and the model are exonerated, and the corruption is confined to a byte read's collection inside `sdram_gba`. Analysis of the existing 3000-million-step captures by access width showed the defect is narrow: on the array build every width is correct, and on the controller build word, low-halfword and high-halfword reads are all correct while byte reads fail, with 3,881 of 3,888 wrong reads landing on the single address `0x0800009c`. That address is the last word of the Nintendo logo, which the BIOS validates, so the machine is failing its logo check and retrying in a loop rather than executing the cartridge. The first divergence in the read stream is a dropped access rather than a wrong one: the array services `0x0800009d` once and the controller never services it at all. A bus-level trace was then built in `fpga/gba/diag/gba_sdram_rtl.v` with one counter in one clock domain, because two independently started counters in the controller and the model reported a spurious 16-cycle offset. It arms on a READ command to the word holding `0x0800009c` and prints every cycle afterwards. The result is textbook: the READ command appears with `dq=0000`, and exactly two clocks later `dq=d421`, which is the correct halfword for bytes `21 d4`, and it is then held stable for as long as the trace runs. So the part returns the right word at the cycle a CL=2 part should, the controller's collect point falls inside that window, the DQM handling is correct because the controller issues `dqm=00` on reads as the model's own comment claims, and the bus is clean. The corruption therefore happens between the bus and `cpu_rdata`, inside the collection stage, and only for the byte arms: `casez (ds_latch[0])` maps `4'b0001` to `{4{dq_in[7:0]}}`, and the trace earlier this cycle showed the collected byte as `0x75` where the bus was carrying `0x21`, a value that appears nowhere in the cartridge image. Three instrument traps were hit and cost time: a comment beginning with the word the simulator treats as a directive fails elaboration, which entry 10 already records; a tristate operand may not be compared outside the propagation graph, so DQ is now read through a wire and printed rather than compared; and a counter placed in a block that does not tick on every clock produces an offset that looks like a real timing defect. Nothing was deployed and the Tang was not connected to. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 33 and the existing reference records were not rewritten, confirmed the one new record carries a unique id and the canonical field order, and validated this entry as entry 34 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-four against the 100-entry limit.

#### Next Steps:

Instrument the byte arm's input rather than the bus, because every other candidate is now excluded by measurement and the remaining question is exactly what `dq_in` holds on the cycle the `4'b0001` arm samples it during a byte read at `0x0800009c`: print `dq_in`, `ds_latch[0]`, `addr_latch[0]` and `cpu_rdata[port[0]]` on the collect edge for that access, on the same bus-level counter, and do it for a byte read in the retry loop rather than the first logo read, since the failure count of 3,881 implies the loop is where the corruption is reproducible. If `dq_in` is correct at the collect edge the fault is in the arm or in what happens to `cpu_rdata` afterwards, and if it is wrong the fault is that the collect edge falls outside the part's driven window for back-to-back reads, which the model withdraws the bus for one cycle when a new READ arrives. Do not re-test the bus, the part, the DQM handling or the word and halfword paths; all are measured and recorded. Do not place counters in blocks that may not tick every clock, and do not compare tristate signals. Keep every cartridge-read claim going through `tools/check_cartread.py`, keep weight-bearing runs at 3000 million steps, and note the board remains in two-wire mode.

#### Files Modified:

None.

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 35 COMMIT Unreleased 2026-11-08T14:43:20-07:00

#### Coming From:

Unreleased 64d5d1c

#### Purpose:

Find why a byte read of the BIOS logo word returned a value that was on neither the bus nor in the ROM, after the part, the bus and the word paths were excluded by measurement.

#### Outcome:

The phase-four fault was a defect in this port's own pin-level SDRAM model, and correcting it removes the logo retry loop and makes 753 of 764 cartridge reads correct where 112 of 4,000 were before. The trace in `build/run_bt6` printed both dies unconditionally and showed the cause directly: at the cycle the selected die was driving `d421` for `0x0800009c`, the deselected die was simultaneously driving `f374` on the same `SDRAM_DQ` wire, and the bus settled on `f775`, whose low byte `0x75` is the value the BIOS logo check rejects. The wrapper wires die 0 to `nCS` and die 1 to `~nCS` onto one shared bus, and the model withdrew its drive only on `cs && command == CMD_RD`, so a deselected die that still had read data in its pipeline kept driving indefinitely and overrode the selected one. The defect can only exist in a model, because a real part tri-states whenever `nCS` is high regardless of pipeline state. The repair is one functional line, `if (command == CMD_RD)` in place of `if (cs && command == CMD_RD)`: `command` is decoded from RAS, CAS and WE, which every die sees, so gating the withdrawal on the command lets a deselected die release the bus. Gating on `cs` alone was tried first and is wrong for the opposite reason: the controller raises `nCS` immediately after the command while the data appears two clocks later, so a plain `cs` gate suppressed the word it was meant to drive and made the picture worse; that attempt was reverted before commit. Verified on a clean rebuild from the committed tree at 3000 million steps: `tools/check_cartread.py` reports 753 of 764 reads matching the ROM with `data_now`, against 112 of 4,000 before the change, and the 3,881-fold retry at `0x0800009c` is gone. The 11 remaining failures are all 32-bit word reads of the literal pool at `0x080002b0` through `0x080002e4`, which is the separate one-word lag BRD-032 records and is now the only read defect left. The picture is still white, so the machine still does not boot: the pool literals feed the entry code's own checks, and a stale literal there is enough to stop it. Nothing was deployed and the Tang was not connected to. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 34 and the existing reference records were not rewritten, confirmed the one new record carries a unique id and the canonical field order, and validated this entry as entry 35 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-five against the 100-entry limit.

#### Next Steps:

Attack the eleven remaining word-read failures, because they are now the only read defect and the machine's boot depends on them: the pool literals at `0x080002b0` to `0x080002e4` return the previous word, and the entry code loads `0x08000400`, `0x08000800` and `0x08000c00` from that pool before its self-checks. Instrument the same single-domain bus counter already proven in this cycle, but arm it on a 32-bit fetch rather than a byte read, and compare the two clocks by which the part presents data with the cycle the controller accepts a 32-bit request, since a 32-bit access is serviced as two halfwords and the acknowledgement for the first is issued before the second has been collected. Do not re-test the byte path, the two-die bus contention, the part, the DQM handling or the word-validity of individual halfwords; all are measured and recorded in BRD-034 and BRD-035. Do not gate a model's bus withdrawal on `cs` alone, which is measured wrong in this configuration and made the picture worse. Keep every cartridge-read claim going through `tools/check_cartread.py`, keep weight-bearing runs at 3000 million steps, and note that the board remains in two-wire mode. BRD-033 still governs what may be claimed: this is a model result, and the model does not reproduce the board's failure.

#### Files Modified:

- fpga/gba/diag/sdram_model.v

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 36 COMMIT Unreleased 2026-11-08T15:32:56-07:00

#### Coming From:

Unreleased cf240f8

#### Purpose:

Fix the one-word lag that remained after the model's two-die bus defect was corrected, and see whether the machine then boots through the real SDRAM controller.

#### Outcome:

The lag is fixed, every cartridge read is now correct, and the BIOS boot logo renders through the real controller for the first time in this port. The mechanism was measured on one clock domain before any code changed: instrumenting `sdram_gba`'s collect at `build/run_wt` showed a 32-bit read of `0x080002b0` collecting its low halfword with `hi=0`, which assigns `{stale_high, new_low}` and produced the intermediate `e1540400`, and collecting the high halfword four clocks later to produce the correct `08000400`. The acknowledgement was issued at the low-halfword slot, so the consumer latched the splice. The repair is two parts, applied together because each is insufficient alone: `sdram_gba.v` no longer acknowledges a 32-bit read at the low-halfword continuation and instead acknowledges it on the cycle the high halfword is collected, while `gba_memory.sv` now drives `rom_data` and `ram_rdata` from the controller on that acknowledgement cycle rather than only in `MAIN`. The earlier attempts at exactly this pair failed because they were measured through the corrupt bus of BRD-035, where a deselected die was overriding nearly every read; with that defect fixed the change takes effect and the result is categorical. `tools/check_cartread.py` reports 448 of 448 cartridge reads matching the ROM with zero failures, against 753 of 764 before this change and 112 of 4,000 before BRD-035. The picture confirms it: frames 300 to 700 render the GAME BOY wordmark and Nintendo mark with the logo's colour cycle animating, then the screen goes white at frame 800 where the BIOS hands over. The cartridge fetch count falls from 18,375,892 to 18, which is very close to the fifteen accesses BRD-023 records from the board with the same cartridge, so the model has moved from diverging wildly from the board to matching its stopping point. What has not changed is the destination: no `DISPCNT <= 0x0403` store is issued, the display is never enabled, and the cartridge's own checks are still not reached, so the machine does not boot. Nothing was deployed and the Tang was not connected to, at the operator's instruction; note that `sdram_model.v` and `gba_sdram_rtl.v` are never compiled into a bitstream, so no board image was possible from this change and the board session the operator offered would have tested nothing. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 35 and the existing reference records were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 36 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-six against the 100-entry limit.

#### Next Steps:

Establish whether the model now reproduces the board, because the fetch count dropping from eighteen million to eighteen in step with BRD-023's fifteen changes what this instrument can be used for: run the same cartridge on the board and compare the two read streams address by address, since BRD-033's claim that the model is not the board's failure was written when the model was reading garbage and may now be too strong. Then attack the stopping point, which is shared with the board and is therefore worth solving once: the cartridge's first store `DISPCNT <= 0x0000` lands, the entry code then loads its literal pool and writes `0x0403` to `DISPCNT`, and that second store is never issued in either the model or on the board. Now that reads are correct, find the last address the CPU fetches and what it does with it, because the earlier belief that the cartridge wedges on stale literals is no longer available as an explanation. Do not re-test the byte path, the two-die contention, the DQM handling or the read timing; all are measured and recorded, and every cartridge read now matches the ROM. Keep every read claim going through `tools/check_cartread.py` and every weight-bearing run at 3000 million steps. Do not attempt a board build from this tree expecting a change: the files fixed here are simulation-only, and a bitstream from it is identical to the last one flashed.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/memory/sdram_gba.v

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 37 COMMIT Unreleased 2026-11-08T17:50:27-07:00

#### Coming From:

Unreleased 26069d6

#### Purpose:

Withdraw entry 36's claim that the acknowledgement change fixed the cartridge reads, after isolating that the same change cost the machine its reach, and restore the last known-honest source state.

#### Outcome:

Entry 36's result was produced by a change that broke something else, and it is withdrawn. Reverting the source half of that commit while keeping its log history in place restores a tree whose RTL is byte-identical to `cf240f8`, confirmed with `git diff cf240f8 -- fpga/gba/src/memory/` returning nothing, and the restored baseline reproduces exactly: `test_logo` under `-DTINYGBA_SDRAM_RTL` at 3000 million steps reaches `0x080002e4`, issues the literal-pool load at `0x080002b0`, and `tools/check_cartread.py` reports 451 of 462 reads matching the ROM with 11 failures, all 32-bit word reads of the pool from `0x080002b0` to `0x080002e4`. The isolation was measured rather than argued, by building four configurations from the same tree. The model die-selection fix alone, which is `cf240f8`, reaches `0x080002e4` with the pool load issued and 11 bad reads. Adding the controller acknowledgement change with the output mux untouched leaves those numbers unchanged at 451 of 462, so that change moves nothing measurable on its own. Adding the wide mux that drove both output ports on the acknowledgement cycle cut reach to `0x080000de` and removed the pool load entirely, while every read it did perform was correct, which is the 448-of-448 figure entry 36 reported as a fix. Narrowing that mux to the data port restored reach but returned the 11 failures, and tying it to `cpu_en` instead cut reach again. The conclusion is that entry 36 measured a machine that had stopped earlier over a set of reads that happened to be clean, and described the truncation as a repair; the BIOS logo that rendered in that run rendered because the fetch path was still working at that point, not because the read timing had been corrected. What stands from the cycle is `cf240f8`, the pin-level model's deselected-die bus defect, which took reads from 112 of 4,000 correct to 753 of 764 and removed a 3,881-fold retry loop at `0x0800009c`, and which was verified before the acknowledgement change existed. The eleven literal-pool word reads still return the previous word and their cause is not established. Nothing was deployed and the Tang was not connected to; no bitstream was affected either way, because the files in question are simulation-only per TCL-026. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 36 were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 37 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-seven against the 100-entry limit.

#### Next Steps:

Establish what the eleven pool word reads actually do before changing any timing again, because three attempts at a timing change have now been made and each was measured against a different confound: the first two ran through the corrupt bus of BRD-035, and the third was reported as a fix while the output mux was silently truncating the fetch path. The specific measurement that is missing is whether the pool word reads are a timing defect at all, given that the same code path returns correct words for the header and logo reads in the same run: compare the state machine trace for a pool access against a header access that succeeds, on the same single bus-level counter, and look for a difference in which port, which state, or which acknowledgement the two take rather than assuming they take the same one. Do not re-test the byte path, the two-die contention or the DQM handling; all are measured and recorded. Do not widen an output mux to cover an acknowledgement cycle without first checking that instruction fetches still work, which is the specific mistake that produced this entry. Treat every read claim through `tools/check_cartread.py` and every weight-bearing run at 3000 million steps, and require both properties together before reporting a fix: reach equal to the previous baseline and reads correct, since a run that is correct only because it stopped earlier is not progress. BRD-033 still governs what may be claimed about the board, the board remains in two-wire mode, and the DMA `REQ1_START` defect remains open and untouched.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/memory/sdram_gba.v

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 38 COMMIT Unreleased 2026-11-08T19:53:51-07:00

#### Coming From:

Unreleased 048e441

#### Purpose:

Test whether the eleven remaining literal-pool word reads are an artefact of the simulator's clk16/clk67 phase relationship rather than a property of the logic, by sweeping all twelve phase offsets the harness supports.

#### Outcome:

The phase hypothesis is dead: all twelve offsets produce identical results, so the defect is a property of the logic and not of the clock relationship the simulator happens to impose. `TINYGBA_CLK16_SHIFT` was swept across all twelve values with `test_logo` under `-DTINYGBA_SDRAM_RTL` at 3000 million steps, and `tools/score_phases.py` reports 864 reads correct, 11 failed and a highest cartridge address of `0x080002e4` for every one of the twelve, with the cartridge fetch cycle counter reading 149,742,181 in all of them. The baseline reproduces exactly at phase 0, which is the default, and each run printed its own `Total frames` summary, so the result rests on twelve completed runs rather than on partially written logs. That last point cost a cycle: an earlier attempt launched the sweep in the background inside a shell that then exited, the children died with it, and their truncated logs were read as data before anyone noticed that none of them contained a summary line, which is the same failure mode entry 37 records in a different form and the reason `tools/score_phases.py` prints reach beside accuracy. The sweep was rerun with `setsid` so the processes detach from the launching shell, and completion was confirmed by counting summary lines before a single number was read. This closes the phase question that entry 10 opened and entry 19's twelve-offset sweep of a standalone raster model did not answer for the memory path: the clk16-to-clk67 relationship has no effect on this defect, so it is deterministic logic in `sdram_gba`'s collection or in `gba_memory`'s assembly, both of which are simulated with exact integer ratios in every phase. What the eleven failures are, precisely, is unchanged from the previous cycle: they are exclusively 32-bit word reads, 11 of 532, every narrower width being clean, and each returns the word belonging to the previous transaction, with repeated reads of the same address converging on the correct value. Nothing was deployed and the Tang was not connected to; no bitstream is affected because these files are simulation-only per TCL-026. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 37 were not rewritten, confirmed the two new records carry unique ids and the canonical field order, and validated this entry as entry 38 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-eight against the 100-entry limit.

#### Next Steps:

Stop looking at clocks and read the collection path as arithmetic, because phase is now excluded across all twelve offsets and the defect is therefore deterministic: the eleven failures are the first 32-bit word read of each distinct pool address, each returning its predecessor, and repeated reads of the same address converge, which is the exact signature of `cpu_rdata` being consumed while it still holds `{old_high_halfword, new_low_halfword}` from the low-halfword collect. The missing measurement is not another timing change but a trace of when `cpu_rdata` is written relative to when the consumer latches it, for one failing pool read and one succeeding header read in the same run, since those two differ in outcome and the earlier assumption that they take the same path has now been wrong three times. Do not re-run a phase sweep, do not widen an output mux without checking instruction fetches still work, and do not attempt another acknowledgement change until that trace exists. Note that `test_logo`'s entry code loads its pool through `ldr Rd,[pc,#imm]`, which is a 32-bit data read on the same port as every other data access, so if the header reads succeed at 16 bits while the pool reads fail at 32, the distinguishing variable is width and not address. Keep every read claim going through `tools/check_cartread.py`, report reach and accuracy together per TCL-027, and confirm a run printed its summary before reading any number out of it. The board remains in two-wire mode, BRD-033 still governs what may be claimed about it, and the DMA `REQ1_START` defect remains open and untouched.

#### Files Modified:

- tools/score_phases.py

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 39 COMMIT Unreleased 2026-11-08T20:34:30-07:00

#### Coming From:

Unreleased c10b594

#### Purpose:

Trace the consumer side of a failing literal-pool word read against a succeeding one in a single run, to find why three acknowledgement changes moved nothing.

#### Outcome:

The trace explains all three failed attempts at once, and the reason is a misidentification of the signal that matters. Recording the memory FSM's consumer side across the whole literal-pool block shows the acknowledgement and the complete word landing on different cycles, and shows that moving the acknowledgement cannot fix it because the acknowledgement is not the signal the CPU acts on. The window starts at the first 32-bit read of `0x080002b0` and covers 140 consecutive cycles including four pool reads and the first cartridge text read. Each 32-bit read takes four cycles through `MAIN`, `REQ1_WAIT`, `REQ2_START` and `REQ2_WAIT`, and at the `REQ2_WAIT` cycle where `cpu_en` is high the mux is presenting the buffered word from the previous transaction while the controller is presenting the low halfword splice: for `0x080002b0` at cycle 76106114 the state is `REQ2_WAIT`, `cpu_en` is 1, `sdram_rdata` holds `e1540400` and `ram_rdata` holds `e154e154`, and the correct `08000400` appears only at the next cycle, 76106115, when the FSM has returned to `MAIN`, the mux sources `sdram_rdata` correctly, and `cpu_en` is 0. The same shape repeats on every pool read in the window. The decisive detail is in the enable decode: `cpu_en` for a concurrent rom-and-ram access is `state == REQ2_BRAM | (state == REQ2_START | state == REQ2_WAIT) & sdram_ready`, which references the state machine and the controller's ready pulse and does not reference `cpu_ready` at all. Every attempt in this session moved `cpu_ready` in `sdram_gba`, which is an input to that expression only through `sdram_ready` in two states, so moving it cannot move the cycle on which `cpu_en` asserts while the state machine is already returning to `MAIN`. That is why the acknowledgement change left the eleven failures untouched, why widening the output mux fixed the reads by breaking fetches, and why the `cpu_en`-tied mux truncated the machine: each was aimed at the wrong signal. No source change is made this cycle; the instrumentation was reverted and the tree is clean at `c10b594`. The phase sweep from the previous cycle stands and is what makes this diagnosis usable, since the defect is deterministic and therefore has a single cause rather than a phase-dependent one. Nothing was deployed and the Tang was not connected to. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 38 were not rewritten, confirmed the one new record carries a unique id and the canonical field order, and validated this entry as entry 39 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of thirty-nine against the 100-entry limit.

#### Next Steps:

Fix the enable rather than the acknowledgement, because the trace shows the data is complete and the mux is correct on the cycle after the controller's ready pulse, and the only thing missing there is `cpu_en`. The candidate is to register `sdram_ready` and add a term to the concurrent rom-and-ram branch of `cpu_en` that fires in `MAIN` on the cycle after a 32-bit RAM read completed, so the CPU consumes when `ram_rdata` is sourced from `sdram_rdata` instead of from the buffer; this must be written to apply only to 32-bit accesses, since the trace shows 16-bit reads are collected in one pass and already correct. Before building it, trace the same window for a 16-bit data read to confirm it completes in one collect and would be broken by an unconditional delay, because the eleven failures are exclusively 32-bit and the fix must not move the width that works. Then require both properties together: reach `0x080002e4` or better and the eleven failures gone, measured with `tools/check_cartread.py` and reported with reach per TCL-027. Do not move `cpu_ready` again to try to achieve this, which is measured three times now to have no effect on this path. Do not widen an output mux without checking instruction fetches still work, and confirm every run printed its summary before reading a number from it. Keep weight-bearing runs at 3000 million steps and launch long runs with `setsid` per TCL-028. The board remains in two-wire mode, BRD-033 still governs what may be claimed about it, and the DMA `REQ1_START` defect remains open and untouched.

#### Files Modified:

None.

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 40 COMMIT Unreleased 2026-11-08T21:08:59-07:00

#### Coming From:

Unreleased e1c555f

#### Purpose:

Compare a 16-bit cartridge data read against the failing 32-bit case before attempting the repair that entry 39 proposed, so the width that already works could be shown to be undisturbed.

#### Outcome:

The comparison was not obtained, and the reason is worth recording because it is an instrument-selection fault rather than a machine result. A consumer-side trace armed on a 16-bit cartridge data read and ran the full 3000 million steps, confirmed by its `Total frames` summary before any line was read, and it captured a single window of 24 cycles. The window is at `0x08008c20`, which is offset 35,872 into a 4,096-byte cartridge, so it is an out-of-range access rather than a real cartridge read: the trace's arming condition tested `ram_be == 4'b0011` and an address at or above `0x02b0` but never checked that the address was inside the image, and the first 16-bit data access the CPU made happened to be beyond it. What the window does show is consistent with the 32-bit case and not informative about it: at the acknowledgement cycle the state is `REQ2_START`, `cpu_en` is high, `ram_rdata` presents the buffered value and `sdram_rdata` already holds fresh data, which is the same shape as the failing 32-bit read. Because the access is out of range its returned value is meaningless either way, so it cannot distinguish a correct 16-bit path from an incorrect one, and the lead recorded in BRD-039 remains untested for the 16-bit half. No source change is made this cycle, the instrumentation was reverted, and the tree is clean at `e1c555f`. Two things are worth carrying: the `check_cartread.py` scoring already shows 16-bit halves as correct in bulk, with 55 low halfwords and 55 high halfwords matching and no failures at either, so the comparison that the repair depends on is available from the existing capture and does not need a new trace at all; and the trace as built would arm on any 16-bit data access above `0x02b0` regardless of whether it lies inside the cartridge, which is the specific mistake to correct if it is ever rebuilt. Nothing was deployed and the Tang was not connected to. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, checked that entries 1 to 39 were not rewritten, and validated this entry as entry 40 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of forty against the 100-entry limit.

#### Next Steps:

Do not rebuild this trace: the comparison it was meant to supply already exists in the scored captures, where 16-bit low and high halves match the ROM 55 times each with zero failures against the 32-bit path's 11 failures out of 532, so the width asymmetry is already measured and the repair's safety requirement is satisfied without another run. Proceed instead to the repair proposed in entry 39, which is to register `sdram_ready` and add a `MAIN`-state term to the concurrent rom-and-ram branch of `cpu_en` that fires on the cycle after a 32-bit RAM read completes, applying only when the access is 32-bit so the 16-bit path is untouched, and then require both properties together: reach at least `0x080002e4` and the eleven failures gone. If a trace is rebuilt for any reason, arm it on an address inside the cartridge, since the condition used here accepted `0x08008c20` in a 4 KiB image and produced a window that could not be interpreted. Keep every read claim going through `tools/check_cartread.py`, report reach and accuracy together per TCL-027, confirm a run printed its summary before reading a number from it, and launch long runs with `setsid` per TCL-028. The board remains in two-wire mode, BRD-033 still governs what may be claimed about it, and the DMA `REQ1_START` defect remains open and untouched.

#### Files Modified:

None.

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 41 COMMIT Unreleased 2026-11-08T22:35:00-07:00

#### Coming From:

Unreleased cb04146

#### Purpose:

Measure on the board, with one stall-tail instrument, where `test_logo.gba` stops and what state the memory controller and DMA are in when Super Mario Advance stops, instead of continuing to chase model-only literal-pool failures.

#### Outcome:

A new define, `TINYGBA_STALLTRACE`, layered on `TINYGBA_FETCHTRACE` (decoder layout `v5`), records the last sixteen completed CPU memory cycles (`(rom_en | ram_cen) & cpu_en & ~halt`) in a ring and freezes it, together with a snapshot of the `gba_memory` FSM state, `dma_on`, `dma_ena`, `dma_addr`, `rom_en`, `ram_cen`, `cpu_en`, `halt`, `sdram_ready` pulses since the last completed cycle and since the last state change, clk16 spent in the current state, DMA beat counts and the DMA arbiter's `debug_dma`, either when no cycle completes for 2^22 clk16 (0.25 s, nearly thirteen times the longest gap then measured) or 2^27 clk16 (8 s) after release, whichever comes first; the longest pre-freeze gap is kept so the margin is measured, and page 3 shows live counters that keep running after the freeze. The MMIO write ring is compiled out under the new define, and `gba_memory.sv` gains only a STALLTRACE-guarded `stl_mem_state` output port. `tools/decode_fetchtrace.py` decodes `v5`, drops the first frame after each page change (TCL-019), takes a per-word majority over the remaining frames, checks the `0x57A1` marker and compares every cartridge fetch against the ROM; it was validated on synthetic frames before any capture was read. `check_ring_width.py` passed, all 2,048 ring bits and every counter and snapshot flop were confirmed in `build/stl_s1/tinygba.json` as `DFFRE` with logic-driven D or CE (the only GND bits are design constants: address bit 0, `f_mem[4:3]` and the unused `debug_dma[7]`), and the default and FETCHTRACE-only configurations still elaborate. Seeds 2 to 5 were placed from the seed-1 netlist of the same tree and defines; seeds 1 to 4 failed the clock-plane gate with `clk67` on general routing, and seed 5 (`build/stl_s5`, `.fs` SHA-256 `04dc4311896e5aab122f22b39d38c00f027fa6ae60948eb80301d2abef861aa8`) passed the clock-plane gate non-strictly, met timing with zero hold violations under the documented clk67 multicycle allowance, and was deployed over JTAG. Three loads of each cartridge, each freshly flashed, decoded identically to the cycle (`build/stl_cap/logo1..3/decode.txt`, `build/stl_cap/sma1..3/decode.txt`). Neither machine stops: in every load the stall trigger never fired, the 8-second time trigger did, and the live counters showed tens of millions of further completed cycles. `test_logo.gba` completes 26,863,572 cycles before the freeze, its longest gap is 276,009 clk16, the BIOS sound DMA finished at 29,352 beats and is idle, and the tail is the cartridge's `delay` loop at `0x080002A4` `subs r4, r4, #1`, `0x080002A8` `bne delay` and the prefetched `0x080002AC` `b blink`, every fetch matching the ROM; that loop lies after the `DISPCNT <= 0x0403` store, so on this image the CPU executes past the point BRD-023 and BRD-025 inferred it never reached, though whether the store lands in `DISPCNT` is not measured here (BRD-040). Super Mario Advance completes 17,459,560 cycles before the freeze, its longest gap is 327,688 clk16, and at the freeze the FSM is in `MAIN` with `dma_on` low, every DMA channel idle and no `sdram_ready` pending, while the tail is the BIOS sound mixer loop at `0x0000207C` to `0x000020CC` and `0x00002004` to `0x0000200C`, mixing bytes into IWRAM `0x03004532` and `0x03003F02`, and FIFO-B sound DMA from IWRAM keeps running after the freeze (BRD-041). The `REQ1_START` DMA lead is therefore not observed on the board: no DMA deadlock and no CPU stall occurs in either cartridge within about twenty seconds of release. A static reading of Super Mario Advance's `crt0`, not a measurement, shows it installing an ARM IRQ handler at `0x080000FC` in cartridge ROM through `0x03007FFC` and then calling Thumb `AgbMain` at `0x08000280`, so the board's frozen count of 84 cartridge fetches with the CPU alive in BIOS code means the game's own handler is never entered; that, the coincidence of `0x080000FC` with the DMA3 source recorded in BRD-025, and sound DMA running under the game but not under `test_logo.gba` are recorded as a lead in BRD-042. No fix was attempted, the entries 39 and 40 `cpu_en` repair was not applied, and nothing about the Verilator model is claimed (BRD-033). The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 40 were not rewritten, and validated this entry as entry 41 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of forty-one against the 100-entry limit.

#### Next Steps:

The plan's premise that both cartridges stop is falsified on this image, so the next instrument should capture transitions rather than a stall tail, and it needs approval before it is built: keep the `v5` ring but freeze it on control-flow events instead of time, either sixteen cycles after the last cartridge fetch, recognised as the first BIOS-region fetch that follows a cartridge fetch with no cartridge fetch for 2^22 clk16 afterwards, or by recording only fetches whose region differs from the previous fetch together with every fetch of the `0x08` and `0x18` exception vectors and the word the BIOS IRQ stub reads from `0x03FFFFFC`. That would show how Super Mario Advance leaves the cartridge for the BIOS, whether an IRQ is ever dispatched through its handler pointer, and whether the BRD-025 DMA3 entry is really the `crt0` store of `0x080000FC`. For `test_logo.gba`, an overlay-off image of the current tree would show directly whether the blink square is drawn now that the CPU is measured inside the blink loop. Keep the `cpu_en` repair parked, since the board shows no read fault and no stall for it to address, keep the `REQ1_START` DMA defect recorded as unobserved rather than fixed, and use `build/stl_s5` as the deployed reference for this instrument.

#### Files Modified:

- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/memory/gba_memory.sv
- tools/decode_fetchtrace.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---

## 42 COMMIT Unreleased 2026-11-12T22:10:00-07:00

#### Coming From:

Unreleased 2574ec9

#### Purpose:

Build the current tree as an overlay-free production image at a clean placement seed and put it on the board with `test_logo.gba`, to close the question BRD-040 left open by measuring whether the cartridge draws its own picture now that the CPU is known to execute past the `DISPCNT <= 0x0403` store.

#### Outcome:

Stage 1 was a build-only cycle with no source change, and it answers its question negatively. The tree at `2574ec9` was synthesised once with `TINYGBA_OVERLAY_OFF` and the official BIOS via `TINYGBA_BIOS_HEX` pointing at `build/test/official_bios.hex`, matching every prior board image rather than the production default `gba_bios_cultofgba.hex`, and that netlist was placed across eight seeds. Seed 1 aborted with the BRD-024 route error, `Net hclk5 has no route to the FCLK of video.hdmi.serializer.gwSer0 (sink wire X181Y102/FCLKA)`, which is the second seed-1 batch in a row to fail exactly there and is now a reproducible property of seed 1 rather than a coincidence. Seeds 2, 3 and 5 passed every gate and packed; seeds 4 and 6 through 8 were still routing when the cycle closed and were stopped. The deployed image is seed 3, `build/ovb_s3/tinygba.fs` SHA-256 `c0a890d7f47684d753a264e8ae0e3fed093d79e5ac7e85f6e9420b22f1a2161e` with `.bin` `45840d3638a78fe7ee2e2d4b586b534b43cfde5d582282720d30707ffb0597b2`, 11,495 flip-flops and 148 block RAM, zero hold violations, `clk16` 20.111 against 16.750, `clk50` 83.542 against 50.251, `clk67` 40.987 against 67.002 under the documented GBATang four-cycle allowance with a 24.40 ns worst path against a 59.70 ns budget, `hclk` 88.082 against 74.250, cross-domain paths 38.28 and 36.11 ns, and `clk67` on both measured-good spines `SPINE16/TOP0` and `SPINE25/TOP1`, while `clk16` sits on seven `*/TOP3` pips this board has never measured, so BRD-019 still bounds how this result may be worded. The define provably reached the compiler and the machine proves it again on screen: with `test_logo.gba` loaded over `/dev/ttyUSB1` (header `TINYGBATEST1`, Nintendo logo present, byte `$B2` `$96`, complement check `$40`), the official BIOS intro plays and the operator watched it load, so the 960-pixel OSD window that hid the field in entries 3 and 24 is conclusively not what was hiding the picture. After the intro the field holds solid white and nothing else appears. Two freshly loaded sessions were captured, seven frames over eight seconds and six frames over ten seconds, and every frame is a uniformly white active area with the pillarbox grey as the only other colour in the image: there is no green or red field, which is what `test_logo` paints from its own eight-check result, no yellow column, which would count out a failing check bit, and no toggling square. A white field is therefore a positive reading rather than an absence, because the cartridge is a self-describing instrument, and it says the cartridge's `DISPCNT <= 0x0403` store has not taken effect and the display is still in forced blank, whose backdrop is white. That reproduces entry 24's `fix_ov_s1` result on a tree that now carries the SDRAM model repairs, the GPU fixes and entry 41's stall instrument, and the honest summary is that the picture has not moved in eight entries. What this cycle narrows is the question rather than the fault: BRD-040 measured the CPU executing the blink loop past the store on `stl_s5`, and this image shows the store's effect absent, so the remaining candidates are that the store is issued and lost between the CPU and the `DISPCNT` register or that it is never issued, and because this image is uninstrumented no CPU state is claimed from it. Two procedure faults cost time and are recorded rather than glossed: a first capture attempt left an `ffmpeg` holding `/dev/video0` so the next one returned `Device or resource busy`, which must be checked before the board is blamed, and the deploy set's first checksum verification ran from the wrong directory and reported a false failure before the same hashes verified clean in place. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 41 were not rewritten, and validated this entry as entry 42 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set, `None.` for Files Modified because no engineering file changed, and a count of forty-two against the 100-entry limit.

#### Next Steps:

Build the Stage 2 instrument, which is the one entry 41 specified and the only thing that can now separate the two remaining candidates: keep the `v5` ring but freeze it on control flow instead of time, arming on the first BIOS-region fetch that follows a cartridge fetch, and make sticky the exception-vector fetches at `0x00000008`, `0x00000018` and `0x0000001C`, the word the BIOS IRQ stub reads from `0x03FFFFFC`, whether `0x080000FC` is ever fetched, whether `DISPCNT` ever receives `0x0403` beside the drawer's live register copy, and the existing cartridge, BIOS and IWRAM counters, which together test BRD-042's lead directly instead of by inference and at the same time show where the `0x0403` store stops if it is being issued. That change needs approval before it is built because it touches `gbatang_top.sv` and `gba2hdmi.sv`, and it should be built from a fresh build directory because a re-synthesis into an existing one reuses the cached netlist. Do not reuse seed 1, which has now cost two builds to the same `hclk5` route abort, and prefer seeds 2, 3 or 5, which were clean here. Before any board result from the new instrument is worded as a statement about the design, settle the clock plan measurement BRD-019 still holds open, since `clk16` has never been on a pip this board has measured. Keep every cartridge-read claim going through `tools/check_cartread.py` with reach reported beside accuracy per TCL-027, keep weight-bearing simulations at 3000 million steps launched with `setsid` per TCL-028, do not arm a trace without bounding it to the region and image per TCL-029, leave the parked `cpu_en` repair parked because the board shows no read fault and no stall for it to address, and note that a register-parity baseline for `TINYGBA_OVERLAY_OFF` still does not exist and should be recorded only from a build whose behaviour is understood.

#### Files Modified:

None.

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: FAIL

---

## 43 COMMIT Unreleased 2026-11-12T23:06:00-07:00

#### Coming From:

Unreleased 8549292

#### Purpose:

Build the control-flow instrument entry 41 specified and entry 42 approved, and use it to place the white screen that eight cycles of display-side instruments could not explain.

#### Outcome:

The white screen is explained, and it is a wrong word on the bus rather than anything after it. Layout `v6` keeps the `v5` stall ring and adds two things to `TINYGBA_STALLTRACE`: a third freeze cause, the first BIOS-region instruction fetch that follows a cartridge fetch, and sixteen new sticky records covering the handover, the exception vectors, the handler pointer the BIOS IRQ stub reads from `0x03FFFFFC`, whether `0x080000FC` is ever fetched, and both ends of the DISPCNT chain, the data carried by each write to `0x04000000` and the value the GPU drawer actually registers. Every new record is sticky, because a live sample of a cycling register aliases across frames and made entry 21's reading unsafe. Two instrument defects were found and fixed before any capture was read: `tools/check_ring_width.py` covered only `+:` part-select packings and none of the readout muxes' plain assignments, and extending it to those forms plus whole-identifier assignments found a real pre-existing slip, the page-1 status word packing 33 bits into 32, which was harmless only because the bit dropped was padding. The gate now checks 51 such assignments where it checked none, and both new checks were mutation-tested. My own first draft also had DISPCNT `0x0000` decoded as `7'b0000000` when forced blank is active high and the correct comparison is `7'b0000001`, which would have measured nothing; it was corrected before the netlist was built. The netlist needed a fresh build directory and 583,265 iterations at seed 9, the only seed of eight to close: seeds 1, 2, 3 and 5 all aborted with BRD-024's `Net hclk5 has no route to the FCLK of video.hdmi.serializer.gwSer0`, which is now recorded as a seed property rather than a run of bad luck, and seeds 4, 6, 7 and 8 were still routing at 15,000 to 43,000 unrouted nets when seed 9 finished and were stopped. `build/v6_s9` passed every gate with zero hold violations, `clk16` 19.543, `clk50` 55.559, `clk67` 32.631 under the documented GBATang multicycle allowance, `hclk` 102.459 MHz and cross-domain paths at 42.66 and 39.40 ns against 59.70, `clk67` on both measured-good spines, and all sixteen new registers were confirmed present and driven in the routed netlist with the flip-flop count rising 116 against an expected 115. Deployed one-wire as `.fs` SHA-256 `71324ac4442c8ac01a80efbaaf1f1c81c2bed7ea3e4a94b88dc0a63b13fd36d6` and read with two cartridges. With `test_logo.gba`, five page-3 frames over eight seconds agree: 213 writes to `0x04000000`, none of them carrying `0x0403`, the last carrying `0xFFE0`, and the drawer holding forced blank with BG0..BG3 set, with `0x0000` seen, `0x0403` never seen and `0x1F80` seen. So the cartridge's `strh` is issued, the CPU is past it per BRD-040, and the value on the bus is `0xFFE0`, which sets exactly the forced-blank and BG bits observed and paints the white backdrop entry 42 saw; the word immediately before `0x0403` in the cartridge's literal pool is `0x0000FFE0`, so a literal load returning its predecessor explains it, and that is the one-word lag of BRD-038 and BRD-039 arriving on the board at last, recorded as BRD-044 and left as a lead because the pool read itself was not captured. With Super Mario Advance the stall trigger fired instead of the time trigger: after 9,309,508 completed cycles the machine wedged in `REQ1_WAIT` with `dma_on` and `dma_ena` high, `cpu_en` low, `dma_addr=0x03001190`, the arbiter on channel 3 and zero `sdram_ready` pulses in a saturated 65,535 clk16 state, and three frames over six seconds all read zero completed cycles after the freeze, which makes the `REQ1_START` deadlock entry 14 read in the source and BRD-041 reported as unobserved a measured board fault on this load, and establishes the machine is bimodal across loads rather than contradicting BRD-041's three loads. The same build never fetches `0x080000FC` under the game, never transitions from cartridge to BIOS after handover, and reads `0x00000000` from `0x03FFFFFC`, which closes both of BRD-042's alternatives with measurement while noting the pointer reads happen during the intro before handover. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 42 were not rewritten, confirmed the five new records carry unique ids and the canonical field order, and validated this entry as entry 43 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of forty-three against the 100-entry limit.

#### Next Steps:

Capture the literal read itself, because BRD-044 is the whole remaining distance and it is one measurement away: arm the existing `v5` tail ring on a 32-bit data read of `0x080002E0` with the region nibble and image bound checked per TCL-029, keep the `v6` controls, rebuild as layout `v7` and read whether the returned word is `0x00000403` or `0x0000FFE0`, since the former kills the lead and moves the search back to the address path while the latter confirms the lag on the board and makes the parked `cpu_en` repair of entries 39 and 40 the next change -- and that repair must then be required to show both properties together, the white field gone and reach undiminished, per TCL-027. Treat BRD-045 as the second fault and do not conflate the two: the DMA deadlock stops Super Mario Advance in the first second on some loads and not others, so any run must take at least three loads and report which behaviour appeared, and the `REQ1_START` wait on `sdram_ready` is a separate change from the read lag even though both end in the same white screen. Do not rebuild seed 1, 2, 3 or 5 for this netlist; seed 9 is the one recorded clean placement and seeds 4, 6, 7 and 8 never converged. Keep `tools/check_ring_width.py`'s new plain and identifier checks in the build, since they found a real slip on their first run, and re-read any new readout word against them because a truncated packing decodes to plausible values. BRD-019 still governs wording, since `clk16` sat on six `*/TOP3` pips this board has never measured on this placement, and the clock-plan measurement that would close it remains undone.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- tools/check_ring_width.py
- tools/decode_fetchtrace.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---

## 44 COMMIT Unreleased 2026-11-13T00:52:00-07:00

#### Coming From:

Unreleased 413a0ba

#### Purpose:

Build layout `v7` to capture the literal-pool read at `0x080002E0` and settle whether the one-word lag of BRD-044 is what put `0xFFE0` in DISPCNT, then stop at the operator's request for a handoff with the build and the measurement state recorded rather than interpreted.

#### Outcome:

The instrument is built and deployed and its result is deliberately unread, because the placement that carried it behaved unlike every prior image and no clean alternative placement was available before the session ended. Layout `v7` adds a fourth freeze cause, the first completed 32-bit cartridge data read of `0x080002E0` with the region nibble and an in-image offset both checked per TCL-029, plus raw records of the words returned for `0x080002DC`, `0x080002E0` and `0x080002E4` and a two-deep history of 32-bit cartridge data reads, all scored against the cartridge image by the host decoder rather than against constants compiled into the instrument, following TCL-024. `tools/check_ring_width.py` refused two of my own packing mistakes on the way, a 33-bit cause field and a 45-bit flag word, and the decoder's field order for the new words was corrected after a round-trip test showed flags and byte enables in the wrong positions; both verdicts it can reach, confirmed and refuted, were exercised against synthetic words before any capture was read. Synthesis needed three attempts: the first two ran from source that was then edited, and re-synthesising into an existing directory would have reused the cached netlist, so each was discarded and the build that shipped was made from the committed source at 23:22 with its netlist written at 23:36. Of eight seeds, seed 9 was again the only one to converge, at 589,915 iterations against 583,265 for the previous netlist, and it passed every gate with zero hold violations, `clk16` 19.529, `clk50` 80.880, `clk67` 31.398 under the documented GBATang allowance, `hclk` 91.819 MHz and cross-domain paths at 44.39 and 40.29 ns against 59.70; seeds 10 to 16 were relaunched after seed 9 was first read and were still routing when the build was killed at the operator's request. `build/v7_s9` (`.fs` SHA-256 `0d3d58da1d022a1cdf1e5f918c5ec83065aac6d3cace16a5362a00374a1aad86`) then behaved unlike any prior image: three fresh loads all read 32,192,194 completed cycles before the freeze, 211 writes to `0x04000000` with the last carrying `0x0080` and none carrying `0xFFE0` or `0x0403`, and a tail ring showing the CPU looping at `0x0800020C` to `0x0800025C` instead of the blink loop that `stl_s5` and `v6_s9` both measured, with the pool-read arms never firing. Five page-0 frames agreed field for field, so the capture was stable rather than torn, and scoring those fetches against the cartridge image showed five of nine differing, every one of them by byte 2 being incremented by one, which is not a corruption pattern any previously recorded fault produces. Re-flashing `build/deploy_v6/tinygba.fs` on the same board with the same cartridge restored the correct blink loop and byte-exact words, so the difference is the bitstream and not the board, the loader or the capture path. The one build-visible difference found is that `clk67` on `v7_s9` is carried by `SPINE0/TOP0`, which this board has never measured, while the working control's `clk67` sits only on `SPINE16/TOP0` and `SPINE25/TOP1`, both measured good, so the result is recorded as BRD-047 in lead status and the v7 reading is withdrawn rather than interpreted: it can neither confirm nor refute BRD-044, and its absent pool reads describe a run that was not executing the cartridge correctly. The board was left running `build/deploy_v6` with `test_logo.gba` loaded, since that image is measured working. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 43 were not rewritten, confirmed the new record carries a unique id and the canonical field order, and validated this entry as entry 44 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of forty-four against the 100-entry limit.

#### Next Steps:

Resume by settling BRD-047 before spending another build on BRD-044, because the two are now coupled: build layout `v7` again and inspect each candidate seed's `build/*/clock-plane.log` before deploying, keeping only a placement whose `clk67` is confined to `SPINE16/TOP0` and `SPINE25/TOP1`, and if such a seed reads the pool correctly then the spine is the cause and the project has its first placement-level A/B that separates two near-identical netlists; if it repeats the byte-2 increment and the `0x0800020C` loop then the cause is in the v7 logic and the added comparators are the place to look. Seeds 10 to 16 are already netlisted from the committed source and only need their gates inspected, so this costs placement time and no synthesis. Do not reuse seed 9 for v7 and do not read anything further from `build/v7_s9`; also note that `stl_s5`, `v6_s9` and now `v7_s9` all converge at seed 9, which suggests seed sensitivity rather than anything about the seed's quality, so a wider seed range is worth the wall clock. Once the pool read is in hand, require both properties together per TCL-027, the white field gone and reach undiminished, before reporting a fix, and keep the parked `cpu_en` repair of entries 39 and 40 parked until then. The DMA `REQ1_START` deadlock of BRD-045 remains a separate fault on a separate cartridge and is not on this path. BRD-019 still governs wording and has now earned it twice.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- tools/decode_fetchtrace.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---

## 45 COMMIT Unreleased 2026-11-13T10:54:45-07:00

#### Coming From:

Unreleased 7d41f1b

#### Purpose:

Settle BRD-047 by re-placing layout v7 at a seed whose clock plane matches the working control, then read the `0x080002E0` literal-pool word on the board to confirm or refute BRD-044.

#### Outcome:

BRD-044 is confirmed and the chain BRD-043 left open is closed. Re-placing the v7 netlist needed no synthesis: `build/v7_base/tinygba.json` was hardlinked into each seed directory and the build took its cached-synthesis path, so seeds 10 to 26 cost placement time only. Entry 44 had reported seeds 10 to 16 as routed and awaiting gate inspection; all seven were instead dead from the previous session, `exit=1` with `nextpnr.log` ending mid-progress and no `tinygba.json`, and they were re-run rather than read. Of seventeen seeds attempted, seven reached a bitstream and five were killed in flight at the operator's request: seeds 11, 13, 14, 15, 17, 18 and 24 passed every gate with zero hold violations, seed 20 was refused by the clock-plane gate with `clk67` on general routing and no bridge pip, and seed 21 aborted on BRD-024's `hclk5` route failure. `tools/clock_plane_select.py` was written for this cycle because BRD-047's test condition was prose applied by hand to one clock at a time; it compares all four clocks against a reference routed netlist at once and reports each pip's measured-good state, and its two verdicts were exercised in both directions before any seed was read, which caught a crash on a narrow `--require` and a summary line that claimed more than the filter checked. Its `--require-good` predicate was added after the board result, because set-exact matching cannot express "this clock must cross a measured-good pip": the reference placement may itself be unmeasured, and testing the predicate found that the first version asked whether every pip was good rather than whether any was, which would have rejected the working seed. With the rule applied as a check, `clk67` on the two good spines plus a good `hclk` pip selects `v7_s13` and `v7_s24` and rejects `v7_s9` and `v7_s18`, which is exactly the decision that this cycle got wrong by hand. Selecting on `clk67` alone then produced the cycle's own error: `build/v7_s18` satisfies BRD-047's condition exactly, passed every gate with zero hold violations and `hclk` at 99.532 MHz, and was flashed, and the operator reported the HDMI screen unsynchronised. The capture card returned a pinned 1920x1080 frame of pure black with 255 colours, which is BRD-012's fallback rather than a machine drawing nothing, so that reading was discarded rather than interpreted. `hclk` is the 74.25 MHz pixel clock, and `v7_s18` is the only packed seed whose `hclk` crosses no measured-good pip at all, using `SPINE16/BOTTOM2` and `SPINE24/BOTTOM2` where every other placement -- and both images that have ever displayed, `v6_s9` and `v7_s9` -- carry it across `SPINE19/BOTTOM2` and/or `SPINE26/BOTTOM2`, both measured good; flashing `build/deploy_v7s13`, same two good `clk67` spines and an `hclk` that includes them, restored sync immediately and that is recorded as BRD-048. With the cartridge loaded, `v7_s13` executes the blink delay loop at `0x080002A4` to `0x080002AC`, which is the loop `stl_s5` and `v6_s9` measured and not the `0x0800020C` loop the withdrawn `v7_s9` produced, so BRD-047's prediction held: reach is `0x080002AC` with 7 of 8 tail-ring fetches exact, the miss being `0x0800028C` returning `0xEAFFFFED` from `0x080002AC`, the same one-transaction offset. The pool read itself is direct rather than inferred: two page-3 frames seconds apart agree that the 32-bit read of `0x080002E0` returned `0x0000FFE0` with byte enables `1111` and a read count of 1, while `0x080002DC` and `0x080002E4` returned their correct words, and three of four fresh loads then carry it the whole way, the `strh` to `0x04000000` putting `0xFFE0` on the bus with sticky `0x0403` never seen and the drawer settling at forced blank with BG0..BG3 set. One load of four wrote `0xFEE0`, which is `0xFFE0` with bit 8 clear and a value present nowhere in the image; it is recorded inside BRD-044 rather than smoothed over, and it is a separate load-dependent data-bit fault that the parked repair does not address. Two tool defects were found and fixed before the board was touched: `tools/cap_tang.sh` always reflashed, which reloads the FPGA and clears SDRAM, so it could not capture a cartridge session at all and now takes `--no-flash`; and `tools/decode_fetchtrace.py` printed its "value equals the preceding read" cross-check even when the pool read had not been captured, where an absent record and an empty history are both zero, which would have been a false independent confirmation. The entry-5 and entry-6 valid strips read invalid on page 3, and the cause is instrument-side rather than data-side: `stl_valid` returns `16'h1F00` for that page, marking display entries 0 to 4 only, so the pool-read records never set their own validity bit. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 44 were not rewritten, confirmed BRD-044 retains its canonical field order with a changed status and that BRD-048 is a new unique id, and validated this entry as entry 45 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of forty-five against the 100-entry limit.

#### Next Steps:

Apply the parked `cpu_en` repair of entries 39 and 40, which is now unblocked because the read fault it was parked for is measured, and require it to show both properties together per TCL-027, the white field gone and reach undiminished at `0x080002AC`, since a change that stops the machine earlier would make the surviving reads look correct. Treat the `0xFEE0` load as its own fault and do not fold it into that repair: it lost one bit between a correct `0xFFE0` return and the bus, it appears in one load of four, and no transaction-ordering change addresses it, so it needs an instrument that records the byte enables and the data bus of the store alongside the read. Any further board image must be selected with `tools/clock_plane_select.py` against a reference placement rather than by filtering one clock, and must require a measured-good `hclk` pip as well as good `clk67` spines, because this cycle's single wasted flash came from applying the rule to the cartridge clock and not the pixel clock. Capture from a cartridge session with `--no-flash`, always, or the flash clears the image that was loaded. BRD-019 still governs wording, since `clk16` remains on `*/TOP3` pips this board has never measured on every placement this tree produces, and the clock-plan measurement that would close it is still undone.

#### Files Modified:

- tools/cap_tang.sh
- tools/clock_plane_select.py
- tools/decode_fetchtrace.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---

## 46 COMMIT Unreleased 2026-11-13T12:42:37-07:00

#### Coming From:

Unreleased 63d0406

#### Purpose:

Apply the parked `cpu_en` repair of entries 39 and 40 in the Verilator model, so that the 32-bit read lag confirmed as BRD-044 is removed and the change can be judged by TCL-027's two-property rule before any build is spent on it.

#### Outcome:

The repair removes the lag and collapses reach, so it is not a repair and nothing was built or deployed. The model is decisive because the baseline was re-run at 3000 million steps first and reproduced BRD-038 exactly: `build/sim_base` with `-DTINYGBA_SDRAM_RTL` gave 973 of 984 cartridge reads matching the image, all 11 failures 32-bit, every one returning its predecessor. The repair registers a 32-bit acknowledgement (`ram32_ack_now`) and moves the CPU's consume one cycle forward into the following `MAIN`, where `ram_rdata` carries the word `sdram_gba` has finished splicing, and it suppresses the acknowledgement-cycle term so the stale word is never taken. Three defects in my own patch were found by running it rather than by reading it: it first patched only the concurrent rom+ram branch exactly as entries 39 and 40 worded it, and a 32-bit cartridge read with no fetch in flight lands in the ram-only branch, whose `MAIN` cycle asserts `cpu_en = issingle(0x08..) = 0`, so the machine consumed a stale word, re-issued the same read and wedged after ten reads; it then covered only the request-2 states, and a request-1 acknowledgement consumed `0x080002c8` twice; and once both were fixed by stating the rule once outside the `casez` instead of inside four branches, the read data was fully correct, with `0x080002b0` returning `0x08000400` and `0x080002dc` returning `0x0000ffe0`, byte enables `1111`, and no lag anywhere. That is the trap: correct reads and fewer of them. At equal 1000-million-step budgets the unmodified tree produced 261 cartridge reads and was still climbing, reaching `0x080002e4`, while the repaired tree produced 12 and stopped at `0x080002dc` with the CPU looping in the failed-check column painter at `0x08000238` to `0x0800024C`, a loop whose control registers are literal constants `0xA0` and `0x10` and whose store pointer had run away into region `0x0D`. The repaired build is not stalled -- it stalls 64.5 percent against the baseline's 66.4 percent and executes more fetches per cycle -- so the change is fast and the program is wrong, which is a flow divergence and not a timing shortfall. One instrument was built and discarded: a fetch-word trace sampling `rom_data` on the `cpu_en` edge reported a one-word lag in the repaired build and, on re-run, in the known-good baseline too, so it was measuring its own sampling point and not the machine, exactly the failure TCL-024 records, and it is not kept. The `TINYGBA_MEM32DBG` trace that was kept is the calibrated half -- a periodic PC dump and the consumed 32-bit word with its FSM state -- and both define-on and define-off builds compile. No board image was produced, so the Tang was not flashed; the operator had powered it down in any case. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 45 were not rewritten, and validated this entry as entry 46 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of forty-six against the 100-entry limit.

#### Next Steps:

Revise the plan before another attempt, because the enable-deferral shape entries 39 and 40 proposed is disproven in the model: it produces correct data and the wrong program, and the two are not reconciled by covering more branches. The finding that matters for the next proposal is that the repaired machine diverges in control flow, so the next instrument should record the executed instruction sequence rather than the returned words -- a calibrated fetch trace anchored on a signal that reproduces the ROM in the known-good baseline first, per TCL-024 -- and it should locate the first divergence between the two builds rather than the last correct read. The alternative to the enable shift, and the one I would put first, is to keep `cpu_en` on the acknowledgement cycle and instead make `ram_rdata` carry the assembled word at that cycle, which is a data-path change rather than a control-path one and does not touch request issue at all; the risk to check is that `sdram_gba`'s second collect is not yet complete then, in which case the honest conclusion is that the controller's acknowledgement is early rather than the enable being late. BRD-044 remains confirmed and unaffected by this entry: the board read of `0x080002E0` returning `0x0000FFE0` stands, and the parked repair is still parked. Any board image still needs `tools/clock_plane_select.py` selection with a measured-good `hclk` pip (BRD-048), and BRD-019 still governs wording.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 47 COMMIT Unreleased 2026-11-13T13:38:23-07:00

#### Coming From:

Unreleased 39babb4

#### Purpose:

Replace the failed control-path repair with the data-path one the operator chose, by reading both halfwords of a 32-bit cartridge access from the controller before it acknowledges, so the word is complete when the CPU takes it.

#### Outcome:

The controller's read pipeline was measured for the first time, and the pipelined-read change built on that measurement does not work; nothing was built or deployed. A `TINYGBA_MEM32DBG` trace was added to `sdram_gba` and armed on a 32-bit cartridge read, printing the cycle counter, the registered command, DQ and the ready and port signals for twenty-six consecutive clk67 cycles. It shows the structure directly: a command registered in `cycle[0]` produces data on the pin in `cycle[3]` of the same four-cycle group, so the pipeline presents a word three clk67 after the command register, and each halfword of a 32-bit access occupies a whole group, the low halfword in `cycle[3]` of one group and the high halfword in `cycle[3]` of the next, with `cpu_ready` asserting after the first. That corrects the assumption behind the previous cycle's failed deferral, which had the completion one cycle later than it is. The change implemented from it issues the second READ one clk67 after the first rather than one group later, with auto-precharge moved from the first command to the second so the row stays open across the pair, captures the low halfword in `cycle[3]` and the high halfword on the following cycle, and asserts `cpu_ready` only once both are in `cpu_rdata`. The boot logo and BIOS still run, and 156,000 more CPU cycles execute than in the unmodified tree, but the machine completes one pipelined read in 300 million steps and that read assembled `0xff240000`, with the low halfword empty, and no cartridge data read is consumed at all. Stalling rises from 66.4 to 79.6 percent, so the CPU waits rather than diverging: instruction fetches are 32-bit reads as well, they take the same path, and the first one does not complete correctly, which stops the machine before it can reach the checks. The attempt is recorded rather than pursued because three separate changes to this interface have now each been built, measured and falsified, and the measured trace is the durable result: the honest next step is to instrument the pair path itself, not to guess at it again. The tree is restored to `39babb4` with the change preserved outside the repository, so `sdram_gba` is byte-identical to the version the board has been running. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 46 were not rewritten, and validated this entry as entry 47 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set, `None.` for Files Modified because no engineering file changed, and a count of forty-seven against the 100-entry limit.

#### Next Steps:

Decide how to proceed rather than build again on the same assumption, because the pipeline is now measured and the remaining unknown is the pair path itself. The specific question to answer with the next instrument is why the low halfword read as empty and why only one pair completed: the trace should print `rd32_pair`, `rd32_fin`, `port[0]`, `addr_latch[0]`, `ds_latch[0]` and `dq_in` on every cycle of a single cartridge access, from the request being latched to `cpu_ready`, so the pair can be corrected against evidence instead of inference. One concrete suspicion to test first is that instruction fetches share the path: `gba_memory` drives `bram_be` as `4'b1111` for ROM fetches, so a fetch is a 32-bit read and takes the new branch, which is why the machine stops at the first fetch rather than at the checks; if the pair is to be scoped to data reads only, the controller needs a signal that distinguishes the two, and `gba_memory` does not currently send one. Do not re-apply the control-path deferral of entry 46, which is disproven. BRD-044 remains confirmed and unaffected: the board read of `0x080002E0` returning `0x0000FFE0` stands, and the repair is still parked. Any board image still needs `tools/clock_plane_select.py` selection with a measured-good `hclk` pip (BRD-048); the Tang was powered down by the operator during this cycle and no board work was done.

#### Files Modified:

None.

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 48 COMMIT Unreleased 2026-11-13T13:49:35-07:00

#### Coming From:

Unreleased 4fdf6d6

#### Purpose:

Re-read the whole log at the operator's request, to decide whether entries 36 to 47 were pursuing the right fault, and record what that reading changed.

#### Outcome:

The reading changes the plan and no code was touched. Four findings, none of them new measurements and all of them available in records this project already had. First, the two halves of the read-lag repair were already isolated by entry 37: the controller acknowledgement change alone moved nothing measurable, the output mux alone left the eleven failures, and driving the mux wider removed them only by cutting reach to `0x080000de`. Entries 46 and 47 then built the same two halves again from the control side and the data side and reproduced entry 37's outcome in both directions, which means entries 38 to 47 produced no new information about the repair beyond what entry 37 already contained. Second, entry 33 identified three departures from upstream and its Next Steps named the experiment to test the one that sits on this boundary: put `clk16` and `clk67` back on upstream's `CLKOUT` assignment, one PLL and one VCO, and drop the `CLOCK_LOC "clk67" BUFG`. No entry after 33 mentions that experiment, so the single test the log itself recommended for this boundary has never been run, while ten entries were spent editing the logic of a controller whose only functional deviation from upstream is the `[31:15]` to `[31:16]` repair, which is inert because the masked high half is overwritten on the next collect. Third, the harness cannot see the quantity in dispute. `sim_main.cpp` derives `clk50`, `clk16` and `clk67` from one counter with ideal wires, so it models static phase exactly and arrival delay not at all, and the board has twice been shown to be decided by exactly the class it cannot model: BRD-047 separates two bitstreams of one netlist by a `clk67` spine and obtains a different program, and BRD-048 separates two by an `hclk` spine and obtains a picture against no picture. A correction to my own first reading is recorded rather than dropped: I initially concluded the harness was blind to phase as well, and computing its own clock expressions shows the opposite, since shifts 0, 3, 6 and 9 put a `clk16` edge where `clk67` is high and the other eight put it where `clk67` is low, so entry 38's twelve-offset sweep did test phase and did answer it; what it could not test is arrival, and that narrower claim is the one now written down as TCL-031. Fourth, reading the RTL for the handshake found a hazard the project has never recorded: `cpu_ready` is registered in the `clk67` domain, leaves `sdram_gba` as the bare net `cpu_mem_ready` with no synchroniser, and is consumed as a level by `gba_memory`, `gba_dma` and a third block in the `clk16` domain, while being one `clk67` cycle wide, a quarter of the receiving period; the comment at `gba_memory.sv:385` calls it a single-`clk16` pulse, which the RTL does not produce. That is BRD-049, and it makes a board measurement of this boundary unattributable to logic while BRD-019 remains open. Separately the objective had drifted: reach is measured against the blink loop at `0x080002AC` of a purpose-built test cartridge, and even a perfect read path does not produce a picture from a retail title because BRD-045, Super Mario Advance wedging in `REQ1_WAIT` behind a DMA3 IWRAM write, has been verified since entry 43 and untouched. Nothing was built, nothing was deployed, the tree is clean at `4fdf6d6` and `sdram_gba` is byte-identical to the image the board has run. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 47 were not rewritten, confirmed BRD-049 and TCL-031 carry unique ids and the canonical field order, and validated this entry as entry 48 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set, `None.` for Files Modified because no engineering file changed, and a count of forty-eight against the 100-entry limit.

#### Next Steps:

Run entry 33's experiment before any further work on the read lag, because it is the only test that separates a clock-plan cause from a logic cause and it has been available since entry 33: move `clk16` and `clk67` back to upstream's `CLKOUT` assignment on one VCO and drop `CLOCK_LOC "clk67" BUFG`, then read the literal pool on the board with the v7 instrument, which returns `0x00000403` if the lag was phase-dependent and `0x0000FFE0` if it was not, and report reach beside it per TCL-027. Treat that as a board question and not a simulation one, because TCL-031 establishes the harness has no authority over arrival and the model reproduced the lag deterministically with ideal wires, so a model result there settles nothing either way. Expect to have to satisfy the clock-plane gate non-strictly, since apicula models plane pips only for `CLKOUT0` and `CLKOUT2` and upstream's assignment puts `clk67` on a lane without one. Second and independent of the first, close BRD-049's hazard with a synchroniser on the `cpu_mem_ready` crossing, which is a mechanism change that neither state machine's logic depends on and can be built and reasoned about without the board; it is worth doing even if the clock-assignment test explains the lag, because a one-cycle strobe sampled directly across domains is unsafe regardless of whether it is the current fault. Third, restate the objective before spending another cycle on reads: a retail title booting and drawing is the goal, reach against `test_logo`'s blink loop is a proxy, and BRD-045 is a verified second fault on that path which no read-path change addresses. Do not re-apply the control-path deferral of entry 46 or the pipelined pair of entry 47, both measured and falsified; do not re-run entry 38's phase sweep expecting it to say something about arrival; and keep every cartridge-read claim going through `tools/check_cartread.py` with reach quoted beside accuracy.

#### Files Modified:

None.

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 49 COMMIT Unreleased 2026-11-13T16:22:37-07:00

#### Coming From:

Unreleased 15204e4

#### Purpose:

Run entry 33's open experiment, giving `clk16` and `clk67` upstream's clock-lane assignment on the shared PLL, to test whether BRD-044's one-word read lag is a clock-plan effect rather than a logic one.

#### Outcome:

The experiment is settled as a negative on both halves, and it needed no board time. The device database was read first rather than the record consulted: across the whole GW5AST-138C only three pips drive a clock-plane wire from a PLL output, `TLPLL0CLK0` and `TLPLL0CLK2` from `MPLLCLKOUT0` and `MPLLCLKOUT2` on the left-edge site and `TRPLL0CLK0` from `MPLLCLKOUT0` on the right-edge sites, so `CLKOUT1` reaches nothing beyond the tile-local `F1` lane. Upstream's assignment therefore puts `clk16` on a lane with no plane pip, which is the same position `clk67` was in before this port gave it a BUFG. The swap was implemented faithfully anyway, with `ODIV1_SEL` and `ODIV2_SEL` exchanged and the port connections renamed so `clk16` takes `CLKOUT1` and `clk67` takes `CLKOUT2`, and with `CLOCK_LOC "clk16" BUFG` applied as the same remedy the port already used for `clk67`. Synthesis confirmed nothing but routing had changed, at 14,921 flip-flops and 148 block RAM against `build/v7_s9`'s identical counts. Eight seeds were launched; seed 9 reached a routed netlist and the clock-plane gate refused it with `NO PLANE PIP: 'clk16' crosses no bridge pip, so it is on general routing`, while `clk67` on `CLKOUT2` did reach the plane on `SPINE19/TOP2` and `SPINE27/TOP2`. The remaining seven were stopped rather than awaited, because the refusal is structural: the BUFG route carries `clk67`'s 255 sinks and cannot carry `clk16`'s 2381, so no seed would have differed. The second half of the answer matters more than the first and was available from arithmetic: both arrangements use the same VCO and the same dividers, `FVCO` 1809 MHz from `Fpfd` 27 and `MDIV` 67 with `ODIV0` 36, one lane at 27 and one at 108, giving 50.25, 67.00 and 16.75 MHz in both cases. Upstream puts 16.75 MHz on the /108 divider and 67 MHz on the /27 divider and so does this port; the swap only changes which output pin carries which, so it changes insertion delay and plane routing and does not change the divider relationship that sets when the two clocks' edges fall relative to each other. The phase hypothesis entry 33 was built on is therefore weakened rather than confirmed, and the port's clock swap is shown to be forced rather than gratuitous: `clk16` must be on `CLKOUT0` or `CLKOUT2` to reach the plane on this device, `clk50` holds `CLKOUT0`, so `clk67` is the only clock that can be moved off and the arrangement in the tree is the one the device admits. Recorded as TCL-032. Nothing was deployed and the Tang was powered down throughout, so no board reading was taken and none was possible from a build the clock-plane gate refuses. The tree is restored to `15204e4`; `pll_16.v`, `gbatang_top.sv` and `tinygba.cst` are byte-identical to the image the board has run, and the attempt is preserved outside the repository. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 48 were not rewritten, confirmed TCL-032 carries a unique id and the canonical field order, and validated this entry as entry 49 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set, `None.` for Files Modified because no engineering file changed, and a count of forty-nine against the 100-entry limit.

#### Next Steps:

Close BRD-049's hazard next, which is now the highest-value change on this boundary: `cpu_ready` leaves `sdram_gba` as a bare net, one `clk67` cycle wide and a quarter of the `clk16` period, and is consumed as a level by `gba_memory`, `gba_dma` and a third block with no synchroniser, so a two-flop synchroniser in `clk16` with an edge detect, or a four-phase handshake, removes a hazard that is unsafe by construction regardless of whether it turns out to be the current fault. That work needs no board and can be judged in the model for reach and read accuracy together per TCL-027, with the caveat that the harness cannot confirm a timing fix (TCL-031) so a clean model result is necessary and not sufficient. Do not re-run entry 33's experiment, which this cycle closes as unbuildable and phase-neutral. If the synchroniser is done and the lag survives it, the next discriminating instrument is a board measurement of the arrival relationship rather than any further logic change, and the honest statement at that point is that the fault is placement-dependent timing on an unmeasured clock plan, which BRD-019 has held open since 2026-11-04. Keep the objective in view rather than the proxy: reach at `0x080002AC` is measured on `test_logo`'s blink loop, a retail title needs BRD-045's DMA `REQ1_START` deadlock solved as well, and that record has been verified and untouched since entry 43.

#### Files Modified:

None.

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 50 COMMIT Unreleased 2026-11-13T16:48:27-07:00

#### Coming From:

Unreleased e17c88c

#### Purpose:

Close BRD-049's hazard by synchronising the controller's ready strobe into `clk16`, on the reasoning that the defect lives on the clock-domain boundary rather than inside either state machine.

#### Outcome:

The read lag is gone in the model, and the change is one synchroniser on a wire. `cpu_ready` left `sdram_gba` as a bare net, registered in `clk67` and sampled as a level by `gba_memory` in `clk16`; `gbatang_top.sv` now declares `cpu_mem_ready_raw` for the three controller instances to drive, puts it through a two-flop synchroniser clocked by `clk16`, and keeps `cpu_mem_ready` as the synchronised net that `gba_memory`, `gba_dma`, `sdram_probe` and the two clk16-domain status latches consume, while the one indicator clocked in `clk67` deliberately keeps sampling the raw net so the change introduces no new crossing. A two-flop stage is the right instrument rather than a handshake because the strobe is a full `clk16` period wide, which this cycle measured rather than assumed: 556,000 `clk16` samples of it against 345,000 `clk67` ack rises gives 1.6 samples per rise, and a single `clk67` cycle would have given 0.25. The result is categorical under `-DTINYGBA_SDRAM_RTL` at 3000 million steps against `test_logo.gba`: 47 cartridge reads, 47 matching the image, zero failures, reach `0x08000C00` and 889 frames, where the unmodified tree gives 984 reads, 973 correct, eleven failures, reach `0x080002E4` and 865 frames. The read BRD-044 turned on returns its own word for the first time, `addr=080002E0 data_now=00000403 data_prev=0000FFE0`, and `data_prev` is exactly the value the board measured, so the harness's two candidate columns now disagree and its calibrated column confirms the fix rather than merely permitting it. The display register follows the same way: the `0x0403` store is issued four times and `0xFFE0` never, against the unmodified tree's `0xFFE0` twice and `0x0403` never. The mechanism is the one BRD-039 identified, with the delay on the handshake rather than on `cpu_en`, which is why entries 36, 46 and 47 all failed: `sdram_gba` acknowledges at the first halfword collect while `cpu_rdata` still holds a stale high half, the second collect completes the word one `clk67` cycle later, and two `clk16` cycles of synchroniser delay put the CPU's consume after it. The cost is invisible in this model, since frames rise from 865 to 889. Both of TCL-027's properties therefore hold together: accuracy 47 of 47 and reach `0x08000C00` against `0x080002E4`, so this is not a truncation wearing a clean read set. It is recorded as BRD-050 at status MEASURED and not VERIFIED, because the harness has ideal zero-delay clocks and BRD-033 governs: the model cannot show that the metastability hazard was the board's fault as well as its own, and only a board reading can. No bitstream was built and nothing was deployed, because the Tang was powered down by the operator at the start of the previous cycle and has not been asked for since; the change touches `gbatang_top.sv`, which is in the synthesis source list, so a board image is possible from it. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 49 were not rewritten, confirmed BRD-050 carries a unique id and the canonical field order, and validated this entry as entry 50 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty against the 100-entry limit.

#### Next Steps:

Put it on the board, which is the only thing that can raise BRD-050 from MEASURED to VERIFIED: build with `-DTINYGBA_FETCHTRACE -DTINYGBA_STALLTRACE` and the official BIOS so the v7 instrument reports the pool read, select the placement with `tools/clock_plane_select.py` requiring a measured-good `hclk` pip as well as the two good `clk67` spines per BRD-048, and require both properties together per TCL-027. Two specific predictions to check and report as predictions rather than inferences: the 32-bit read of `0x080002E0` should return `0x00000403` instead of `0x0000FFE0`, and the drawer's DISPCNT should reach `0x0403` with forced blank released, which would mean the white field of entries 42 and 43 is gone. If the board disagrees with the model, the disagreement itself is the next instrument, because it would separate metastability from the delay the model can see. Do not re-apply the control-path deferral of entry 46 or the pipelined pair of entry 47; both are measured and falsified, and this cycle's result explains why they were aimed at the wrong side of the boundary. Do not re-run entry 33's clock-lane experiment, closed by TCL-032. If the board confirms, the next real question is the objective rather than the read path: `test_logo` reaching its `ROMCHK` fetches is a proxy, BRD-045's DMA `REQ1_START` deadlock still blocks a retail title, and that record has been verified and untouched since entry 43.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 51 COMMIT Unreleased 2026-11-13T17:13:28-07:00

#### Coming From:

Unreleased 33c6dda

#### Purpose:

Review the sibling `fpt/tang-tiny-gpu` project's Gowin and open-tool findings, and turn the ones that apply to this tree into a checked record and a build-time gate while the board image for the synchroniser change synthesises.

#### Outcome:

The review found one live defect class in this netlist and one methodology error, and produced a gate for the first. The sibling project is not a candidate for reuse: it targets a Tang Nano 20K on a GW2AR-18 with an RP2350 host, its GPU is a command 2D rasteriser plus a PS1-class 3D engine rather than anything GBA-compatible, and its SDRAM controller serves a package-internal 32-bit part where this board has two external 16-bit dies on a 40-pin header, so adopting it would mean abandoning the GBA. Its `docs/ARCHITECTURE.md` section 10 is a different matter and is titled as the list of things that all passed Verilator and only misbehaved on hardware, which is this project's exact position. Of that list, the signed-multiply and `$buf` findings do not apply, and were checked rather than assumed: the netlist carries no `MULT` cell at all, and every one of the 745 `$buf` cells sits inside a blackbox library module with none in `gbatang_top`. The distributed-RAM finding does apply, and it is already happening here: `build/v7_base/synth.log` maps `gpu.drawer.linebuf_obj_settings.ram` to `$__GOWIN_LUTRAM_` and records `Extracted data FF from read port 0`, while the four wide line buffers in the same drawer and `linebuf_obj_color` all map to block RAM. The RTL did not ask for that: `linebuffer.v` carries `syn_ramstyle = "block_ram"` under `` `ifdef M138K `` and `M138K` is defined for this board, but the attribute is in comment syntax this flow's `read_slang` does not parse, which is the same failure class as the inert `(* keep *)` marks already recorded. It is the 4-bit instantiation that falls through, the four sound arrays and `mem.loader_buf` take the same path, and the netlist holds 66 `RAM16SDP4` cells, recorded as TCL-033 with the caveat that nothing here shows the array is wrong, only that the resource differs from the one asked for. `tools/memory_census.py` is the new gate: it groups flattened cell names back into array paths, prints which arrays are in distributed RAM, and fails on drift against `tools/memory_baseline.json` so a mapping change is a visible baseline update rather than an unnoticed side effect. It was mutation-tested in both directions, and the test found a real defect in my own first version, which compared scalar totals and crashed on the per-array structure; the corrected diff reports an array arriving in LUT RAM and another leaving it. The second finding is a methodology error this project has been making: BRD-047 and BRD-048 each separate two placements of one netlist that pass every gate, and the sibling project's own rule is that if a seed change alters the hardware result then a tool-level defect should be suspected, with completion defined as two or more seeds run twice each. This project has been deploying one seed and reading once, which cannot tell a property of the design from a property of the placement, so TCL-034 records the two-seed two-load requirement. The gate has deliberately not been wired into `tools/build_tinygba.sh` yet, because a placement sweep for the synchroniser build was running and a shell re-reads a running script; that integration belongs to that cycle. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 50 were not rewritten, confirmed TCL-033 and TCL-034 carry unique ids and the canonical field order, and validated this entry as entry 51 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty-one against the 100-entry limit.

#### Next Steps:

Wire `tools/memory_census.py` into `tools/build_tinygba.sh` beside the existing register-parity and clock-plane gates once the synchroniser board build has finished, so the mapping is checked on every build rather than only when someone looks. Then finish the cycle that this one ran alongside: the synchronised tree has been synthesised into `build/sync_b` and is being placed across eight seeds, the placement must be chosen with `tools/clock_plane_select.py` requiring a measured-good `hclk` pip as well as the two good `clk67` spines per BRD-048, and the pool read and DISPCNT must be read on the board against the two predictions BRD-050 makes, at two seeds with two loads each per TCL-034. If the object-settings buffer turns out to matter, the GPU-path test is a real `(* ram_style = "block_ram" *)` attribute on that one array and the drawer instrument, as its own cycle; do not adopt `synth_gowin -nolutram` wholesale without measuring it, because it also moves the four sound arrays and the loader buffer. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment, all three measured and closed.

#### Files Modified:

- tools/memory_census.py
- tools/memory_baseline.json

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 52 COMMIT Unreleased 2026-11-13T17:24:48-07:00

#### Coming From:

Unreleased 9a5974a

#### Purpose:

Turn TCL-035's nextpnr blind spot into a checked tool, and correct the depth figures that record carried from an ad-hoc analysis while the board image for the synchroniser change is being placed.

#### Outcome:

`tools/bsram_addr_check.py` now measures, on any synthesised netlist, how much logic sits between a dual-port BSRAM address port and the nearest flip-flop, and it corrected the record it was built from. The first figures in TCL-035 came from an ad-hoc traversal that walked *into* BSRAM cells, whose outputs are registered, so it never reached a flip-flop and its depths were clipped by a cap; the `twelve levels` that record first carried was that artefact. The tool stops traversal at every non-combinational cell and always measures against a fixed generous cap rather than the bound being tested, so a reported depth is the depth. It reproduces the corrected figures in half a second: 362 logic-driven `ADB` bits on 109 dual-port BSRAM cells, distributed as 38 bits at one level, 38 at two, 38 at three, 76 at five, 38 at six, 38 at seven, and 96 bits at 41 to 43 levels. All 96 deep bits belong to `mem.mem_bios` across eight `DPB` slices, and tracing one chain names its shape: it starts at `cpu.cmd`, runs through a long `ALU` carry chain of the CPU's address datapath, and arrives at `mem.ram_addr`, which is the address `mem_bios` is read with, so the path is the CPU's address generation meeting a port nextpnr does not time rather than a peripheral's local logic. TCL-035 was corrected in place, with the correction itself recorded in its `verification` field rather than made silently. The gate is built to catch a regression rather than to fail on what is already known: `--known` defaults to `mem.mem_bios`, so a recorded array is printed and does not fail, while a *new* array with a deep cone does. It was tested in four directions — the unmodified netlist passes, a cloned deep cone under a new name fails and is named, a generous `--max-depth` reports only, and a missing file exits 2 — and two of those runs found real defects in my own tool: the traversal bug above, and a closing message that claimed nothing exceeded the bound while the known array plainly did. It is not wired into `tools/build_tinygba.sh` for the same reason as `tools/memory_census.py`, that a placement sweep was running and a shell re-reads a running script. Separately, placement of the synchronised tree continues: eight seeds launched at 17:11, seed 13 has already aborted on BRD-024's `hclk5` route failure, and the other seven are between 134,000 and 224,000 iterations. Nothing was deployed and no board reading was taken. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 51 were not rewritten, confirmed TCL-035's correction preserves its canonical field order, and validated this entry as entry 52 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty-two against the 100-entry limit.

#### Next Steps:

Finish the board cycle that this one ran alongside, which is still the thing that decides anything: pick a completed seed with `tools/clock_plane_select.py` requiring a measured-good `hclk` pip and the two good `clk67` spines per BRD-048, and read the pool word and DISPCNT on the board against BRD-050's two predictions at two seeds with two loads each per TCL-034. If the board confirms the synchroniser, the `mem_bios` cone becomes the next thing to look at for the remaining placement sensitivity, and the cheapest test is to register `mem.ram_addr` one level before `mem_bios`'s address port so the 43-level cone feeds a flip-flop; that is a change to the address datapath and must be judged with the box on the same two-seed two-load bar. Wire both `tools/memory_census.py` and `tools/bsram_addr_check.py` into `tools/build_tinygba.sh` beside the register-parity and clock-plane gates once no build is running, so both classes are checked on every build rather than when someone looks. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment; all three are measured and closed.

#### Files Modified:

- tools/bsram_addr_check.py

#### Status:

- Build: N/A
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 53 COMMIT Unreleased 2026-11-13T18:49:09-07:00

#### Coming From:

Unreleased 754bec8

#### Purpose:

Answer the operator's finding that a GBA core which cannot boot should not take longer to build than the sibling SNES core with SuperFX, by finding where the build time actually goes.

#### Outcome:

The build time was the synthesiser's wide-multiplexer mapping, and removing it cuts the build roughly threefold while improving the achieved clocks. The operator's benchmark was the trigger: TinySNES with SuperFX and its helper chips places in about twenty minutes, this design was taking one and a half to two hours per seed, and it does so at only 38 percent LUT4 and 11 percent DFF utilisation. Two hypotheses were tested and discarded by measurement rather than argument. Threads are irrelevant, and the `--threads` experiment was abandoned at the operator's instruction before it produced a number. Clock-net routing was also not the cause: the `sync_s10` build logs 804 failed dedicated routes on `clk67` and I initially read that as the flood responsible, but the same 804 appear in the `ovb_s3`, `v6_s9`, `v7_s9` and `v7_s18` logs, all of which routed and some of which displayed, while `v7_s13`, `v7_s17` and `e49_s9` report zero and `v7_s13` displayed as well, so the count separates nothing. The actual cause was found by comparing netlists rather than logs: `synth_gowin` maps wide multiplexers onto the device's dedicated `MUX2_LUT5` to `MUX2_LUT8` primitives, which occupy fixed tile groups, so a `MUX2_LUT8` locks eight 4-LUT sites at one position. This design produced 13,295 of them on the instrumented build and 14,077 on the older `v7` netlist, 9,419 in the CPU block alone, about 22,677 LUT-site equivalents or 16 percent of the device position-locked. That is why utilisation was low and placement was slow. A `TINYGBA_SYNTH_EXTRA` variable was added to `tools/build_tinygba.sh` so extra `synth_gowin` arguments can be passed without editing the script, and `-nowidelut` was measured against the identical source and defines: cells 81,124 to 58,501, wide muxes 13,295 to zero, flip-flops 14,923 to 14,923 exactly, netlist 102 MB to 64 MB, routing arcs 253,232 to 197,525, synthesis 12.7 to 9 minutes, CPU block 19,895 to 10,595 cells and memory block 13,642 to 4,192. The first `-nowidelut` placement to converge did so in about 32 minutes and passed every gate with better clocks than `v7_s13`: `clk16` 22.871 against 18.688 MHz, `hclk` 104.723 against 86.972, zero hold violations, `clk67` on both measured-good spines. Total synthesis-to-bitstream is about 41 minutes against about 135. That bitstream was flashed and the operator reported the display working, showing the trace instrument's white cells, so the mapped design boots, draws and syncs. What could not be obtained is a decoded capture: during and after the operator's replug of the capture card, `tools/cap_tang.sh` returned the 255-colour near-black frame that BRD-012 records as its no-signal signature, on every timing tried, including after a reflash that forces a fresh HDMI handshake, while the same card decoded `v7_s13` at 2,461 colours earlier in the same session. The board is therefore demonstrably producing a picture and my capture path is not receiving it, and no claim is made from this cycle about the read lag, about DISPCNT, or about whether the `-nowidelut` mapping behaves identically to the wide-lut one. Six further seeds were left placing. Recorded as TCL-036. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 52 were not rewritten, confirmed TCL-036 carries a unique id and the canonical field order, and validated this entry as entry 53 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty-three against the 100-entry limit.

#### Next Steps:

Carry `-nowidelut` in `tools/build_tinygba.sh` as the default rather than as an experiment, since it is smaller, faster, better-timed and flip-flop-identical, and only requires the one variable already added; record the primitive mix in a gate so a return to wide muxes is visible, in the same shape as `tools/memory_census.py` and `tools/bsram_addr_check.py`, both of which are still waiting to be wired in. Then close the two gaps this cycle leaves. First, restore the capture path and decode a frame: the card sees no signal while the board draws, so check the cable and splitter topology before suspecting the bitstream, and note that a reflash does not fix a cable and that `ffmpeg` writing a single PNG needs `-update 1` or the project script. Second, establish behavioural equivalence between the wide-lut and `-nowidelut` mappings, which is the one thing TCL-036 explicitly does not claim: the cheapest test is the same cartridge on both, scored through `tools/check_cartread.py` for accuracy and reach together per TCL-027, at two seeds and two loads per TCL-034. Once a capture is available, the synchroniser verification of BRD-050 is still outstanding and is the original question of this cycle: read page 3 for the pool word at `0x080002E0` and the drawer's DISPCNT. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment.

#### Files Modified:

- tools/build_tinygba.sh

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---

## 54 COMMIT Unreleased 2026-11-13T19:02:35-07:00

#### Coming From:

Unreleased e2e9d1e

#### Purpose:

Verify BRD-050's synchroniser on the board, which is the last step of the read-lag cycle and the property entries 42 and 43 measured as missing.

#### Outcome:

The one-word read lag is fixed on hardware and the white field is gone. With the capture path restored -- the operator had not had HDMI plugged into the capture card, which is why every capture in entry 53 read as BRD-012's no-signal signature while the board was plainly drawing -- `build/deploy_nwl11` was reloaded, `test_logo.gba` streamed, and page 3 decoded from three independent captures that agree field for field. The 32-bit read of `0x080002E0` returns `0x00000403`, the word the image holds there, where `build/deploy_v7s13` returned `0x0000FFE0` before the change; `0x080002E4` returns `0x00007FFF` correctly; the `0x0403` store is issued and is the last DISPCNT write with the sticky `0xFFE0` flag never setting, against `0xFFE0` twice and `0x0403` never before; and the drawer's own copy of DISPCNT settles at forced_blank=0 with BG2 on, where it previously sat at forced_blank=1 with BG0..BG3. The drawer reaching `0x0403` is exactly the property entries 42 and 43 measured as absent, so the white field is gone by measurement and not by inference. The tail ring shows the CPU past the store, at `0x08000260` (the `strh` to `0x04000000`) and `0x08000264`, with 7 of 8 tail-ring fetches exact and the single miss being `0x08000264` reading `0xE1CB00B0`, its predecessor, which is the same one-transaction offset BRD-044 records elsewhere and not a new fault. Both TCL-027 properties therefore hold together: the reads are correct and the machine executes past the store it previously never reached. The four remaining `-nowidelut` seeds from entry 53 all landed with exit 0 and zero hold violations, so five placements exist; `tools/clock_plane_select.py` reports `nwl_s11` as an exact match to the `v6_s9` reference on all four clocks and `nwl_s12`, `nwl_s14` and `nwl_s15` as matching on the required `clk67` spines plus a measured-good `hclk` pip. Per TCL-034's two-seed bar a second seed was flashed, `build/deploy_nwl12`, and page 3 decoded there independently reproduces every headline figure identically, so the result is not a property of one placement. BRD-050 is raised from MEASURED to VERIFIED with the board evidence, and its two predictions -- the pool read returning `0x00000403` and the drawer reaching `0x0403` with blank released -- both held. The decoder's canned verdict line reads `BRD-044 is REFUTED`, which is a wording artefact rather than a finding: BRD-044 was confirmed on `v7_s13` where the read did return `0x0000FFE0`, and it is correct now for the opposite reason, that the read returns its own word. The `0x080002DC` record reading zero in this capture is likewise an absent read rather than a zero word, since the instrument only latches an address it saw. What remains unmeasured is the reach that entry 53 listed as its gap: this capture shows execution past `0x08000260` and `0x08000264` but its tail ring is in the column-painter tail rather than the blink delay loop at `0x080002AC` that `v7_s13` and `stl_s5` both reached, so behavioural equivalence between the wide-lut and `-nowidelut` mappings is still not established by this cycle. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 53 were not rewritten, confirmed BRD-050 retains its canonical field order with a changed status and title, and validated this entry as entry 54 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set, `None.` for Files Modified because no engineering file changed, and a count of fifty-four against the 100-entry limit.

#### Next Steps:

Build a production image with no trace instrument and put the cartridge's own picture on the board, which is now the thing worth looking at: `-DTINYGBA_OVERLAY_OFF` with the official BIOS and `TINYGBA_SYNTH_EXTRA=-nowidelut`, selected with `tools/clock_plane_select.py`, and the operator asked what is on screen rather than what a capture decodes -- the cartridge paints green when all eight checks pass and red otherwise with one yellow column per failed bit, so the field names the failing check directly. That also settles the equivalence gap entry 53 left open, because the same image answers it. Then close the build-time work that TCL-036 opened: make `-nowidelut` the default in `tools/build_tinygba.sh` rather than a variable to remember, and wire `tools/memory_census.py`, `tools/bsram_addr_check.py` and a primitive-mix check into the build so the wide-mux regression cannot return silently. The next substantive fault is BRD-045, the DMA `REQ1_START` deadlock that stops Super Mario Advance in the first second on some loads; it has been verified and untouched since entry 43 and no read-path change addresses it, so a retail title needs it solved. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment.

#### Files Modified:

None.

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 55 COMMIT Unreleased 2026-11-13T19:46:19-07:00

#### Coming From:

Unreleased 3e2ed0a

#### Purpose:

Build a production image with no trace instrument and put the cartridge's own picture on the board, which both shows a real result and settles the behavioural-equivalence question entry 53 left open.

#### Outcome:

The cartridge draws its own picture, all eight of its checks pass, and the gate report needs no relaxation for the first time. A production netlist was synthesised with `-DTINYGBA_OVERLAY_OFF`, the official BIOS and `TINYGBA_SYNTH_EXTRA=-nowidelut`, giving 49,216 cells and 11,497 flip-flops against the wide-lut production build's 70,923 and 11,495, so the only structural difference from the last production image is the two synchroniser flops of BRD-050 and the primitive mapping of TCL-036. Six seeds were placed from that single netlist; `prod_s12` and `prod_s14` reached bitstreams with zero hold violations and `prod_s14` was deployed as `build/deploy_prod`, chosen for better timing at `clk16` 23.959, `clk50` 86.311, `clk67` 152.462 and `hclk` 95.905 MHz, with a timing gate reading `Meets the contract with no relaxation needed` -- the first image in this project's history to need no GBATang multicycle allowance. Both production placements carry `clk67` on `SPINE25/TOP1`, a measured-good spine, and a measured-good `hclk` pip. `tools/clock_plane_select.py` reported both as non-matches, and that is a defect in the tool rather than a finding: it compares pip sets for exact equality, so a placement using a strict subset of the reference's measured-good pips is rejected although it satisfies the rule BRD-048 records. That needs fixing before the tool is trusted as a selector. With `test_logo.gba` loaded the field is solid green with a white orientation square and no yellow or red anywhere: three captures agree, green 1,737,728 pixels, yellow 0, red 0, and the operator confirmed the field on screen. Green is the cartridge's own statement that its failure mask is zero, covering three cartridge word reads at `0x08000400`, `0x08000800` and `0x08000C00`, IWRAM and EWRAM word plus byte-lane checks, and a VRAM halfword check, so this is a behavioural confirmation of the whole read path rather than a probe reading, and it settles entry 53's open question because an image with wide muxes mapped to LUTs passes the cartridge's own self-test. Reach is `0x08000C00` against the `0x080002AC` blink loop earlier entries reached, so reach increased. Recorded as BRD-051. What is not claimed: nothing about retail cartridges, because BRD-045's DMA deadlock is untouched and `test_logo` does not use DMA; nothing about sound, timers or saves, none tested; and no claim of long-run stability, only that three captures across a few seconds agreed. Four further production seeds were still routing when the cycle closed. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 54 were not rewritten, confirmed BRD-051 carries a unique id and the canonical field order, and validated this entry as entry 55 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set, `None.` for Files Modified because no engineering file changed, and a count of fifty-five against the 100-entry limit.

#### Next Steps:

Fix `tools/clock_plane_select.py` so a placement whose pips are a subset of the reference's measured-good set counts as a match, since rejecting `prod_s12` and `prod_s14` was wrong and a selector that refuses valid placements is worse than no selector. Then take up BRD-045, the DMA `REQ1_START` deadlock that stops Super Mario Advance in the first second on some loads, which is now the only known fault between this tree and a retail title: it has been verified since entry 43 and untouched, and no read-path change addresses it. The instrument for it exists in principle -- the v6 control-flow records already showed the FSM wedged in `REQ1_WAIT` with `dma_on` and `dma_ena` high and `dma_addr=0x03001190` -- so the work starts from a measured wedge rather than a guess. Also worth doing while the build is cheap: make `-nowidelut` the default rather than a variable to remember, and wire `tools/memory_census.py`, `tools/bsram_addr_check.py` and a primitive-mix check into the build so the wide-mux regression cannot return silently. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment; all three are measured and closed, and BRD-050's synchroniser is the change that worked.

#### Files Modified:

None.

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 56 COMMIT Unreleased 2026-11-13T21:01:26-07:00

#### Coming From:

Unreleased 2326e07

#### Purpose:

Find out why retail and diagnostic cartridges boot the BIOS and then stop on a garbled picture, while the purpose-built test cartridge draws correctly, by reproducing the fault in the Verilator model.

#### Outcome:

The investigation produced a clean reproduction and then invalidated the instrument that produced it, and no fault was fixed. The reproduction is real and useful: the controller harness running the RetroRegen diagnostic cartridge draws exactly what the board draws, a single orange text row at output rows 130 to 137 with the same smeared glyph shapes, the same descender fragments, and six consecutive frames byte-identical, so the machine is frozen rather than still drawing. Twelve independent checks on that frame support a specific reading: the row is at the right vertical position and exactly 8 pixels tall, which is one tile row, so layout, scaling and palette are all correct and only the glyph bit patterns are wrong. Three hypotheses were eliminated by measurement rather than argument. DMA is not involved: a `TINYGBA_DMADBG` trace of every DMA write in the run records zero, so the cartridge is not blitting through DMA and BRD-045 cannot be the cause of this cart's failure even though it remains real for Super Mario Advance. Cartridge reads are correct: the last reads the cartridge makes are `0x08003428` returning `0x04000054`, `0x0800342c` returning `0x00000403` and `0x08003430` returning `0x04000006`, which are BLDY, DISPCNT and DISPSTAT and which match the image. And the synchroniser did not cause the garble: the pre-synchroniser build run on the same cartridge shows a solid white field with no text at all, so the synchroniser changed a blank field into a garbled one rather than breaking a working picture. What then stopped the cycle is that the instrument cannot be trusted for this question. Asked what `test_logo.gba` draws, three configurations give three answers: the board paints solid green and passes all eight checks (BRD-051); the controller harness dumps pure black at frames 200 through 700; and the array-model harness dumps pure white but reports only 60 cartridge fetch cycles against millions on the controller build, so it is not executing the cartridge at all. The dump code itself is sound, writing the same `screenbuffer` the SDL texture is built from, so the disagreement is not a broken file writer. The harness therefore represents at least one board state faithfully, the diagnostic cartridge, and at least one badly, `test_logo`, and a harness-only result about a picture cannot be carried to the board until that is explained. Recorded as TCL-037 with the disagreement stated as a fact and the likely cause stated as an untested hypothesis, since `screenbuffer` is written only where `pixel_out_we` is high and is never cleared per frame. Two permanent instruments were added behind defines that no synthesised build sets, `TINYGBA_DMADBG` in `gba_dma_module.sv` and `TINYGBA_VRAMDBG` in `gba_gpu_drawer.v`, so the DMA and VRAM write paths can be traced again without rewriting them. Nothing was flashed after the operator's instruction not to touch the Tang, which stood for the whole cycle. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 55 were not rewritten, confirmed TCL-037 carries a unique id and the canonical field order, and validated this entry as entry 56 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty-six against the 100-entry limit.

#### Next Steps:

Settle the harness's display fidelity before using it again for a picture question, because every conclusion in this cycle rests on it and one cartridge already contradicts the board. The concrete test is to clear `screenbuffer` at each frame boundary and check whether `test_logo` then dumps green in the controller harness; if it does, the disagreement was the never-cleared buffer and the harness becomes usable, and if it does not, the harness's display path differs from the board's in a way that needs its own investigation before any picture claim. Do not use the array-model harness for display questions at all, since it did not reach the cartridge. Once the harness is trusted, the fault to pursue is the garbled tile data: position, height and palette are correct and only the glyph patterns are wrong, which points at the tile or bitmap data the drawer reads rather than at the mode-3 drawing path that `test_logo` exercises successfully. `TINYGBA_VRAMDBG` and `TINYGBA_DMADBG` are in place for that. Separately, the two known faults that remain are unchanged and independent of this work: BRD-045's DMA `REQ1_START` deadlock, verified and untouched since entry 43, and the possibility that the diagnostic cartridge relies on a tile or affine feature this core does not implement, which mGBA can rule in or out and which the operator was asked to check. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment.

#### Files Modified:

- fpga/gba/src/gpu/gba_gpu_drawer.v
- fpga/gba/src/memory/gba_dma_module.sv

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 57 COMMIT Unreleased 2026-11-13T22:21:16-07:00

#### Coming From:

Unreleased 0712bce

#### Purpose:

Find why the harness and the board disagree about the same cartridge's picture, after entry 56 left that disagreement blocking any further work on the garbled-text hang.

#### Outcome:

The disagreement is explained as far as the harness can explain it, and the explanation is a harness defect on the store data path rather than a rendering difference. The decisive instrument was a final framebuffer dump taken from the buffer the picture is built from, added to the harness because dumping frames on a schedule had already given two misleading readings: asked what `test_logo.gba` draws, the harness reports `FINALFRAME: nonzero=0 white=0 green=0 of 38400`, an entirely blank screen, against the board's solid green of BRD-051. The cause is a corrupted store. The cartridge's `ldr r0,=0x0403` at `0x0800025C` reads the literal at offset `0x2E0`, and the harness's own read trace reports that read returning `0x00000403`; the following `strh r0,[r11]` at `0x08000260` is then reported committing `0x00000008`, and that is the last write to `0x04000000` in the run, leaving DISPCNT at mode 0 with BG0 rather than mode 3 with BG2, which is exactly a black screen. Two earlier writes in the same trace carry `0x04000000` -- an address where data belongs -- which points at the store data path rather than at the cartridge. So within one harness run the load is right and the store is wrong, and the board completes both correctly. Recorded as BRD-052. Getting there required fixing three defects in my own instruments, each of which had produced a plausible wrong reading: a VRAM write trace sampled on `fclk` when the memory latches on `mclk`, which reported zero data for every write; the same trace capped at 400 lines, which filled entirely during the BIOS's VRAM clear and never reached the cartridge, making a zero-writing machine look like a real finding; and, most consequentially, the harness's `DISPCNTWRITE` trace was never gated on `cpu_en_r` although the read trace beside it was, so a store held on the bus was logged once per cycle and one `strh` appeared as four identical writes followed by a stray fifth. Correcting that last one changed the sequence completely and is recorded as TCL-038, with the note that the board-side readouts are unaffected because they come from the RTL recorder and not from this harness. No RTL was changed for the machine itself; the only source edits are instrumentation guarded by defines that no synthesised build sets, plus the harness dump and the trace gate. The Tang was not touched at any point in this cycle, per the operator's instruction. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 56 were not rewritten, confirmed BRD-052 and TCL-038 carry unique ids and the canonical field order, and validated this entry as entry 57 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty-seven against the 100-entry limit.

#### Next Steps:

Trace `ram_wdata` against the instruction that issued it, in the harness, for the single store at `0x08000260`, because the load into the same register is already known good and the corruption is therefore between that register and the store bus. The specific question is whether `ram_wdata` carries `0x0008` at the moment `ram_cen`/`ram_wen` assert or whether it carries `0x0403` and is corrupted later; the first would put the fault in the CPU's register read for a store, and the second in the memory block's use of the bus. Do not trust the harness's previous `DISPCNTWRITE` sequences, and re-read any earlier conclusion that counted writes from it, noting that the board-side records BRD-050, BRD-051 and the entry 42 and 43 readouts come from the RTL recorder and are unaffected. Once the store path is explained, return to the actual goal: the RetroRegen cartridge's text is smeared on the board with correct position, height and palette and only the glyph bit patterns wrong, which points at tile or bitmap data rather than at layout, and `TINYGBA_VRAMDBG` and `TINYGBA_DMADBG` are in place for that. Two independent faults remain recorded and untouched: BRD-045's DMA `REQ1_START` deadlock, verified since entry 43, and the question of whether the diagnostic cartridge depends on a feature this core does not implement, which mGBA can settle quickly. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment.

#### Files Modified:

- tools/sim/sim_main.cpp
- fpga/gba/src/gpu/gba_gpu_drawer.v
- fpga/gba/src/common/sim_dpram_be.sv

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 58 COMMIT Unreleased 2026-11-13T22:46:44-07:00

#### Coming From:

Unreleased 6adf959

#### Purpose:

Trace the store data path that entry 57 identified as the cause of the harness and board disagreeing about the same cartridge's picture.

#### Outcome:

The store-path trace disproved the finding it was built to confirm, and BRD-052 is withdrawn. A `STOREDBG` trace was added to the harness reporting the address, data, byte enables and PC of every write to DISPCNT, gated on `cpu_en_r` as TCL-038 requires, and calibrated on the RetroRegen cartridge first because that run produces a correct DISPCNT write: `wdata=0x00000403` at `pc=0x0800334C`, which is that cartridge's real store. On `test_logo` the same trace reports DISPCNT writes at `pc_rom` values `0x08000068`, `0x080000D4` and `0x0800026C`. A scan of the cartridge image for the ARM store encodings gives real store sites at `0x06C`, `0x070`, `0x0C8`, `0x114`, `0x144`, `0x174`, `0x1A4`, `0x1D4` and `0x260`, and none of the three reported PCs is among them: `0x068` holds `F130956F`, `0x26C` holds `E59F5070` (`ldr r5,=0x7FFF`) while the store is one instruction earlier at `0x260`. The harness is therefore attributing stores to instructions that are not stores, roughly three instructions late. That makes the `0x00000008` of BRD-052 whatever the datapath held three instructions after the real store rather than what the cartridge's `strh` carried, and the `0x0403 >> 7 = 0x0008` agreement I noticed is a coincidence of that later state and not evidence of a shifter fault. BRD-052 is rewritten in place to record the withdrawal rather than deleted, because a plausible mechanism was published for a few hours and the correction is the useful part. What survives from BRD-052 is only the observation it was built to explain: the harness's final framebuffer is empty for `test_logo` while the board's is solid green, and that is still unexplained. TCL-039 records the attribution defect and the check that would have caught it on the first run, which is to compare a trace's reported PC against a precomputed list of real store sites. Eleven instrument defects have now been found in this project's harness work across entries 53 to 58, each of which produced a plausible wrong reading, and that count is itself the finding: the harness needs its own verification before any conclusion about the machine rests on it. Nothing was changed in the RTL of the machine, nothing was built for the board, and the Tang was not touched at any point in this cycle. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 57 were not rewritten, confirmed TCL-039 carries a unique id and the canonical field order and that BRD-052's withdrawal preserves its field order, and validated this entry as entry 58 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty-eight against the 100-entry limit.

#### Next Steps:

Stop treating the harness as an authority on the machine's picture until its own output is verified against something the board already knows, because eleven instrument defects across six entries have each produced a believable wrong answer and the pattern is now the dominant risk in the work. The cheapest verification is the one TCL-039 names: give the harness a self-check that compares every traced bus event against a precomputed list of real instruction sites for the loaded cartridge, and fail loudly when a trace reports activity at an address that does not decode to that kind of instruction. That single check would have caught the store mis-attribution, and a register-file dump compared against a real emulator's would catch the next class. Only then is the empty framebuffer for `test_logo` worth debugging, and it should be debugged as a harness question rather than a machine question, because the board draws that cartridge correctly. Separately, the machine faults that are actually established and independent of the harness remain: the RetroRegen cartridge's text draws with correct position, height and palette and wrong glyph patterns, which points at tile or bitmap data; BRD-045's DMA `REQ1_START` deadlock, verified since entry 43 and untouched; and whether that cartridge depends on a feature this core does not implement, which mGBA can settle in a minute and which has been asked for twice without an answer. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment.

#### Files Modified:

- tools/sim/sim_main.cpp

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 59 COMMIT Unreleased 2026-11-14T00:01:53-07:00

#### Coming From:

Unreleased 0115f10

#### Purpose:

Take the RetroRegen cartridge's failure to the board with purpose-built probes, after the harness was withdrawn as untrustworthy for picture questions.

#### Outcome:

Three new probes were built and all three pass on the board, which narrows the retail-cartridge failure without explaining it. `tools/make_vram_probe_rom.py` writes a four-band pattern into frame memory in mode 3 and reads every halfword back, painting a white border when all 38,400 readbacks matched; the board shows all four bands and a white border, so writing frame memory, reading it back, and the drawer's read are all correct. `tools/make_romprobe_rom.py` stores each checkpoint's own offset at that offset every 64 KiB across a 1 MiB image and paints one square per checkpoint; all fifteen are green, which is the first test of a cartridge read above 4 KiB on this board. `tools/make_alu_probe_rom.py` scores fifteen operations a text renderer depends on, five multiplies, `mla`, three shifts, add with wrap and carry, subtract with borrow, and the shift-pair forms of unsigned byte, signed byte and signed halfword extension; all fifteen are green and the end marker is reached. That last one matters most: a wrong multiply or shift would produce exactly the observed symptom, glyphs at the correct position and size with wrong patterns, because a renderer computes a glyph address as `base + (char - 32) * bytes_per_glyph`, and the hypothesis is now excluded by measurement rather than by argument. Two corrections to my own readings belong in this entry. The first VRAM capture appeared to show a red border, which would have meant every readback failed; re-measuring at the correct offset showed a white border and the earlier reading was a sampling error in my analysis script, not the machine. And a fourth probe testing VBlank interrupt delivery and HALT drew nothing in three runs, which is what a machine that never delivers an interrupt would do and also what a broken probe would do, so it is recorded as inconclusive and deleted rather than kept; two defects were found in it while trying, a counter placed inside the BIOS's interrupt stack region and an ARM `halt` instruction ARM7TDMI does not have, and fixing both did not make it draw. Recorded as BRD-053 for the three results and TCL-040 for the asymmetry that makes a silent probe unreadable. The Tang was used only to load cartridges over UART and read the capture; no bitstream was rebuilt or flashed, because the image under test is unchanged from BRD-051. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 58 were not rewritten, confirmed BRD-053 and TCL-040 carry unique ids and the canonical field order, and validated this entry as entry 59 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of fifty-nine against the 100-entry limit.

#### Next Steps:

Build the interrupt probe properly, with a control, because interrupts and HALT are now the largest untested subsystem and the most plausible remaining cause of a cartridge that draws some text and then stops. The control is the important part and it is cheap: a variant that draws a fixed green square with no interrupt setup at all, loaded immediately before the real probe in the same session, so that "the real probe drew nothing" can be distinguished from "this cartridge never ran". Then the real probe should test the pieces separately rather than in one program, one square each for: the handler pointer at `0x03007FFC` being taken, `IME` and `IE` enabling, the VBlank flag in `DISPSTAT` rising at all, `HALTCNT` waking the CPU, and the handler being entered. Each square reports independently, so a partial failure names itself. Separately the probe results say where not to look: do not re-test VRAM write, read or display, do not re-test cartridge reads below 1 MiB, and do not re-test multiply, shift or sign extension. If interrupts prove sound too, the remaining candidates for the RetroRegen failure are DMA, timers, execution of code spread across a large image, and the mode 0 tile path, which none of the three probes used because all three draw in mode 3. Closing mGBA on the diagnostic cartridge is still the cheapest way to learn whether the cartridge itself needs something unimplemented, and it has now been asked for three times.

#### Files Modified:

- tools/make_vram_probe_rom.py
- tools/make_romprobe_rom.py
- tools/make_alu_probe_rom.py

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: NOT RUN

---

## 60 COMMIT Unreleased 2026-11-14T00:08:06-07:00

#### Coming From:

Unreleased 0bafdf7

#### Purpose:

Run the RetroRegen diagnostic cartridge under mGBA to learn whether the cartridge itself is sound, since three board probes had narrowed the Retail-cartridge failure without locating it.

#### Outcome:

The cartridge is sound and the board is at fault, and the comparison changes the diagnosis from corruption to addressing. mGBA 0.10.5 renders the RetroRegen cartridge completely: a title screen reading `RETRO REGEN HANDHELD HARDWARE TEST SUITE v1.5` over an illustration, and behind Start a menu listing `QUICK TEST`, `SYSTEM STATUS`, `MEMORY TEST`, `SCREEN TEST`, `GPU STRESS TEST`, `BUTTON TEST`, `AUDIO TEST`, `BURN-IN TEST` and `ABOUT / HELP` above a dashed rule, `MODEL: GBA FAMILY (AGB BIOS)` in orange, and `GUIDED FULL CHECKOUT WITH A PASS/FAIL SUMMARY`. Compared against the board at native 240x160, the board draws exactly one text row, at rows 128 to 147 including descenders, in orange -- the same vertical region and the same colour as mGBA's model line. But the two agree on only 55.3 percent of pixels, which is the agreement of two unrelated patterns rather than of one image with bit errors, while their ink density is close, 607 lit pixels against 537. So the board is not drawing that line with corrupted bits, it is drawing different glyph data: the fault is in what selects a glyph, not in what carries its bits. Recorded as BRD-054. That reframes the remaining candidates because the cartridge sets DISPCNT to `0x0403`, mode 3, so it renders text in software and copies glyph bitmaps into frame memory itself. Cartridge reads are correct to 1 MiB and frame-memory write, read and display are correct, both measured on the board by BRD-053, so a software copy should work; what lies between a ROM read and a frame-memory store and has never been measured on hardware is DMA. A DMA probe was written for it and reported five failures out of five on the board, which would have meant DMA is entirely dead. It was then run under mGBA as a control and reported the same five failures there, so the probe was wrong and the board was innocent. Two probe defects were found and fixed, 32-bit reads from VRAM which does not support 32-bit access, and a DMA source address loaded with `=DMASRC` where the assembler resolves the symbol to a link-time offset so the transfer read from the BIOS region rather than the cartridge; the control still failed after both fixes, so a third fault remains and the probe is recorded as invalid rather than as a result. No claim is made about the machine's DMA. Recorded as TCL-041, which also states the operational rule this cycle produced: run every probe under mGBA and require it to pass there before reading its board result. The Tang was used only to load cartridges over UART and read captures; no bitstream was rebuilt. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 59 were not rewritten, confirmed BRD-054 and TCL-041 carry unique ids and the canonical field order, and validated this entry as entry 60 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of sixty against the 100-entry limit.

#### Next Steps:

Fix the DMA probe until it passes under mGBA before running it on the board again, because that is the only way its red squares can be believed; the third fault is in the probe and not in the machine, since the machine and the emulator agree. The most likely remaining defect is in the DMA control word rather than in the addresses, since both addressing mistakes are fixed: the transfer count, the start-timing field, or writing `CNT_L` and `CNT_H` as one 32-bit store to `0x040000DC` when the hardware may require them written separately. Once the control passes, the board result becomes meaningful, and DMA is the leading candidate for the RetroRegen failure because it is the only path between the two measured-good ends of that cartridge's text copy. Keep using mGBA as the control for every probe from now on, and use it to answer what the board cannot: whether a cartridge depends on a feature this core lacks. Separately, the objective has been drifting for many entries and should be restated before more of this work: `test_logo` passes all eight checks green on the board (BRD-051), three subsystems are measured good (BRD-053), and the failure that remains is a diagnostic cartridge and retail titles. Do not re-test VRAM access, cartridge reads below 1 MiB, or CPU arithmetic. Do not re-apply the control-path deferral of entry 46, the pipelined pair of entry 47, or entry 33's clock-lane experiment.

#### Files Modified:

- tools/make_dma_probe_rom.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---

## 61 COMMIT Unreleased 2026-11-14T00:18:25-07:00

#### Coming From:

Unreleased 10dc6c1

#### Purpose:

Fix the DMA probe until it passes under mGBA, then use validated probes to test the paths that could still explain a cartridge drawing one text row and stopping.

#### Outcome:

Four more subsystems are measured good on the board, and none of them is the fault. The invalid five-check DMA probe was abandoned rather than repaired and replaced with a minimal one, `tools/roms/minidma.s`, about a hundred lines: clear frame memory to `0x001F` with CPU stores, DMA3 64 words from cartridge ROM to `0x06000000` with control word `0x8400003F`, read the first destination halfword and paint the screen green for the expected `0x0000`, red for the clear value, blue for anything else. It is green in mGBA and green on the board, 1,730,160 green pixels with no other colour, and the operator confirmed the screen filled completely green while I was reading it. Then `tools/roms/byteprobe.s` tested eleven byte loads from ROM at consecutive offsets and four more from a deliberately unaligned base -- the access pattern a font decoder uses, which no earlier probe exercised and which BRD-034 once confined a read defect to -- and all fifteen squares are green in mGBA and green on the board. `tools/roms/irqprobe.s` polls the `DISPSTAT` VBlank flag and paints green if it ever rises; that square is green in both. Its two `HALT`-based checks are red in mGBA as well, so they are the probe's defect and no board result is read from them. That last point cost a cycle and is the reason the earlier interrupt probe had been deleted: the control has to pass before a board result means anything. The list of parts measured good on this hardware is now frame memory write, read-back and display; cartridge reads at every 64 KiB to 1 MiB; fifteen arithmetic operations; DMA3 ROM to frame memory; byte loads including unaligned; and the VBlank flag. Every individual operation the RetroRegen cartridge performs to copy a glyph and store it has been tested and works, and the machine still draws exactly one text row of that cartridge from the wrong glyph data (BRD-054) and then stops. Since each operation is good in isolation, the remaining explanations are about execution rather than about an operation. `tools/make_probe_rom.py` was added with the three sources under `tools/roms/`, because `core.md` requires a diagnostic the operator may run to be produced by a committed deterministic script rather than assembled by hand into `/tmp`; it rebuilds all three byte-identically to the images that were tested, and it refuses an image whose header byte `0xB2` has slipped, which is a mistake made twice in this session. Recorded as BRD-055 and BRD-056. Nothing was rebuilt for the board; the image under test is unchanged from BRD-051. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 60 were not rewritten, confirmed both new records carry unique ids and the canonical field order, and validated this entry as entry 61 with six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status set and a count of sixty-one against the 100-entry limit.

#### Next Steps:

Test execution rather than operations, because every operation is now measured good and the failure must be in how the cartridge runs overall. The three specific things worth testing, in the order they are likely to matter: whether the CPU executes correctly from a large image, since every probe is 4 KiB and the failing cartridges are 284 KiB and 4 MiB -- a probe placed at a high ROM offset that must run a loop there would test the instruction-fetch path beyond the first few kilobytes, which nothing has done; whether `HALT` wakes and the handler is entered, using a probe whose control passes in mGBA this time; and whether the mode 0 tile path works, since every probe draws in mode 3 and the diagnostic cartridge's own menu is tile-based even though its text is software-rendered. If the cartridge turns out to need a feature this core lacks, mGBA answers that immediately by showing which part of the menu it reaches, so comparing the board against mGBA at the same instant is cheaper than another probe. Keep the discipline TCL-041 records for every one of these: mGBA first, board second, and a probe that fails in the emulator is a probe defect and nothing else.

#### Files Modified:

- tools/make_probe_rom.py
- tools/roms/minidma.s
- tools/roms/byteprobe.s
- tools/roms/irqprobe.s

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: NOT RUN

---

## 62 COMMIT Unreleased 2026-11-14T01:10:00-07:00

#### Coming From:

Unreleased bb4676d

#### Purpose:

Repair the interrupt probe until its mGBA control passes, then use it to measure cartridge interrupt dispatch on the board -- the last subsystem a cartridge relies on that no board reading had ever covered.

#### Outcome:

Real interrupt dispatch is measured good on the board, and getting there cost three instrument defects that each would have read as a machine fault. The first probe's handler pointer was computed with `ldr r1, =0x08000000 + _irq`, which cannot resolve because `as` gives `_irq` as a section offset and `objcopy` re-bases `.text` to zero; the replacement used `adr` and kept the base addition on the theory that the same correction still applied, producing `0x1000031C` -- unmapped -- so every interrupt jumped into open bus. An mGBA GDB session showed `pc = 0x1000031c` and `[0x03007ffc] = 0x1000031c` and named it in one reading; recorded as TCL-042. The second defect was that the handler acknowledged VBlank by storing to `0x04000200`, which is `IE`, while `IF` is the halfword at `0x04000202`. The source stayed pending, the interrupt was re-taken before the interrupted instruction could retire, the handler ran continuously and the main flow made no progress. On screen that is a machine whose handler visibly runs and which never resumes -- the exact signature the earlier probe had been misread as `lr` trouble, and a `sub lr, lr, #4` added on that theory changed nothing. Disassembling the shipped BIOS settled the `lr` question without experiment: `0x128 push {r0-r3,ip,lr}`, `0x12c mov r0,#0x04000000`, `0x130 add lr,pc,#0`, `0x134 ldr pc,[r0,#-4]` hands the handler `lr = 0x138`, the dispatcher's own `pop`, so a plain `bx lr` is correct and subtracting four re-dispatches forever; recorded as TCL-043. The third defect was mine in the tooling: breakpoint addresses taken from `nm` on a build that predated a prologue edit sat 0x20 low, so the "handler entry" breakpoint never fired and the "loop exit" one fired immediately, which produced the confident and false conclusion that no interrupt was ever dispatched; re-reading `nm` from the current object put `_irq` at `0x33c` and the handler then hit first, as it should. Recorded as TCL-044. `tools/roms/irq3.s` is the probe that resulted, built by `tools/make_probe_rom.py`, and it passes in mGBA 0.10.5 with the retail BIOS before its board result was read, per TCL-041. Board and mGBA agree exactly: square 0 green for the VBlank flag rising, square 1 green because the BIOS hands the cartridge `IE` and `IME` both clear, square 2 green for the pointer readback, square 3 blue painted immediately after `IME = 1` proving the main flow survives the first interrupt, square 4 green for a completed dispatch, a white bar 8 pixels long meaning exactly one interrupt, and three white markers in the top right corner that the handler paints at entry, after its IF acknowledge and after its count increment. Recorded as BRD-057; `tools/roms/irq2.s` was deleted rather than kept, because it was a broken instrument and nothing references it. A second probe, `tools/roms/swiprobe.s`, was then written to test the BIOS SWI path a cartridge uses every frame: SWI `0x06` Div, one SWI `0x05` VBlankIntrWait, sixty consecutive VBlankIntrWait calls, and the handler's wake count, with a blue marker drawn before the first SWI so a dead SWI can be told from a dead cartridge. It does not pass in mGBA. The screen is black, the emulator reports 60 fps, `DISPCNT` is written correctly, and an audit of every literal reference in the image confirms each one lands on the right constant, so the fault is in the probe and not yet found. Following TCL-041, no board result is read from it and no conclusion about SWI dispatch is drawn. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 61 were not rewritten, the four new records carry unique ids and the canonical field order, and this is entry 62 with the five canonical sections plus Status, a one-sentence Purpose and a count of sixty-two against the 100-entry limit.

#### Next Steps:

Find the `swiprobe` defect before reading anything from it. The remaining suspects, cheapest first: that the blue marker is not reached because of something in the clear loop's handoff rather than in the SWI, which a marker painted before the clear loop would settle; and that the SWI test's own register use clobbers `r9` or `r10` and takes the square routine with it. Once it passes in mGBA, run it on the board, because SWI `0x05` is the single most likely thing a retail cartridge waits on and the observed failure -- a cartridge that runs briefly and then stops, having drawn part of one frame -- is exactly what a frame wait that never returns looks like. If SWI dispatch is good, the next candidate is the DMA `REQ1_START` deadlock already recorded as BRD-045, which was verified before the display worked and has not been revisited since.

#### Files Modified:

- tools/roms/irq3.s
- tools/roms/swiprobe.s
- .ai/core-reference.md

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: NOT RUN

---

## 63 COMMIT Unreleased 2026-11-14T01:55:00-07:00

#### Coming From:

Unreleased eda5e33

#### Purpose:

Measure the BIOS call path a cartridge uses -- first that SWI dispatch works at all, then whether the frame wait retail software performs every frame returns.

#### Outcome:

BIOS SWI dispatch is measured good on the board, and the frame wait is not measured at all. `tools/roms/swidiv.s` paints blue when the cartridge reaches its first BIOS call and green when `swi 0x06` returns quotient 142 and remainder 6 for 1000 / 7. It passed in mGBA 0.10.5 with the retail BIOS first, per TCL-041, and the board agrees exactly: blue `(0, 0, 232)` and green `(18, 255, 0)`. Reaching that probe cost one more instrument defect, and it is the most instructive of the four: on GBA ARM code the SWI number belongs in bits 23-16, because the retail BIOS dispatcher reads it with `ldrb r12,[lr,#-2]` and in ARM mode `lr = address + 4`, so the byte fetched is at `address + 2`. `swi 0x06` assembles to `06 00 00 EF`, the dispatcher reads `0x00`, and calls SWI 0 -- SoftReset -- which reboots the cartridge. Every apparent hang in this cycle was a self-inflicted reboot, under the retail BIOS and under HLE alike, and a reboot is indistinguishable from a hang in a screenshot. An mGBA gdb session stepping the call showed `pc` 0x08000100 to 0x00000008 to 0x00000140 and then the `ldrb`. Recorded as BRD-058 and TCL-045, and it also gives a second explanation for a cartridge that appears to return to the BIOS startup sequence. Then `VBlankIntrWait` was attempted five ways and none of them passed in mGBA, so by TCL-041 none of them was taken to the board and no conclusion about the frame wait is drawn. The four shapes: with a handler that acknowledges IF, which deadlocks because the BIOS halts and polls IF while the handler clears it; with a handler that leaves IF set, which deadlocks the other way because the interrupt is re-taken before the BIOS can run its check; with no handler at all, which is how retail software calls it; with no handler plus `DISPSTAT` bit 3 enabled, because VBlank's IF bit may only be raised while that interrupt is enabled; and with no handler plus `DISPSTAT` bit 3 and `IE` bit 0 both enabled, which the disassembly suggests should be required. That last one follows from reading the routine: `IntrWait` at 0x330 halts via `HALTCNT` at 0x344 and calls 0x358, which writes IME and only IME -- `strb r3,[ip,#0x208]` before its check and `strb r4,[ip,#0x208]` after it -- so the caller must enable the bit in IE for the HALT to wake, and every earlier shape of this probe had cleared IE and never set it. That reasoning is sound and the probe still hangs, so either the caller must do something further or the decode of 0x358 is still not trustworthy: it reads a halfword at `[ip,#-8]`, which decodes to 0x03FFFFF8, an IWRAM mirror rather than the `IF` register the comparison implies. All five shapes show the blue square and then nothing, which puts the cartridge inside the call every time. The remaining difference from retail software is one this session has not established: what the BIOS's own `IntrWait` at 0x330 actually requires, which the disassembly so far has not settled -- its loop halts at `HALTCNT`, calls 0x358 to enable IME, read a halfword and conditionally clear flags, and re-halts while that comparison says nothing matched, and the halfword address decodes to 0x03FFFFF8, an IWRAM mirror rather than IF, so either the routine being read is the wrong one or the decode needs more care before it can be trusted. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 62 were not rewritten, the two new records carry unique ids and the canonical field order, and this is entry 63 with the five canonical sections plus Status and a count of sixty-three against the 100-entry limit.

#### Next Steps:

Settle what the BIOS `IntrWait` routine requires before writing another version of the probe, by disassembling 0x328-0x358 completely and confirming the table entry for SWI 5 rather than inferring it from the tail; the probe has now been rewritten four times against hypotheses that the routine itself can answer. If that shows a precondition the probe lacks, add it and require mGBA to pass before the board is touched. If it shows nothing missing, the honest next step is a different instrument: a cartridge that performs exactly one `VBlankIntrWait` and then writes a marker, run on the board with the display already proven, so that the board's behaviour is compared against mGBA's rather than against a theory. The other open candidate is BRD-045's DMA `REQ1_START` deadlock for Super Mario Advance, verified before the display worked and not revisited since, and it is now the only recorded cartridge-specific failure that has not been re-examined.

#### Files Modified:

- tools/roms/swidiv.s
- tools/roms/irqprobe.s
- .ai/core-reference.md

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: NOT RUN

---

## 64 COMMIT Unreleased 2026-11-14T09:40:00-07:00

#### Coming From:

Unreleased 8fc894c

#### Purpose:

Re-examine BRD-045's DMA deadlock against the current image, since it was verified before the display worked and had not been revisited.

#### Outcome:

DMA3 from cartridge ROM does not deliver data on the board. It completes and it writes zeroes. `tools/roms/dmawrote.s` pre-fills a destination with a sentinel, runs one transfer from cartridge ROM, and then asks three separate questions of the destination: did it change at all, does it hold the source word, and is it exactly zero. The binary is required to pass in mGBA before any board result is read, per TCL-041, and in mGBA it reports changed, correct and not-zero. On the board, on three consecutive captures, it reports changed green, correct red and zero green: the location was written, it is not the source data, and it is exactly zero. The RTL is consistent with that. In `gba_memory.sv` the BRAM write data is driven from `dma_wdata` while `state == MAIN`, and the buffered write path is armed by `if (~dma_on & rom_en & ram_cen)`, which is false throughout a DMA because `dma_on` is high; so a transfer from an SDRAM source to a BRAM destination never presents the fetched words to the destination's write port. IWRAM and VRAM are wired identically (`wre(bram_wr & sel_iwram)` and `vram_lo_we = bram_wr & sel_vram`, both with `bram_wdata`), so the account predicts the same fault for both, which is what was measured. This withdraws BRD-055, whose `minidma` probe painted green when the destination read `0x0000` -- and `0x0000` is exactly what a transfer that writes zeroes leaves -- so its green certified the broken path rather than the working one. That blind spot is recorded as TCL-047 and BRD-055 now carries a WITHDRAWN title and status rather than being quietly reworded. BRD-045 was not reproducible on this image: Super Mario Advance does not freeze in `REQ1_WAIT`, it boot-loops the BIOS (BRD-059), and Dr. Mario completes the BIOS and then never enables the display (BRD-060); both are now explained by this one fault, because a `crt0` that copies its own code into IWRAM by DMA receives zeroes, and the ARM encoding of zero is `andeq r0, r0, r0` repeated, so execution either wanders into unmapped memory and resets or wedges. It also explains the shape of the whole investigation: every probe built in this session used CPU stores and every one of them passed, `test_logo.gba` passes and draws correctly because it uses no DMA, and the cartridges that fail are exactly the ones that do. Four probes were written and discarded during this cycle because each compared its destination only against an expected pattern, which cannot separate "not written" from "written wrongly"; `dma3dest`, `dmaalias`, `dmaalias64` and `dmamin` were deleted and `dmawrote` asks the question that separates them. `tools/roms/minidma.s` keeps its source but now carries an UNSOUND COMPARISON note. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 63 were not rewritten, the two new records carry unique ids and the canonical field order, BRD-055's withdrawal preserves its original text with the status changed, and this is entry 64 with the canonical sections and a count of sixty-four against the 100-entry limit.

#### Next Steps:

Fix the DMA-to-BRAM write path, because it is now the single fault standing between this core and a booting cartridge, and the RTL names where it is. The write data for a BRAM destination must come from the fetched SDRAM read data on the cycle after the acknowledgement, not from `dma_wdata` in `state == MAIN`; the mechanism the CPU path already uses for rom-plus-ram accesses, where `bram_wr_buf`, `bram_wdata_buf` and `bram_be_buf` are loaded in `REQ1_WAIT` and replayed in the wait states, is the shape the DMA path needs, and the `~dma_on` term that excludes DMA from arming it is the specific thing to change. Before any rebuild, re-run `dmawrote.gba` under mGBA to confirm it still passes there and then on the board, because that probe is the gate this fix has to satisfy. Then re-test Super Mario Advance and Dr. Mario, which are the two observations that should change: SMA should stop looping the BIOS and Dr. Mario should get past handover. Two records elsewhere still rest on the withdrawn BRD-055 and must be corrected when the tree is next reviewed -- BRD-055's consequence lists the DMA path among the subsystems measured good, and entry 61's summary repeats it. `minidma`'s zero-comparison blind spot may not be unique to it, so any other probe expecting `0x0000` should be re-read under TCL-047 before its result is quoted again.

#### Files Modified:

- tools/roms/dmawrote.s
- tools/roms/minidma.s
- .ai/core-reference.md

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: NOT RUN

---

## 65 COMMIT Unreleased 2026-11-14T11:20:00-07:00

#### Coming From:

Unreleased 1d5f8a7

#### Purpose:

Fix the DMA-to-BRAM write path that BRD-062 identified as the last fault between this core and a booting cartridge.

#### Outcome:

No fix was landed, and the fault was narrowed from two candidate ends to one. Two RTL changes were written and both were reverted without being built, because each altered the data seen in simulation, which is the signature of breaking working behaviour rather than repairing broken behaviour. The reasoning was that a latch was needed on the DMA read data inside `gba_memory`; the first version captured on the raw ready and produced a half-assembled word (`0x00001111` where `0x11111111` was correct), and the second captured at the acknowledgement and produced a one-word lag. Both were measured in the Verilator model with `-DTINYGBA_SDRAM_RTL -DTINYGBA_DMADBG`, in which the unmodified RTL prints `DMAWR: adr=3001000 dat=11111111`, `adr=3001004 dat=22222222` and so on, i.e. the design is correct there. That is the decisive fact of the cycle: the same binaries transfer correctly in simulation against the real `sdram_gba.v` controller and the pin-level SDRAM model, and fail on the board, so the remaining fault is hardware-only and a candidate patch cannot be tested against a model that does not exhibit it. Instead the fault was localised with two probes. `tools/roms/dmastep.s` verifies its own preconditions in the same image -- it writes 0xF00D to the destination and reads it back, and reads the source back -- and on the board both are green while the DMA copy is red and the destination holds neither the pattern nor its pre-fill. `tools/roms/dmaside.s` varies the source across IWRAM to EWRAM, IWRAM to IWRAM, EWRAM to IWRAM and cartridge ROM to IWRAM: all four are red on the board and all four are green in mGBA. The IWRAM-to-IWRAM case settles the question, because neither end touches SDRAM, so the SDRAM read path is cleared and the fault lies in the value presented on `bram_wdata` during the DMA write cycle. Recorded as BRD-063 and TCL-048. Four probes written earlier in the cycle were deleted for conflating "not run" with "ran wrongly", and `dmastep` exists because of that lesson: it reports its own preconditions rather than assuming them. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 64 were not rewritten, the two new records carry unique ids and the canonical field order, the RTL tree is unmodified by this entry, and this is entry 65 against the 100-entry limit.

#### Next Steps:

Build the instrument, not the patch, because the fault cannot be reproduced in simulation and every candidate patch therefore changes behaviour that currently works. What is needed is the value `gba_memory` drives on `bram_wdata` and the value of `dma_rdata` during the write cycle, read back from the board. The machinery for this already exists in `gbatang_top.sv`: pages 2 and 3 of the trace port carry the MMIO write ring and the status pages, and the stall-trace ring at 1440 already records 1,024 registers, so the cheapest path is a sixth page or a ring slot that captures the DMA write data and address on the cycle `bram_wr` is high while `dma_on` is set. An alternative that needs no rebuild at all is a probe that makes the wrong value self-identifying: DMA a source whose words are all distinct, then copy the destination back to VRAM with CPU stores as a bitmap, since the observed destination value is exactly zero and a distinct-pattern transfer would show how many words were written and in what order. Whichever route is taken, do not attempt another speculative `gba_memory` latch: two have already been tried, both were wrong, and both were visible as wrong in a model that does not have the bug.

#### Files Modified:

- tools/roms/dmaside.s
- tools/roms/dmastep.s
- .ai/core-reference.md

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: NOT RUN

---

## 66 COMMIT Unreleased 2026-11-14T14:05:00-07:00

#### Coming From:

Unreleased 3474ffa

#### Purpose:

Act on a second agent's analysis that the board netlist was mis-synthesised, and repair the two independent defects it exposed.

#### Outcome:

The root cause of the retail-cartridge failures is found, and it is not in the design's logic. Three helper functions in `gba_memory.sv` -- `issingle`, `isreadonly` and `tosdram` -- were declared without `automatic`. In SystemVerilog a static function has one shared module-level variable per argument, so every call site drives the same variable; these three are called from two `always @*` blocks, the clocked FSM and two more combinational blocks. Yosys reported 72 `multiple conflicting drivers` warnings against `mem.tosdram.addr` (56), `mem.issingle.region` (8) and `mem.isreadonly.region` (8), those being the only multi-driven signals in the whole design and exactly the memory and DMA arbitration. The warning had been present in every synthesis of this tree including the deployed bitstream and had been overlooked. A minimal reproduction with the same front end showed the consequence is silicon-visible: the static form emits four input buffers all driving one net that is also tied to GND plus a combinational output tied to VCC, while the `automatic` form emits a correct bus and real LUTs. Declaring every static function in the tree `automatic` took the count from 72 to 0. A second defect lay underneath it and was found by following the flagged undriven nets: `dma_bus_unread` was connected to nothing at the top level, with its declaration commented out, and it sits in the single condition deciding whether a DMA transmits the word it just read or a stale buffer. In simulation an undriven wire is 0 so the first arm is taken and real data moves; `synth_gowin` treats it as `x`, `opt` folds the condition to constant false, and the bitstream always took the second arm and transmitted `last_dma_in`, which is zero on a first transfer. That is exactly the measurement BRD-062 and BRD-063 recorded. Driving the wire to 0, and adding `setundef -undriven -zero` so the remaining 417 undriven nets receive the zero that both Verilator and the Gowin vendor flow already give them, removed the second defect. On the rebuilt bitstream DMA is measured working on the board for the first time: `dmastep` reports its own preconditions and the DMA copy green, `dmawrote` reports changed, pattern and not-zero, matching mGBA check for check, and a new probe `dmavram` confirms a 32-bit DMA into VRAM delivers both halves of every word. Two further probes closed paths nothing had covered: `iexec` copies a position-independent routine into IWRAM and again into EWRAM and branches into it, which is what a retail `crt0` does and had never been tested, and `swilz` calls SWI 0x11 on a hand-built LZ77 stream, which is how every title decompresses its fonts. Both pass on the board. The cartridges moved: the diag cart's purple striped background is gone and is now correctly black with the text row still garbled, Dr. Mario went from white forced-blank to black, and Super Mario Advance still boot-loops. A second agent produced the static-function analysis which this entry verified independently rather than accepting; the undriven wire was found here. Three defects in my own instruments were caught by mGBA controls before any board result was read: a reader sampling the wrong rows, a fabricated register name, and a DMA count off by one because the count field is a literal unit count and `0x0F` transfers 15 units. Recorded as BRD-064, BRD-065, TCL-049 and TCL-050, with BRD-055 withdrawn and BRD-062 and BRD-063 marked superseded. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 65 were not rewritten, all 115 records carry unique ids and the canonical field order, and this is entry 66 against the 100-entry limit.

#### Next Steps:

The remaining fault is narrow and the diag cart now describes it precisely: its tilemap, text position, text colour and text size are all correct while the glyph pixels are wrong and the logo image is absent entirely, which is a defect in tile pixel data rather than in indexing. With DMA, internal-RAM execution and BIOS LZ77 all now measured good, the next instruments should test what produces tile pixels: a mode 0 tile whose bitmap is copied into VRAM and then displayed, so the datapath from stored tile data through the drawer to the screen is measured end to end rather than only its write half; and the palette path, since a wrong palette index mapping would corrupt every tile's colours while leaving positions correct. Super Mario Advance's boot loop should be re-examined after those, because it no longer shares a cause with the other two cartridges and may be a separate fault. The timing regression also needs settling before the next image is trusted: this build passed the gate only because of the documented GBATang multicycle path, with `clk67` at 36.28 MHz against a 67 MHz constraint and a worst path from `cpu_mem_rdata_DFFRE_Q_15` to `sdram.f_mode_DFFRE_Q`, where the previously deployed image reached 202.59 MHz. The netlist grew by only 92 cells so this is unlikely to be logic depth, but two seeds are placing to decide whether it is seed sensitivity or a real cost of the change.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/gba2hdmi.sv
- fpga/gba/src/sound/gba_sound.v
- fpga/gba/src/ddr3_framebuffer.v
- fpga/gba/src/iosys/uart_fixed.v
- tools/build_tinygba.sh
- tools/roms/dmaside.s
- tools/roms/dmastep.s
- tools/roms/dmawrote.s
- tools/roms/dmavram.s
- tools/roms/iexec.s
- tools/roms/swilz.s
- tools/roms/minidma.s
- .ai/core-reference.md

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 67 COMMIT Unreleased 2026-11-14T15:40:00-07:00

#### Coming From:

Unreleased 04b086e

#### Purpose:

Adopt the substantive findings of a second agent's analysis of the boot failure, test them, and land the change that lets a retail cartridge run.

#### Outcome:

A retail cartridge runs on the board. The analysis proposed returning two lines of `gba_memory.sv` to their upstream form, on the theory that a port change from entry 14 let `REQ2_START` leave on the acknowledgements left over from the previous request. The two-line revert was applied and proved in the harness before any bitstream was built, against the real `sdram_gba.v` controller, with the RetroRegen diagnostic cartridge as the subject: before, a black field with one garbled orange text row at rows 130 to 137; after, the complete title screen, logo and all. That result was then confirmed on hardware. `build/rev_prod` was built from the reverted tree with seed 14, the official BIOS and `-nowidelut`, synthesised with 0 conflicting drivers and timed at clk16 21.590, clk50 83.500, clk67 181.061 and hclk 100.140 MHz with zero hold violations and no relaxation needed, and flashed to the board. The diagnostic cartridge draws its full title screen with 491,509 lit pixels. Dr. Mario draws its title screen with the capsule logo, the checkered background, the one-player panel, the Mario and virus sprites and the copyright line, 1,293,791 lit pixels. Super Mario Advance draws and animates its intro, 79 unique frames out of 80 across 80 seconds. The operator reported no graphical glitch in any of the three. The fix is confirmed; the mechanism proposed for it is not, and the difference is recorded rather than smoothed over. A Thumb discriminator was written to test the proposed mechanism, since no probe in this tree had ever executed a Thumb instruction and every failing cartridge is Thumb, and it passes on the board image that still contained the defect, including the arm predicted to fail. That contradiction is set out in `DISSENT-req2-start-mechanism-2026-11-14.md` with three questions whose answers would settle it, together with two failure modes in the discriminator itself: the exposure may need the prefetch buffer empty rather than merely Thumb data access, and the probe's expected value appears in its own literal pool so a stale read could pass by returning the right answer for the wrong reason. The analysis also corrected three things of mine and each was verified before being accepted: that the clk67 figure of about 152 MHz on the deployed image was an artefact of the mis-synthesised netlist rather than a property to recover, which is confirmed by a 1.87 ns `clk67` to `clk16` cross path in `build/deploy_prod` against 28.65 ns in this build; that VRAM does allow 32-bit CPU access so the premise that excluded it from the probe suite was false, confirmed in the RTL at `bram_wdata16 = bram_wdata`; and that `swilz` tests LZ77 literals only and never the back-reference path. Two probe sources were corrected accordingly and one Thumb probe added. Audio was heard from this board for the first time: the operator reports correct stereo separation on HDMI and a scratchy timbre, recorded as a lead with the tests that would settle it and explicitly not as a finding. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 66 were not rewritten, all 117 records carry unique ids and the canonical field order, and this is entry 67 against the 100-entry limit.

#### Next Steps:

Write the audio instrument, because audio is now the largest subsystem that has been observed but never measured and the operator's description is specific enough to discriminate between causes. A probe cartridge that plays a known waveform through channel 1 with sweep disabled, then channel 3, then channel 4, each for a second, would tell whether the scratchiness is per-channel or common to the mixer, and a sweep on channel 1 would separately exercise the four undriven sweep wires that `setundef -undriven -zero` has tied off. Then verify the save path, which no cartridge here has used: an EEPROM, SRAM and flash test each, because `gba_eeprom.sv`, `gba_flash_sram.sv` and the `config_backup_type` selection have never been exercised by a game. Then re-run `tools/roms/thumbprobe.s` against this image and against an image built from a tree with entry 14 restored, because that pair is the cleanest available test of the mechanism the analysis proposes: if the probe passes on both it is insensitive, and if it fails on the old tree and passes on the new one the mechanism is proven and the dissent can be withdrawn. Also correct BRD-049, which states `cpu_ready` is one clk67 cycle wide where the RTL and a 16-bit access make it one to two clk16 cycles, and update `README.md`, which is still ten entries behind and says no cartridge has run.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv
- tools/roms/thumbprobe.s
- tools/roms/dmavram.s
- tools/roms/swilz.s
- DISSENT-req2-start-mechanism-2026-11-14.md
- .ai/core-reference.md

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 68 COMMIT Unreleased 2026-11-14T17:10:00-07:00

#### Coming From:

Unreleased 2bd9ddf

#### Purpose:

Drive the diagnostic cartridge's menu from the host, so input on the board becomes measurable rather than something a person has to supply by hand.

#### Outcome:

Input works on the board and the diagnostic cartridge navigates under scripted control. Nothing in this project could press a button before: every board result came from a cartridge that draws its answer and stops, so anything gated behind a keypress was unmeasurable here. The core's command table already carried the input command, so the work was a host tool and an instrument rather than an RTL change. `tools/gba_input.py` sends command `0x09` with a 16-bit joystick word, which the core stores into `hid1` and `gbatang_top.sv` ORs into the keypad; `tools/roms/keylive.s` polls `KEYINPUT` in a loop and paints one 16x16 square per button, green when held, which is what `keyprobe.s` could not do because it samples the register once at boot. Each button was verified in isolation with everything else released: START lights square 3 only, RIGHT square 7, UP square 4 and A square 0, and release returns all ten to red with `KEYINPUT` back at `0x3FF`. The diagnostic cartridge was then walked through its menu: START opens it, three DOWN presses moved the marker 8 native rows each time from 33 to 41 to 49 to 57, two UP presses reversed it exactly, and the hover description changed from `GUIDED FULL CHECKOUT WITH A PASS/FAIL SUMMARY` to `CPU + BIOS ID, BUS TIMING, SAVE CHIP DETECTION`, so the cartridge is reading the keypad every frame. A entered SYSTEM STATUS and B returned with the selection preserved. The page it drew is the cartridge's own report about this machine: `ARM7TDMI @ 16.78 MHZ`, `ARMu4T (ARM+THUMB)`, `BIOS SUM: 0xBAAE187F`, `GBA/SP/MICRO`, bus timing `IWRAM 1496` `EWRAM 2264` `ROM 2264` cyc/256 reads all `OK`, `WAITCNT: 0x0000`, and `CART SAVE (SRAM PROBE): NOT DETECTED`. That checksum is the same value the same cartridge reported under the Verilator model, which independently confirms the BIOS image on hardware. One tool defect cost two rounds of hardware measurement and is recorded as TCL-051: the input tool hard-coded a frame magic of `0xA5` where the working loader uses `0xAA`, so every frame was silently discarded as an unknown command and the symptom was indistinguishable from a dead input path. The lesson is to take framing from a working client rather than from a protocol comment that documents only the payload. Recorded as BRD-068 and TCL-051. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 67 were not rewritten, all 119 records carry unique ids and the canonical field order, and this is entry 68 against the 100-entry limit.

#### Next Steps:

Use the input path to let the cartridge verify the machine instead of building probes for what it already tests. The obvious next step is to walk to MEMORY TEST and run it, then the remaining entries in order, because that page reports IWRAM, EWRAM, VRAM, PRAM and OAM in one screen from a third-party suite rather than from a probe written here -- the same suite whose Verilator result is already recorded, so the board result becomes a direct comparison. Then read what `CART SAVE (SRAM PROBE): NOT DETECTED` means before treating it as a finding: the cartridge's probe search and the core's `config_backup_type` selection both need reading, and the likely candidates are that the core reports no backup type for this image or that the SRAM window is not where the probe looks. Audio remains the largest unmeasured subsystem (BRD-067) and the AUDIO TEST menu entry is now reachable, which makes an operator-verifiable audio check cheap. Leave the save path and audio alone until the memory test has been run, since it is one keypress away and answers a question the probes were about to be written for.

#### Files Modified:

- tools/gba_input.py
- tools/roms/keylive.s
- .ai/core-reference.md

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: PASS

---

## 69 COMMIT Unreleased 2026-11-14T18:05:00-07:00

#### Coming From:

Unreleased fb4b214

#### Purpose:

Run the diagnostic cartridge's full memory test on the board, which the new input path makes reachable, and read its result against the model's.

#### Outcome:

`RESULT: ALL REGIONS PASS` on real hardware, from a third-party suite rather than a probe written here. Driven from the host -- START to open the menu, one DOWN to MEMORY TEST, A to run -- the cartridge tested every internal memory region at full size and drew: IWRAM 32K cells PASS with decoder `LIVE*`, EWRAM 256K PASS/PASS, VRAM 96K PASS/PASS, PRAM 1K PASS/PASS, OAM 1K PASS/PASS, in 1377 ms. The page explains its own annotations: `*IWRAM HOLDS THE LIVE STACK: DECODER SKIPPED`, which is why IWRAM is the only `LIVE*` in the decoder column, and `TABLE = CONSOLE-INTERNAL RAM. CART SRAM IS ON THE CARTRIDGE.` The same suite's board bus timing reads `IWRAM 1496`, `EWRAM 2264`, `ROM 2264` cycles per 256 reads against the model's `1190`, `1702` and `1702`, all `OK`; the board is slower in every region as expected, since the model substitutes a behavioural SDRAM array for the real controller. The five regions now have a board result to set beside the model result, and the memory side of the machine is closed at full size rather than at sampled addresses. The one open line on both pages, `CART SAVE: NOT DETECTED`, was resolved the same session by reading the RTL rather than measuring: `tools/load_gba_rom.py` sends only commands `0x06`, `0x07` and `0x08`, and `config_backup_type` is assigned from the loader stream only while `loading == 3` and `loader_addr[2:0] == 0`, a fourth loading stage this loader never enters, so the value stays `BACKUP_NONE`. `isreadonly` then treats regions `4'hE` and `4'hF` as read-only, every save write is discarded, and the cartridge's read-back finds nothing. The cartridge is reporting the truth about what the core presents; the defect is that the loader configures no save hardware. Recorded as BRD-069 and BRD-070, the latter resolved rather than left open. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 68 were not rewritten, all 121 records carry unique ids and the canonical field order, and this is entry 69 against the 100-entry limit.

#### Next Steps:

Decide whether the loader should configure a backup type, because that is now a known and specific gap rather than an unknown: `load_gba_rom.py` could enter loading stage 3 with a type derived from the cartridge header, or a `--save` flag could set it, and either would make a battery-backed save exercisable for the first time on this board. That is the only thing standing between the current state and a test of `gba_eeprom.sv`, `gba_flash_sram.sv` and the backup-type selection, none of which has ever run against a cartridge. Separately, run the remaining menu entries now that input works and each is a keypress away: SCREEN TEST, GPU STRESS TEST, BUTTON TEST and AUDIO TEST, in that order, because each is answered by a third-party screen or by the operator's eyes rather than by another probe, and the BUTTON TEST in particular would exercise the input path through the cartridge's own expectations rather than through `keylive`. Audio remains the largest unmeasured subsystem (BRD-067) and AUDIO TEST is the first instrument for it that costs nothing to run.

#### Files Modified:

- .ai/core-reference.md

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: PASS

---

## 70 COMMIT Unreleased 2026-11-14T21:30:00-07:00

#### Coming From:

Unreleased 588d133

#### Purpose:

Fix the two audio defects BRD-072 located and confirmed, verify them on the board, and then test the machine with the largest retail cartridge available.

#### Outcome:

Audio is closed and the machine runs a retail title continuously. Two changes were made, each small and each verified against the real module in a Verilator unit testbench before any bitstream was built. In `gba_sound.v` the Game Boy's 4.194304 MHz timebase was restored as a one-in-four enable from `clk16`, gated onto the `soundcycles_*` increments alone so the thresholds and decrements stayed ungated -- which is deliberate, because that gating also removes a second defect for free: the increment and the decrement are non-blocking assignments to the same register in the same block, so the increment was lost on every fourth cycle and the prescaler divided by five rather than four. In `gba_sound_ch1.v` and `gba_sound_ch4.v` the volume is now zero-extended before being made signed, because `signed'(volume)` on a `reg [3:0]` reinterprets four bits as two's complement and a volume of 15 consequently played at magnitude 1, 32 dB down, with a polarity inversion every time an envelope crossed between 7 and 8. The unit testbench drove the real channel over its register bus and measured, for identical registers, the unfixed module at 11920 cycles per tone (1407.47 Hz) with amplitude 1 and the fixed module at 38144 cycles (439.83 Hz) with amplitude 15, against an expected 38144 cycles and 439.84 Hz. The unfixed simulation agreed with the 1404.4 Hz measured on the board to 0.2 percent, which is what licensed trusting the fixed prediction before building. On hardware the result is: CH1 SQUARE 1404.4 Hz at 219 RMS became 439.4 Hz at 3331.7 RMS; CH3 WAVE TRIANGLE 1173.9 Hz became 440.1 Hz; and PCM SINE, which neither fix should touch and which therefore serves as the control, stayed at 437-438 Hz and 9025 RMS throughout. One prediction failed: BRD-073 expected CH3 near 783 Hz on a 2/3 residue argument and it measured 440.1 Hz, so the channel 3 arithmetic is not as BRD-072 modelled it and that is recorded rather than explained away. Then the suite was exercised entry by entry with the capture card recording alongside: all four PSG channels play at correct pitch and level, CH3's spectrum is a textbook triangle with the second harmonic 114.9 dB down and odd harmonics at 1/n^2, and the PCM sweep 100-8000 Hz measures 40 to 7960 Hz rising in a clean staircase. The operator listened to every entry and marked audio a pass. Finally Castlevania Aria of Sorrow, at 8 MiB the largest cartridge this board has run and double the previous largest, booted to its title screen, played its intro, and produced 75 unique frames out of 75 across 75 seconds while crossing from the intro into gameplay; the operator reported it looks and sounds perfect with a correct frame rate. Recorded as BRD-073 through BRD-076 and TCL-053. The core-syntax audit confirmed `.ai/core.md` was not modified, entries 1 to 69 were not rewritten, all 129 records carry unique ids and the canonical field order, and this is entry 70 against the 100-entry limit.

#### Next Steps:

Update `README.md`, which is now well behind the tree: it still says no cartridge has run, that `pixel_out_we` never asserts and that the `REQ2_START` deadlock stands, and all three are closed. Then take a second load of the same Aria of Sorrow image, because BRD-014 and BRD-045 recorded the machine as bimodal across loads of one bitstream and a single good run must not be generalised; that is the cheapest test of whether the earlier bimodality is gone or merely not sampled. After that, the subsystems that remain wholly unexercised are the save path, which the loader still does not configure a backup type for (BRD-070), the link port, and the RTC and solar sensor, none of which any cartridge here uses. The `clk67` timing margin also deserves a seed sweep when convenient: this image needed the documented multicycle relaxation where `build/rev_prod` needed none, and since the netlist is cached a sweep costs minutes not hours.

#### Files Modified:

- fpga/gba/src/sound/gba_sound.v
- fpga/gba/src/sound/gba_sound_ch1.v
- fpga/gba/src/sound/gba_sound_ch3.v
- fpga/gba/src/sound/gba_sound_ch4.v
- .ai/core-reference.md

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 71 COMMIT Unreleased 2026-11-14T23:10:00-07:00

#### Coming From:

Unreleased ad773df

#### Purpose:

Bring the project's user-facing documentation into line with what the hardware has actually been shown to do, and correct two records that later evidence contradicted.

#### Outcome:

`README.md` was rewritten rather than patched, because its opening sentence still said no cartridge had run and its "Known gaps" list opened with the same claim; every section now states what was measured and cites the record. The new text leads with the result that a retail cartridge runs, naming Castlevania Aria of Sorrow at 8 MiB with 75 distinct frames in 75 seconds and six consecutive clean loads, then separates the two defects that blocked the machine -- the static-function mis-synthesis of BRD-064 and the undriven `dma_bus_unread` of BRD-065 -- from the earlier video, SDRAM and clock findings that remain true. The build section now documents the actual gates in the order they run, including the synthesis-conflict gate added this session and the reason each exists; the deploy section names the real image, `build/snd_prod`, since the earlier `build/deploy_prod` reference pointed at a November 13 image taken before the DMA fix and would have misled anyone following it. New sections cover host-side input injection, the capture card's ALSA input, and the `.ai/` record library with an explicit note that many records carry SUPERSEDED or WITHDRAWN titles deliberately. Two claims were deliberately weakened rather than stated as fact: the "first open-flow GBA core" line is attributed to the operator as an assessment about the wider field rather than something measured here, and the capture geometry is described as measured on this board rather than derived from a script that does not in fact contain it. `THIRD_PARTY.md` said the vendored tree was "verbatim except for the files listed below", which had not been true for some time; it now points at the `TinyGBA:` marker as the authoritative list, names the seventeen files carrying one, and groups them by kind. Two corrections were made in `.ai/core-reference.md`. BRD-049 claimed `cpu_ready` is high for a single `clk67` cycle, which the RTL contradicts: every assignment sits inside the `cycle[3]` slot of a one-hot counter over four values, so the strobe is a full `clk16` period wide, and the synchroniser added later was justified on exactly that width, so designing against the recorded figure would have made a safe synchroniser look unsafe. A paraphrase of the Thumb stale-acknowledgement claim was also removed from the same record rather than asserted, since the probe written to test that mechanism did not reproduce it. The core-syntax audit was run as required for a change under `.ai/`: `core-log.md` holds 70 entries numbered 1 to 70 with no gaps, all of type `COMMIT` and version `Unreleased`, every entry carrying exactly the six canonical sections in order and ending with `---`, no `???` placeholder, and the log is under the 100-entry limit; `core-reference.md` holds 130 records with 130 unique ids, no duplicates, every record in the canonical field order, all ids matching `BRD-` or `TCL-` and three digits, and a status vocabulary of 122 `VERIFIED`, 6 `LEAD` and 2 `MEASURED`. The audit also found that six historical entries, numbers 5 and 14 to 18, carry prose in their Status values where the current syntax allows only `PASS`, `FAIL`, `NOT RUN` or `N/A`; those are committed history and the syntax document forbids rewriting a recorded outcome, so they are left as they stand and noted here rather than corrected. Every command the README documents was executed and checked to work, including `make_probe_rom.py --list`, `load_gba_rom.py --dry-run` and `gba_input.py`, because a README with broken commands is worse than a stale one. No RTL was changed, so no build or hardware stage applied.

#### Next Steps:

The README and THIRD_PARTY now match the tree, so the documentation debt is cleared and the next cycle can return to hardware. Two items remain from the previous entry and are unaffected by this one: a seed sweep to recover `clk67` timing margin, since `build/snd_prod` needed the documented multicycle relaxation where `build/rev_prod` needed none and the netlist is cached so a sweep costs minutes rather than hours; and configuring a backup type in the loader so that the save path, which no cartridge has ever exercised here, becomes testable. Neither is urgent against a machine that runs retail software, and both are recorded rather than implied. If a release is wanted, this is the natural boundary for one: the versioning rule calls for a MINOR bump at a hardware-proven milestone and the first release is 0.1.0, but tagging is an external publication and awaits the operator's explicit decision.

#### Files Modified:

- README.md
- THIRD_PARTY.md

#### Status:

- Build: N/A
- Deployment: N/A
- User Test: N/A

---

## 72 COMMIT Unreleased 2026-11-14T23:55:00-07:00

#### Coming From:

Unreleased 4983e0c

#### Purpose:

Establish the controller path before porting any of it, and leave the tree in a state a fresh agent can pick up without re-deriving what this session learned the hard way.

#### Outcome:

Two-wire deployment is now established for this project, and a controller cannot work any other way. The session began by flashing TinyNES's release `.fs` with `openFPGALoader` and finding the Classic Controller absent, and three explanations were tried and refuted before the right one: the adapter's power, then an I2C mux channel, then the image itself. The image was innocent -- the `.fs` decompressed from `TinyTang.v0.2.1.zip` is byte-identical to the one in the TinyNES build tree, SHA-256 `2a356060084bad43...`, and its `.bin` twin matches the card's listing at `5cd4ab004f7af3c9...`. The difference is the loading path. Flashed over JTAG the core runs, and Zelda's video and audio are perfect, but `pad_test` reports `PAD STATUS 50000000` on every bus with about eighty failed I2C transactions and zero reads; loaded with `tangload` from the card the same core reports `PAD1 connected classic ID=010320a40000 FAIL=0` on the first poll, and the operator played Zelda through the Old Man cave to confirm it end to end. TinyTang's `tang_ini_core_loaded()` pushes the socket declaration parsed from `/tinytang.ini` into the core as part of the load, so a bare JTAG flash configures no pad fabric at all, and in one-wire mode TinyTang does not run to send it; recorded as TCL-054. With that settled, TinyGBA was built as a first-class core on the card: `tinygba.bin` 5,000,172 bytes and `tinygba.fs.gz` 1,404,785 bytes written to `/root/cores/console138k/` alongside tiny89, tinygbc, tinynes, tinysnes, tinyphosphor and tinytang, `tangload` programming it and the RetroRegen cartridge drawing its title screen at 503,407 lit pixels, identical to the one-wire run; recorded as BRD-078. Controller input does not reach TinyGBA and correctly so, because it has no Wii-extension I2C logic: `wii_pads.sv` exists only in TinyNES, `USB1` and `USB2` are commented out in `console138k.v` leaving `joy_usb1` and `joy_usb2` tied to zero, and `keylive` reads `KEYINPUT 0x3FF` both idle and while a qualified controller's button was held. One standards gap was closed on the way: the card pair had been produced by copying a `.bin` and running `gzip -9` by hand, which stamps the wall clock into the header so the same bitstream hashes differently every run; `tools/ship_core.py` now produces both halves deterministically with `mtime=0`, refuses a missing or empty `.bin`, and prints both hashes, verified byte-identical across two consecutive runs; recorded as TCL-055. The core-syntax audit was run as required for changes under `.ai/`: `core-log.md` holds 72 entries numbered 1 to 72 with no gaps, counting this one, all `COMMIT` and `Unreleased`, every entry carrying the six canonical sections in order and ending with `---`, and the log is under the 100-entry limit; `core-reference.md` holds 133 records with 133 unique ids, no duplicates, every record in the canonical field order and every id `BRD-` or `TCL-` with three digits, across a status vocabulary of 125 `VERIFIED`, 6 `LEAD` and 2 `MEASURED`. Six historical entries, numbers 5 and 14 to 18, still carry prose in their Status values where the current syntax allows only `PASS`, `FAIL`, `NOT RUN` or `N/A`; they are committed history, the syntax document forbids rewriting a recorded outcome, and they remain noted rather than corrected.

#### Next Steps:

Port the controller, which is now a scoped job rather than an unknown. It needs three things, and the third is the one that would otherwise waste another session: `wii_pads.sv` from TinyNES adapted in, four I2C masters with the Classic Controller wake-up and format-3 selection, kept as a vendored adaptation with an entry in THIRD_PARTY.md rather than a copy; pin constraints for whichever socket the pad is seated in, and the first thing to check is whether `fpga/gba/src/boards/console138k.cst` carries the `pmod0` pins TinyNES uses at `V18` and `V19` onward, since TinyGBA's board file was written for `usb1_dp/dn` and `usb2_dp/dn` and may not; and the socket-declaration path, because TCL-054 shows a core loaded by a bare JTAG flash has no pad fabric and TinyGBA must therefore be loaded through TinyTang and accept the declaration the way TinyNES does. The pad state then joins the existing OR term at `assign joy_btns_gba = overlay ? 0 : joy_btns | joy_usb1 | joy_usb2 | hid1 | hid2;`, which is where `hid1` and `hid2` already arrive. Before any of that, take the operator's advice and test TinyGBA in two-wire mode with the host-side `tools/gba_input.py` path, which should work already and would prove the rest of the chain independently of the I2C port. Two smaller items stand from earlier entries and are unaffected: a seed sweep to recover `clk67` margin, since this image needs the documented multicycle relaxation where `build/rev_prod` did not, and configuring a backup type in the loader so the save path becomes testable for the first time. Nothing here is urgent against a machine that runs retail software, and none of it should be started without the operator's go-ahead.

#### Files Modified:

- tools/ship_core.py

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: PASS

---

## 73 COMMIT Unreleased 2026-11-14T17:32:48-07:00

#### Coming From:

Unreleased 51204f2

#### Purpose:

Close the build-hygiene debt the project has been carrying since entries 51 and 52 -- make `-nowidelut` the default, wire the two finished-but-unwired gates into the build, and settle the `clk67` timing margin with a seed sweep.

#### Outcome:

Three build-hygiene changes are landed and proven by a full build, and the seed sweep that was meant to recover `clk67` margin instead refuted the record that predicted it would. `tools/build_tinygba.sh` now passes `-nowidelut` to `synth_gowin` by default, with `TINYGBA_WIDELUT=1` restoring the old mapping, because TCL-036 measured it as smaller, faster to place and better timed at an identical flip-flop count, and every image deployed since `build/nwl_s11` was already built that way -- the default now describes what has actually been measured rather than what someone remembered to type. `tools/memory_census.py` and `tools/bsram_addr_check.py` are wired in as gates 1d and 1e beside the register-parity and clock-edge gates, keyed on the same `$cfg` as the parity gate so a diagnostic configuration does not have to match production, and both cost under a second on a 57 MB netlist. Baselines for both were recorded from `build/snd_prod` -- the image that runs Castlevania and survived six loads -- rather than from a fresh unproven build, per the rule entry 11 set; the parity baseline is 11,471 flip-flops and 156 block RAM, reproducing BRD-074's recorded counts exactly. `build/hyg_s1` then ran the whole flow to a packed bitstream (`.fs` SHA-256 `d211e99747ec9ae5...`) with all nine gates passing, including zero conflicting drivers, 0 wide-mux cells, `census matches the baseline for 'TINYGBA_OVERLAY_OFF'`, and `no NEW ADB cone deeper than 8 levels`. The census earned its place on its first run by flagging `sdram.din_latch`, an array the pre-existing baseline lacked; checking `rev_prod`, `fix_s7` and `fix_s21` showed it is LUT RAM in every recent netlist including the retail-proven one, so it is a baseline gap rather than a regression. The timing half of the cycle went the other way. BRD-074 had recorded the `clk67` drop from `rev_prod`'s 181 MHz to `snd_prod`'s 53.6 MHz as placement variance that a seed sweep would recover; ten placements of the current netlist instead give 48.6 to 57.2 MHz with a mean of 53.75 and not one clean seed, while the `rev_prod` netlist placed at two of the same seeds gives 184.1 and 190.0 MHz with no relaxation. The cause was isolated rather than inferred: the current tree was synthesised with only the four sound files returned to their `f38cebe` state, which reproduced `rev_prod`'s netlist exactly at 49,562 cells and 8,534 `DFFRE`, and that netlist placed at seed 10 gave 184.060 MHz -- the control figure to the digit -- where the same tree carrying the audio fix gives 54.301. So a change worth two flip-flops costs a factor of 3.4 on `clk67` by moving ABC's optimisation boundary and rerouting the cone into `sdram.f_mode`, and no seed recovers it; recorded as TCL-056, with BRD-074's attribution named as superseded rather than rewritten. The build is not broken -- the relaxation it now needs is the one upstream `gbatang.sdc` exists to express -- but any image carrying the audio fix must state that it needs it. Two operational notes: twenty concurrent placements exhausted available memory and stalled the sweep, so six were killed by exact pid, and the one leftover was cleaned up before the control could finish; the causal build ran with a trap that restores `fpga/gba/src/sound/` on every exit path, and the tree was confirmed byte-identical to `HEAD` in those four files afterwards. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed, confirmed entries 1 to 72 were not rewritten and that BRD-074's text is preserved with its refutation recorded in TCL-056 instead, and validated this entry as entry 73 with the six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, and a count of seventy-three against the 100-entry limit. The audit also found that 36 historical records from BRD-057 onward carry eight fields and no `verification:` line; they are settled history, the syntax document forbids reformatting them, and they are noted here rather than corrected, while TCL-056 carries all nine canonical fields in order.

#### Next Steps:

Shorten the `sdram.f_mode` cone rather than sweeping for a seed, because the margin is a property of the netlist and TCL-056 has closed the sweep question as a negative: the shape is to register the address that feeds `mem_bios` -- or the flash-mode decode itself -- one level before the port, which is the remedy TCL-035 already names for that array, and the change must be judged on both properties together per TCL-027, the relaxation gone and reach undiminished, at two seeds per TCL-034. That is an RTL change to the address datapath and needs its own approval before it is built. Until then, treat the documented relaxation as a permanent property of this tree and quote it whenever a timing figure from a post-audio image is stated, rather than reporting `clk67` achieved against 67 MHz without the note. Two smaller items stand: the four diagnostic configurations with no census or parity baseline will report and skip rather than gate, which is correct but worth recording baselines for when each is next proven, and `build/ship/tinygba.fs.gz` on disk is still the hand-gzipped 1,404,785-byte file rather than the deterministic output of `tools/ship_core.py` that TCL-055 requires, so re-running that tool would put the shipped hash on a reproducible footing. Do not re-run a seed sweep expecting to recover `clk67`; do not re-apply the control-path deferral of entry 46 or the pipelined pair of entry 47.

#### Files Modified:

- tools/build_tinygba.sh
- tools/memory_baseline.json
- tools/synth_baseline.json
- README.md

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---

## 74 COMMIT Unreleased 2026-11-14T18:19:10-07:00

#### Coming From:

Unreleased 260f95c

#### Purpose:

Give the board its own controller, which was the last missing input capability and the one project item that was missing capability rather than polish.

#### Outcome:

A Wii Classic Controller on USB-A port 2 now drives the GBA keypad with no host in the loop, and the operator confirmed the mapping by playing. The work was mostly vendoring rather than design: `fpga/gba/src/peripherals/wii_pad_master.sv` is TinyNES's `wii_pad_master` extracted verbatim from `fpga/ae350_soc/wii_pads.sv` at `7013393` with only a provenance header added, so the body still diffs clean against upstream and an upstream defect stays distinguishable from a local edit. Only that module was taken, not the `wii_pads` AHB slave that wraps it for TinyNES's AE350 SoC, because TinyGBA has no AHB bus and porting one to reach a single controller's buttons would have been the larger change; the wiring therefore lives in `gbatang_top.sv` and the GBA memory map is untouched. The bus is USB-A port 2's data pair with D+ (`usb1_dp`, H13) as SDA and D- (`usb1_dn`, G13) as SCL through two open-drain `IOBUF`s, which are pins this tree already declared and left free because `USB1` is undefined, so the pad is gated on the same define and cannot contend with a USB host. The master runs on `clk50` at a 126-quarter bit time, 99.7 kHz, and its report crosses into `clk16` through two flops per BRD-050. The mapping aliases the Classic Controller's second face-button pair and its shoulders onto the GBA's single pair, X playing A and Y playing B to preserve the physical arrangement, ZL and ZR playing L and R, HOME unmapped, and the analogue sticks and triggers read and discarded because the GBA has no analogue input. `build/pad_s14` passed every gate -- zero conflicting drivers, parity +194 flops at 1.7 percent, census unchanged, no new deep `ADB` cone, clock edges OK, hold 0, `clk67` on `SPINE25/TOP1` and `hclk` across `SPINE26/BOTTOM2`, both measured good per BRD-048 -- and both `IOBUF`s were confirmed at `X181Y97` with `hdlname usb1_dp`/`usb1_dn` in the routed netlist before the load rather than assumed. It was written to the card and loaded with `tangload` in two-wire mode, the only path on which a controller can work at all per TCL-054. Two verification decisions are worth recording. A committed regression test, `tools/pad/run_pad_tb.sh`, drives the vendored master against `tools/pad/wii_classic_model.sv` -- also vendored byte-identical, from TinyNES's testbench -- through the real open-drain wiring, synchroniser and mapping, for both a genuine Classic Controller and an 8BitDo receiver; both pass with `present=1 classic=1 reads=1 fails=0` and data words matching TinyNES's recorded hardware values, and it was mutation-tested by deleting the ZR alias, which makes it fail. And the button bit positions came from TinyNES `firmware/apps/pad_test/main.c`, the table validated on this board, not from the comment in TinyNES's own testbench, which labels the same pad bit 'Up held' that the table calls ZR; hardware agrees with the table. Three of my own errors were caught by the test rather than by the board: two hand-written hex vectors that were simply wrong -- the RTL was right both times -- after which the vectors were generated by OR-ing named bits so they cannot be wrong, and a testbench that sampled at the edge that raised `reads`, racing the continuous assign and the synchroniser, which produced a spurious 'more than one button mapped'. The capture card was receiving no signal throughout this cycle (a uniform single-colour frame with none of the `(43,43,43)` pillarbox that every known-good capture carries), so the screen could not be read remotely; the operator confirmed OBS was working and reported the result directly. That result is that A and X both light the leftmost square, B and Y both light the second, and every other button lights its own square -- the intended mapping -- recorded as BRD-079, with TCL-057 recording the vendoring and test discipline. Seed 10 failed on BRD-024's `hclk5` route abort, a known seed property. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 73 were not rewritten, confirmed BRD-079 and TCL-057 carry unique ids and the canonical field order, and validated this entry as entry 74 with the six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, and a count of seventy-four against the 100-entry limit.

#### Next Steps:

Take the two remaining capability gaps in whichever order suits the operator. The save path is the larger one and is now well scoped: `tools/load_gba_rom.py` sends only commands `0x06`, `0x07` and `0x08`, so `config_backup_type` stays `BACKUP_NONE` and no cartridge has ever had a working save here (BRD-070), and the fix is a loader stage or a `--save` flag derived from the cartridge header, after which `gba_eeprom.sv` and `gba_flash_sram.sv` become testable for the first time. The other is the `sdram.f_mode` cone from TCL-056, which is hygiene rather than capability and should stay parked unless logic is added to the SDRAM controller or the `mem_bios` address path. Now that the pad works, the diagnostic cartridge's BUTTON TEST entry is reachable from the controller rather than only from `tools/gba_input.py`, which would be a second independent confirmation of the input path through a third-party suite. A release is also overdue in the sense that the versioning rule calls for a MINOR bump at a hardware-proven milestone and the machine now runs retail titles, plays audio and takes input, but tagging is external publication and awaits the operator's explicit decision. Do not re-test the pad mapping, the I2C wake-up or the receiver path; all are measured in simulation and on the board. Do not cite TinyNES's testbench comment for button positions.

#### Files Modified:

- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/boards/console138k.cst
- fpga/gba/src/peripherals/wii_pad_master.sv
- tools/build_tinygba.sh
- tools/pad/tb_pad.sv
- tools/pad/wii_classic_model.sv
- tools/pad/run_pad_tb.sh
- THIRD_PARTY.md
- README.md

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 75 COMMIT Unreleased 2026-11-14T20:25:30-07:00

#### Coming From:

Unreleased 760e46b

#### Purpose:

Give TinyGBA the card-based cartridge loader every other core on the Tang already had, and use it to sweep twelve retail cartridges and find out what the machine actually runs.

#### Outcome:

TinyGBA now loads cartridges the way every other core on the card does -- core on the SD, cartridge on the SD, board loads both itself, no PC transfer -- and a twelve-title sweep found eleven of them running correctly. The loader is a new `gbaload` command in TinyTang's firmware, which is a different repository and a separate change from this one: TinyGBA had no card loader because only NES and SNES had one, so the work was to add an eighth entry to `tang_fpga_uart.c`'s command table modelled on `cmd_nesload`, since both cores are nand2mario's and `iosys_bl616.v`'s frame table is the same in each. It sends `0x06` to hold the core in reset, `0x07` for cartridge bytes in 1024-byte chunks with a `taskYIELD` between them so the BL616's USB and console tasks keep running, then clears the OSD through the OSD module and sends `0x06` again to start the cartridge. It refuses a file with no `0x96` at `0xB2` or one larger than 32 MiB. The chunk size and the yield are load-bearing rather than stylistic: a frame whose length high byte reaches 8 makes the core's receiver fall back to hunting for a magic byte, and the earlier host-side `fpgapipe` path aborted whenever UART1's FIFO stayed full for 100 ms, which a sustained 192 KB/s stream against a 200 KB/s core does on any hiccup -- that is why every attempt to stream an 8 MB image that way died at about 5.7 MB and took the BL616 down with it each time. The firmware was built from a tree whose `ports/bl616/` is byte-identical to what the board was already running, verified with `git diff` against the board's own reported commit before anything was flashed, and installed with `tinytang_flash.py`, which stages at `0x120000` and commits from TCM; the board reports `63ca128-dirty.aa33546` afterwards and `gbaload` is in its command table. The sweep then ran eleven cartridges from `/root/media/gba/` with mGBA 0.10.5 on the same ROM and the same retail BIOS alongside. Metroid Fusion, The Minish Cap, Golden Sun, Metroid Zero Mission, Advance Wars, Fire Emblem, Final Fantasy Tactics Advance, Castlevania: Aria of Sorrow, Mario Kart: Super Circuit, Doom II and Asterix & Obelix XXL all pass on audio and video, and Pokemon Emerald alone fails, stopping on the uniform white field the BIOS leaves at handover on two separate loads; recorded as BRD-080 through BRD-087. Doom II and Asterix & Obelix XXL were added deliberately as stress cases beyond the curated ten, and they carry the strongest performance evidence the project has: the operator played matched sections on both systems and reported that Doom II's frame-rate drops occur at the same places by the same magnitude, which is what the 0.1622 percent clock deficit of TCL-058 predicts and means the core is reproducing the hardware's performance profile rather than merely being fast enough. The sweep also produced three defect fingerprints and one unexplained failure, all recorded and none diagnosed: one native scanline of Advance Wars shimmers with garbage that is not a shifted copy and changes at about a fifth of its pixels per frame (BRD-081); Fire Emblem's intro flames flicker (BRD-082); Castlevania has a semi-regular large pop during the intro (BRD-085); and Emerald's stop is the only outright failure. Because Doom II and XXL exercise the affine, sprite and software-3D paths harder than any of those three and are clean, a general throughput or timing limit is unlikely to be the cause and a specific interaction inside each cartridge's use of a mode is more likely -- stated as reasoning, not as a finding. The speed question was settled with arithmetic rather than impression: `pll_16.v` gives FVCO 1809 MHz and `clk16` 1809/108 = 16.750000 MHz against a GBA's 16.777216, so the core runs at 59.6306 Hz against 59.7275, or 99.8378 percent, and a 30-second capture counted 14 near-identical frame pairs which matches the prediction and not 60 fps; recorded as TCL-058, which also notes that exact-hash frame counting fails on an MJPEG capture because quantisation noise makes duplicate frames hash differently. Two tooling faults of mine cost time and are fixed: the console helper waited out its full timeout after a completed `gbaload` because it looked for `core loaded` rather than `the core is running`, which held the USB port and produced `device reports readiness to read but returned no data` for the next command, and that was mistaken first for a board fault; and `lsusb` disagrees with a working controller about which mode the board is in, so `tools/board_mode.py` now asks the board's console instead of inferring it. `README.md` gained the card-based deploy workflow, was corrected where it still described the sweep as three titles, and now states the 99.8378 percent figure with the reason; the old one-wire path is kept as bench-only with the `fpgapipe` limit written down. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 74 were not rewritten, confirmed the eight new records carry unique ids and the canonical field order, and validated this entry as entry 75 with the six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, and a count of seventy-five against the 100-entry limit.

#### Next Steps:

Chase Pokemon Emerald, because it is now the only cartridge of twelve that fails and it is the only question the sweep left open: the loader still configures no backup type, so `config_backup_type` stays `BACKUP_NONE`, `isreadonly` discards every write to the save window at regions `0xE` and `0xF` while `tosdram` still maps them so the cartridge sees a readable area that never changes, and the core has no cartridge RTC or GPIO implementation at all -- Emerald is flash-save and reads an RTC at boot, while Mario Kart is EEPROM-save and runs a full race and Castlevania is SRAM-save and reaches its save menu, so the RTC is the leading difference and the save window alone is excluded. The test is to add the loader's backup-type stage so `gbaload` can set it from the cartridge header, then retry Emerald; do that before writing any probe, since it may be the whole fault. The three recorded artefacts -- the Advance Wars scanline, the Fire Emblem flames and the Castlevania pop -- should be left alone until Emerald is settled, and each needs an instrument rather than another observation when it is taken up: the pop in particular should be captured through the capture card's audio input at 48 kHz, the method BRD-071 to BRD-076 used, because a pop is a discontinuity at a period and that measurement alone separates a buffer underrun from a wrong constant. `tools/load_gba_rom.py` now documents a path that is not how this core is used and should be retired or rewritten around the card workflow. A release is overdue by the project's own rule, since the machine runs retail titles, plays audio, takes input and loads from the card, and the versioning section calls for a MINOR bump at a hardware-proven milestone -- but tagging is external publication and still awaits the operator's explicit decision.

#### Files Modified:

- README.md
- tools/board_mode.py

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: PASS

---

## 76 COMMIT Unreleased 2026-11-14T21:01:28-07:00

#### Coming From:

Unreleased 71a61b4

#### Purpose:

Fix Pokemon Emerald, the one cartridge of twelve that failed, by giving the loader the save-hardware configuration it had never performed for any cartridge.

#### Outcome:

Emerald now boots by itself, the sweep is twelve of twelve, and the cause was found by A/B on one image rather than by theory. BRD-080 had recorded Emerald stopping on the white field the BIOS leaves at handover and had named the absent RTC as the leading suspect, on the reasoning that Mario Kart is EEPROM-save and ran while Emerald is flash-save and reads a clock. That reasoning was wrong and the simpler explanation was right. The first test cost nothing: with the 16 MiB image already in SDRAM from `gbaload`, and knowing that changing the core's loading state does not clear SDRAM, a small `fpgapipe` client drove loader stage 3 directly and set `config_backup_type` to `FLASH1M`, without re-streaming the ROM. Emerald booted at once. That isolated the fault to the save type -- the core's `isreadonly` treats the cartridge save window at regions `0xE` and `0xF` as read-only unless the type is flash or SRAM, so with `BACKUP_NONE` every write the game made was discarded and the game blocked when it could not write its save. The operator then reported the cartridge's own message, `The internal battery has run dry. The game can be played. However, clock-based events will no longer occur.`, which states the RTC's true scope: clock-based events, not boot. Recorded as BRD-088, which names BRD-080's hypothesis as refuted rather than quietly dropping it. The fix makes `gbaload` set the type itself so the result survives a reload. While streaming, it looks for the marker string every GBA save library leaves in the image -- `FLASH1M_V`, `FLASH512_V`, `FLASH_V`, `SRAM_F_V`, `SRAM_V`, `EEPROM_V` -- and sends stage 3 with the matching type before releasing the core, so a 16 MiB load costs nothing extra. The scan searches every byte of each 1024-byte chunk and separately searches the ten-byte tail carried from the previous chunk, so a marker split across a read boundary is still found. My first version searched only a 20-byte window at the start of the chunk and reported `no save marker found` for Emerald, whose marker sits at offset 192 of its chunk; that would have looked exactly like the original fault and read as the fix having failed rather than as it not having run, so it is recorded as TCL-059 along with the rule that caught it -- simulate the scan offline against every real input before building and flashing. The prototype detection was simulated against all thirteen cartridges in the collection and found all thirteen, which also showed two things a guess would have got wrong: Castlevania and Fire Emblem use `SRAM_F_V` rather than `SRAM_V`, and `FLASH1M_V` must be matched before `FLASH_V` or Emerald is misread as 512K flash. On the board the loader now prints `gbaload: save hardware = flash1M` and Emerald boots with no manual step, recorded as BRD-089, and regression loads of Mario Kart and Metroid Fusion detected `flash512K` and `SRAM` correctly, so the change does not disturb the other types. During that regression the second of two back-to-back loads was seen to freeze part-way through its BIOS boot and then booted normally; the capture taken at the moment it was reported showed a live animating picture, so no fault is established and it is recorded as BRD-090 with the discipline rather than a diagnosis. What is now visibly absent is persistence: the core writes the save window but nothing reads it back to the card, so a save survives only until the next `gbaload`, and the RTC is still unimplemented, which the cartridge says on screen. The core-syntax audit re-read `.ai/core.md` and `.ai/core-syntax.md`, inspected the complete `.ai/` diff, confirmed `.ai/core.md` was not changed and entries 1 to 75 were not rewritten, confirmed the four new records carry unique ids and the canonical field order, and validated this entry as entry 76 with the six canonical sections, a one-sentence Purpose, prose in Outcome and Next Steps, and a count of seventy-six against the 100-entry limit.

#### Next Steps:

Make saves persist, because that is now the only thing standing between this core and behaving like the hardware for a player rather than only on screen: the core already writes the cartridge save window, so the work is in the loader -- read the window out to a file on the card when a cartridge is unloaded or the board is asked to, and restore it before the cartridge starts, keyed to the cartridge so two games cannot overwrite each other's save. The window is 64 KB at the region `0xE`/`0xF` mapping in `tosdram`, and GBA save types are all smaller than that, so one fixed-size file per cartridge covers every type. The RTC is the other absent capability and is worth doing as its own cycle after that, following TinyGBC's host-side model in shape but not in mechanism: TinyTang reads the DS3231 at 0x68 over I2C and hands a date to its software core through `tn_rt_set_date`, where this core needs either fabric logic speaking the cartridge's register protocol at `0x080000C4`/`C6`/`C8` or a date delivered to that logic over the loader's UART. Until either is done, Emerald's battery message is expected and must not be read as a fault. The three cosmetic artefacts from the sweep -- the Advance Wars scanline (BRD-081), the Fire Emblem flames (BRD-082) and the Castlevania pop (BRD-085) -- remain recorded fingerprints with no diagnosis and each needs an instrument rather than another observation. `tools/load_gba_rom.py` still documents the obsolete host-transfer path and should be retired or rewritten around the card workflow.

#### Files Modified:

- None.

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---

## 77 COMMIT Unreleased 2026-11-15T01:23:44-07:00

#### Coming From:

Unreleased 31f156d

#### Purpose:

Give the core a way to move a cartridge's save data between the cartridge and a file on the SD card, so a save can outlive the board losing power.

#### Outcome:

Save persistence is implemented and the transport is proven on hardware, but the persistence claim itself is not: the negative control that would make it a measurement failed, and that is where the next agent must start. The RTL is a new `fpga/gba/src/memory/gba_save.v`, a byte pump that drives the RISC-V port `sdram_gba` already exposes for cart RAM at RV address 0x700000, through `rv_sdram_adapter`, which upstream provided and this tree had never instantiated -- before this change both sides of that interface in `gbatang_top.sv` were driven by nothing, and the EEPROM's port-B write enable was an undriven wire. Two 16-entry asynchronous FIFOs carry bytes across the clock boundary and the engine moves 128 bytes per request, a size chosen because it divides 8 KB, 32 KB, 64 KB and 128 KB exactly. `iosys_bl616.v` gained commands 0x0e and 0x0f and responses 0x10 and 0x11, and TinyTang gained `gbasave` and a restore step inside `gbaload`. The build passed all five gates and reported `clk67: 67.002 MHz constraint, achieved 173.641 MHz, pass` with `Meets the contract with no relaxation needed`, where the previous build had needed the documented GBATang multicycle exception; bitstream `53d9a2c5e0a62fcbeca4b37a051dc5b81dcf9cbacb35294fbd3dc7ee072c9b1a`, `.bin` `338f35faf7ef6c0ddedd16ea6e32fed1d76ba4f836cda063622b61733d473694`. On hardware the round trip is exact for every type the core supports: SRAM 32768 bytes byte-identical at sha256 `611253a4531dea3d840789b4f11a1ad9c4329fbbf85ee1634f2ae601e6da6db0`, flash512K 65536 identical, EEPROM 8192 identical, flash1M 131070 of 131072 with the two outliers at 0x2AAA and 0x5555 holding 0x55 and 0xF0 -- flash command opcodes, which `sdram_gba.v` line 206 lets into the array because `flash_cmd_en` is cleared whenever `f_mode == MODE_WRITE`, a pre-existing property of the flash model rather than of this path. Restore was shown to write correctly against a known-different state: with the array filled with 0xC3 by an earlier restore, `gbaload` restored the offset pattern and the dump returned the pattern, not 0xC3. Three faults were found and fixed along the way, each recorded. The adapter and engine had been instantiated on clk67 against a bus `sdram_gba` paces with mclk, so every 32-bit read returned the previous read's high halfword and every dump was shifted two bytes; the EEPROM could not have worked at clk67 at all, because `mem_eeprom`'s B port is a clk16 memory. `tools/save/tb_save.sv` had certified the broken version because its controller model presented read data in the same cycle as the acknowledgement, under a comment claiming to reproduce the controller's actual order; it now models the real one-cycle gap and runs a must-fail regression with the adapter on clk67. `gbasave` wedged the shell silently and reproducibly, and a host test (`tools/tests/tb_frames.c` case 11, 27 checks) reproduced the mechanism with no board involved: `rx_decode` stops when the sixteen-frame queue is full, `fpga_frames_take` removes only the type it was asked for, and unprompted joypad reports therefore hide the awaited reply indefinitely; `fpga_frames_flush_queue()` between exchanges fixes it, and the instrumented firmware then completed an 8192-byte dump that had previously gone silent. What is NOT established, and is the whole remaining question, is that a save survives the board losing power. The negative control was run and failed: after a cold boot with the `.sav` renamed so no restore could run, the EEPROM was not blank -- 8121 of 8192 bytes were non-blank and 2775 differed from the pattern that had last been written to it, which is neither "erased" nor "the pattern" and therefore cannot be read as persistence. The follow-up experiment that would separate "the game rewrote it" from "the memory never cleared" was interrupted before it ran, so the cause is unknown.

#### Next Steps:

Start with the failed negative control, because everything else depends on it. The experiment that was cut short is the one to run first: with the cartridge running and no `.sav` present, dump twice about fifteen seconds apart and compare -- identical means the memory is stable and simply was not cleared by power loss, differing means the running game is writing the EEPROM and the control has to be taken with the cartridge held in reset instead. If the store genuinely survives power loss, persistence cannot be tested at all on this machine as it stands and the value of the work reduces to moving saves on and off the card, which the round trip already proves; say so plainly rather than claiming persistence. Then either restore the stashed `.sav`, reload and confirm the pattern returns, or, if the control shows the game interferes, hold the core in reset via loader stage 1 while dumping. Two smaller items are recorded and should be closed in the same firmware build: `fpga_frames_flush_queue()` is called outside a critical section in `gba_save_read` and `gba_save_write` where every neighbouring caller into `fpga_frames` takes one (TCL-062 -- bounded, because `s_q_count = 0` is an atomic word store and only discards joypad reports whose state is cached separately, but it is an inconsistency this cycle introduced), and `tools/load_gba_rom.py` still documents the obsolete host-transfer path. `tools/save/tb_iosys.sv` covers the save read framing only; its write case was removed rather than left failing, because the harness cannot drive 135 bytes at 2 Mbaud without the core's receiver stalling, and the reason is written in the file. The tearing the operator reported across all cartridges is BRD-091 and is a display-path question, not a save one. `third_party/tinydesk` in TinyTang shows as modified and is not this cycle's to commit.

#### Files Modified:

- fpga/gba/src/memory/gba_save.v
- fpga/gba/src/memory/rv_sdram_adapter.v
- fpga/gba/src/iosys/iosys_bl616.v
- fpga/gba/src/gbatang_top.sv
- tools/build_tinygba.sh
- tools/memory_baseline.json
- tools/save/tb_save.sv
- tools/save/tb_iosys.sv
- tools/save/run_save_tb.sh
- tools/save/run_iosys_tb.sh
- tools/save/sav_pattern.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---
## 78 COMMIT Unreleased 2026-11-15T07:21:15-07:00

#### Coming From:

Unreleased 1464fc0

#### Purpose:

Bring the user-facing documentation and the record store back into agreement with what the hardware has shown since they were last written, and correct one record that had been given a status value the store does not define.

#### Outcome:

The README no longer contradicts the records, and three claims in it were wrong rather than merely stale. The twelve-title sweep had been recorded as eleven passes with Pokemon Emerald stopping at the BIOS handover's white screen; BRD-089 has Emerald booting, because `gbaload` finds the save marker while it streams the image and configures the core's save hardware before releasing it, so the sweep is twelve of twelve and the fault was in the loader rather than in the machine. The Open section still carried a bullet headed "The save path has never worked" which asserted that every save write is discarded and that no cartridge with a battery-backed save had ever had one on this board, and BRD-089, BRD-092 and BRD-093 contradict every clause of it; it is replaced by a bullet that states the transport as proven and separates it from persistence, and by a second bullet recording that `tools/load_gba_rom.py` is obsolete for saves rather than that saves do not work. The Known gaps entry "Save hardware is not configured by the loader" was the same stale claim in shorter form and is now the true one: both stores survive a `tangload` and a reload untouched, so a reload cannot test persistence and only a power cycle can, and that test has never completed. Three additions were made from records that had no README counterpart at all: a Status bullet for the save round trip, byte-exact for SRAM, flash512K and EEPROM and 131,070 of 131,072 bytes for flash1M with the two outliers named as flash command opcodes that the flash model admits into the array (BRD-092); an Open bullet for the tearing the operator reported across all cartridges, recorded as a display-path question with the two candidate mechanisms and the point that no capture of a tear has been taken (BRD-091); and a sentence in the multi-load bullet recording that two cartridges loaded back to back can catch the second in the BIOS sequence and look like a freeze that clears on reload (BRD-090). The Deploy section's description of `gbaload` was wrong in its mechanics -- it described only the reset and stream commands and predated save detection and restore -- so it now describes the marker scan and the restore of `<rom-path>.sav`, and `gbasave` is documented beside it with an explicit warning that this is transport and not persistence. A paragraph on `tools/save/` was added to Simulation and a line to Layout, because the save testbenches are now part of the evidence chain and were undocumented. The build and deploy commands were moved from `build/snd_prod` to `build/save_s14` after checking that `build/snd_prod`'s `synth.log` contains no reference to `gba_save.v` and therefore predates the save path, and the new image's digest `338f35faf7ef6c0ddedd16ea6e32fed1d76ba4f836cda063622b61733d473694` was recomputed here and matches the one entry 77 records as deployed. One further contradiction was found while checking the others and is worth more than the documentation change that exposed it: the Open section's timing bullet asserted that every build carrying the audio fix lands at 48 to 57 MHz and needs the documented `clk67` multicycle allowance, and `build/save_s14` carries that fix and passes the gate at 173.641 MHz with `Meets the contract with no relaxation needed`, while `build/hyg_s1` at 51.967 MHz does need it. Four netlists are now measured in this tree and divide evenly, `build/rev_prod` at 181.061 MHz and `build/save_s14` at 173.641 MHz needing no allowance and `build/snd_prod` at 53.622 MHz and `build/hyg_s1` at 51.967 MHz needing it, with the audio fix present in three of the four and slow in two of them, so it neither predicts nor precludes the loss; that is recorded as TCL-063 and the README no longer names the audio fix as the cause, saying instead that the margin must be read from the build in hand. In the record store itself, TCL-062 carried `status: KNOWN`, which is outside the three values the store defines and which its own verification field declines to support, since the finding was reasoned from a comparison of call sites and never measured; it is now `LEAD` and its title carries the `LEAD: ` prefix that all five other LEAD records carry. One inconsistency was found and deliberately not rewritten: BRD-067 is a LEAD whose title lacks that prefix, its status is legal, the prefix is cosmetic, and it is committed history, so it is noted here rather than corrected. Every claim added to the README was checked against its source before it was written, including the `.sav` path convention and the marker-scan behaviour read out of TinyTang's `tang_fpga_uart.c` rather than taken from prose, the deployment digest recomputed from `build/save_s14`, and the gate text read out of `build/save_s14/timing-gate.log`; and both save testbenches were re-run in this tree, `tools/save/run_save_tb.sh` reporting `RESULT: PASS` for the adapter on `clk16` and correctly rejecting the `clk67` wiring, and `tools/save/run_iosys_tb.sh` reporting `RESULT: PASS` for the read framing and correctly rejecting the shipped-broken `save_d_ready`, so the two must-fail regressions still fail and the claims about them in the README remain evidence rather than assertion. The core-syntax audit required by `.ai/core.md` was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, the complete `.ai/` diff was inspected, `.ai/core.md` was confirmed unchanged, entry 78 was validated as the seventy-eighth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed to hold 78 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 156 records with no duplicate ids, every record presenting its fields in canonical order, and every status now inside the three-value vocabulary at 144 `VERIFIED`, 5 `MEASURED` and 7 `LEAD`; 36 of those records carry no `verification` field and end at `sources`, which is a long-standing and consistent practice in the store rather than a conformance failure, and this cycle neither added nor removed one. The six historical log entries that carry prose in their Status values, numbers 5 and 14 to 18, are unchanged and remain noted as entry 72 recorded them.

#### Next Steps:

The persistence question is still the open one and still needs the board: the interrupted experiment is to run a cartridge with no `.sav` present and dump twice about fifteen seconds apart, identical meaning the store is stable and was simply never cleared by power loss and differing meaning the running game is writing it, in which case the control has to be taken with the core held in reset through loader stage 1, and neither the Tang nor the card was connected during this cycle so nothing was measured. After that, the tearing in BRD-091 needs a capture long enough to contain a tear -- minutes of footage rather than the thirty seconds the existing method takes -- before either candidate mechanism can be separated. Three smaller items are ready and need no decision: `fpga_frames_flush_queue()` should be wrapped in a critical section the way `tang_fpga_joypad` does it, which TCL-062 now records as a lead rather than a finding and which should be closed in the next firmware build; `tools/load_gba_rom.py` still documents the obsolete host-transfer path and should say that it cannot configure save hardware; and the placement seed is not recoverable from a build directory's products, being carried only by the directory name, which is why TCL-063 cannot be stated as a fixed-seed comparison -- writing the seed into the build directory would make the next such comparison checkable. BRD-067's missing `LEAD: ` prefix is cosmetic and can be taken whenever that record is next touched. Nothing here is urgent against a machine that runs all twelve cartridges, and the save path should not be described as persistence anywhere until the control succeeds.

#### Files Modified:

- README.md

#### Status:

- Build: N/A
- Deployment: N/A
- User Test: N/A

---
## 79 COMMIT Unreleased 2026-11-15T08:08:24-07:00

#### Coming From:

Unreleased 4f22700

#### Purpose:

Run the persistence control that entry 77 left as this session's starting point, settle whether the running cartridge or the store itself is what made the earlier negative control unreadable, and record what the board actually does across a power cycle.

#### Outcome:

The control has now been run and it cannot succeed, for a reason that is measured rather than inferred, and the explanation it displaces was wrong in an instructive way. Entry 77 had left a fork: after a cold boot with no `.sav` present the EEPROM was neither blank nor the pattern last written, and it could not tell whether the memory was stable and had never cleared or whether the running game was writing it. The cheaper branch of that fork is now closed. With the EEPROM filled with `0xC3` through the shipped restore path, Super Mario Advance 2 was loaded and left running, and two `gbasave` dumps about fifteen seconds apart returned sha256 `4ab596140ada097ffb0ae8f6a701fc349be23f448f746b5543d0d9d454ee8d0a`, byte-identical to the fill that had been restored and identical to each other, so an unattended running cartridge does not disturb the store and does not have to be held in reset to take a valid reading (BRD-095). That leaves the store, and the store is the answer. A pattern was written into the save window over the host path and read back byte-exact (`3faac63d133ee546e983a131136bc44c9d3c0910d1c6b143d60509ef90a386e7`), the board was power-cycled, and after a `tangload` the EEPROM read back `65047658e4d7d4e082295f0422f379a5f199c0a7b1cf9d74253ce93f1cb53e2e`, which is the pattern with 360 of 8192 bytes differing. The board was power-cycled a second time and read back the same `65047658` byte for byte, with no `.sav` present and none written in between, the second reading being taken over `fpgapipe` with the core parked in loader stage 3. Both cycles were verified to be real power losses rather than resets on the evidence that the FPGA answered `fpga: core 84`, the board's own default core, before `tangload`, and `core 3` only after it. `mem_eeprom` is Gowin block RAM carrying no `INIT_` parameters and nothing in the design restores it, so a fresh fabric has no defined content; the store nevertheless retains 95.6 per cent of what it held. It does not clear, it partially decays, the decay happens once and the content is then stable, and the differing bits fall evenly across all eight bit positions rather than on one lane or one address range (BRD-094). That is the mechanism behind entry 77's 8121-non-blank, 2775-differing reading, and it means persistence is not testable on this hardware as it stands, because the only event that could destroy the store does not destroy it, so nothing distinguishes "the save persisted" from "the memory was never lost". It also means the store is not trustworthy as a save at all: 4.4 per cent corruption per cycle is neither volatile enough to be a clean subject nor non-volatile enough to be relied on, and the demonstrated value of this work reduces to what BRD-092 already proves, which is moving a save on and off the card. Getting any of this measured required a route around the console, because the BL616 stopped answering three times in the session and every time the command in flight was moving a file — `gbasave` twice and `tangput` once — while `tangload` ran eight times and `gbaload` five at up to 16 MiB without a single failure; the kernel logged no USB disconnect after 07:35 while the CDC node stayed enumerated and a single carriage return timed out on write, so the firmware had stopped servicing the console with the device still attached, and recovery needed power removal because `cdc_acm/unbind` and the device's `authorized` node are not writable to an unprivileged user and `sudo` is blocked by `no new privileges` (TCL-064). The route that worked is `fpgapipe`, which moves console bytes to and from UART1 through `uart_write` and `rx_pop` directly and so skips both the SD and the sixteen-frame decoder TCL-061 identified as the place a reply gets hidden; over that pipe 64 save-read frames were requested and answered for a full 8 KiB dump with no SD write and no `gbasave` involvement. Two mistakes in this session are recorded because they cost board time rather than because they produced results. Re-flashing the FPGA over JTAG to test whether reconfiguration clears the store was wrong twice over: it was the wrong experiment, since a reconfiguration cannot distinguish a volatile store from a retained one, and it left the core unreachable on both FT2232 channels. And a port-discovery helper that opened every `/dev/ttyACM*` in turn to find a shell interrupted another session's flash, because on this machine a watch comes and goes on the same ttyACM namespace and opening a port is not read-only; the fix, and the rule, is to resolve the node from the USB descriptor in sysfs — the board is `ffff:5454` at `1-13` — and never by probing candidates. The README's persistence bullet and Known gaps were corrected to state the measured position and cite BRD-094, BRD-095 and TCL-064. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged, the complete `.ai/` diff was inspected, entry 79 was validated as the seventy-ninth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 79 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 159 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Persistence should be described as untestable on this hardware and not as unproven-but-promising, and no further cycle should spend a power cycle trying to make the store read blank, because BRD-094 shows the control cannot reach that state. If persistence on real hardware matters to this project, the next step is not another measurement here but a decision about whether the store should be made deterministic — either by initialising `mem_eeprom` so a fresh fabric has a known content and the difference between volatile and retained becomes observable, or by accepting that the save lives on the card and dropping any claim about the cartridge's own store. The first is a small RTL change and would make the question answerable for the first time; it also needs approval, since it changes a vendored IP. The console defect is worth closing before another save cycle is attempted: `cmd_fpga` takes the unbounded `tang_fpga_lock()` where its neighbours take `tang_fpga_lock_within`, which is why the console goes silent even for an innocent `fpga` after a transfer has failed, and that is a one-line fix in TinyTang rather than here. Until it is fixed, a save dump should be treated as the least reliable operation on this board and `fpgapipe` plus the `0x0e` and `0x0f` frame types as the way to reach the save window, which is what made this cycle measurable at all. The host-side save tool that used those frames is still a scratch script and probably belongs in `tools/save/`, committed and documented, because it is the only path that survives the console dying. Two smaller items stand unchanged from entry 78: `fpga_frames_flush_queue()` should be wrapped in a critical section, and `tools/load_gba_rom.py` should say plainly that it cannot configure save hardware. The scratch files left on the card are `t_sma2.gba` and possibly `fillA5.sav` if the interrupted `tangput` completed, and they should be removed; the operator's own `.sav` files were never written to and are backed up outside the repository.

#### Files Modified:

- README.md

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: PASS

---
## 80 COMMIT Unreleased 2026-11-15T08:23:15-07:00

#### Coming From:

Unreleased ca17b23

#### Purpose:

Establish what licence the Gowin-authored files inside `fpga/gba/src/` are actually under, record the answer, and scope the replacement work that follows from it, without changing any RTL.

#### Outcome:

The question was asked because this repository is described as open flow and those files carry Gowin Semiconductor's copyright, which looks impossible until the mechanism is seen. Sixteen files under `fpga/gba/src/` carry `Copyright (C)20xx Gowin Semiconductor Corporation. All rights reserved.`, with no grant, no SPDX tag and no licence text; nine of them are in the shipped build, being the six memory wrappers `memory/mem_eeprom.v`, `memory/mem_iwram.v`, `gpu/vram_lo.v`, `gpu/vram_hi.v`, `iosys/gowin_dpb_menu.v` and `fb.v` and the PLL wrappers `pll/pll_12.v`, `pll/pll_27.v` and `pll/pll_33.v`, while the other seven are unbuilt duplicates in an unused `plla/` directory plus `pll/pll_74.v`, which the hand-written `pll/gowin_pll_hdmi.v` supersedes. They build in the open flow, and the reason is that they are not vendor HDL but flat Verilog instantiating blackboxed primitives: `DPB`, `SP`, `DPX9B` and `PLL` are passed to `read_slang` as `--blackboxed-module`, behaviour comes from oss-cad-suite's `cells_sim_nospecify.v` and `cells_xtra_gw5a.v`, and nextpnr places them against apicula's device database, so no Gowin EDA is involved and none is needed; the build never reads the `.ipc` or `.mod` descriptors sitting beside them. The generated cells are not vestigial, since `build/save_s14`'s routed netlist holds 66 `DPB`, 16 `SP` and 43 `DPX9B`, of which 53 `DPB` are declared in the four memory wrappers, all 16 `SP` in `mem_iwram`, and 38 of the `DPX9B` in `fb.v` (TCL-065). On the licence itself the answer is no, and it is no for a reason that choosing a different licence cannot fix: GBATang is GPL-3.0 and these files arrived inside GBATang's tree, but a licensor can only license what it owns, so GBATang's grant does not reach Gowin's generated output and neither this project's MIT, GPL or Apache-2.0 terms can. Whether redistribution is permitted at all turns on Gowin's EULA, which is not established here and is not asserted: no Gowin EDA is installed on this machine and no EULA text is in the tree, and inventing a permission is the one thing this store exists to prevent. Two further facts came out of the same reading and both matter for the replacement work. The precedent inside this project's own family is that the ambiguity has been reduced rather than resolved, since TinyNES carries no Gowin-generated file at all while TinySNES replaced its PLL wrappers with hand-written GPL-3.0 ones and still ships Gowin-headed RAM wrappers. And the flow demonstrably infers memory primitives from behavioural RTL, because 43 `DPX9B` appear in the netlist against the 38 declared in `fb.v`, so five came from arrays such as `linebuffer.v`'s. That made the conversion look cheaper than it is, and scoping it against the two generic wrappers already in the tree revised the plan: only `gowin_dpb_menu` fits `dpram_block`, because `dpram_block` has one width for both ports and `mem_eeprom` is 65536 by 1 on port A and 8192 by 8 on port B, `dpram32_block` is limited to 1024 words where `vram_lo` is 16384 by 32 and `vram_hi` 8192 by 32, and `mem_iwram` is a single-port `SP` where `dpram_block` is dual-port `DPB`. Three of the six memories do, however, already carry a generic behavioural model at the same instantiation site under `ifdef VERILATOR` -- `mem_iwram`, `vram_lo` and `vram_hi` -- while `mem_eeprom`'s equivalent exists only as a commented-out `dpram_block` instantiation and `gowin_dpb_menu` and `fb.v` have none, so half the work is a swap and half is new RTL. Because that is a material change to a plan already approved, work stopped before any RTL was edited, as `.ai/core.md` requires, and this cycle records the finding instead. `THIRD_PARTY.md` gained a paragraph under the GBATang entry stating that a subset of that tree is not nand2mario's work and is not GPL-3.0, naming the nine built files, saying they are carried as build inputs rather than as licensed source, and recording that the EULA question is unresolved, because the previous wording described the whole of `fpga/gba/src/` as GPL-3.0 and that is the one sentence a downstream user could read as a grant this project cannot back. No RTL, no build script and no README statement was changed, and the build, deployment and user-test stages do not apply to a documentation-and-records cycle. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged, the complete `.ai/` diff was inspected, entry 80 was validated as the eightieth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 80 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 160 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

The conversion needs one decision before it needs any code, and the honest framing is that the approved scope and the achievable scope differ. Replacing the six memory wrappers means writing this project's own generic wrappers -- an asymmetric-port one for `mem_eeprom`, a wide one for the VRAMs with byte enables, and a single-port one for `mem_iwram` -- and letting yosys infer `DPB` and `SP`, or converting those four sites to the behavioural models that already sit in their `ifdef VERILATOR` branches after removing the whole-array synchronous reset loop that would prevent inference; either way `gowin_dpb_menu` needs a wrapper written from scratch because it has no behavioural counterpart. The success criterion is measurable and should be stated before the work rather than after: `DPB` must stay 66 and `SP` 16 in the routed netlist, the timing gate must still pass, and the memory diagnostic and a retail cartridge must still run, which means the last step needs the board and the operator rather than a build. The risk is concentrated in `vram_lo` and `vram_hi`, which account for 48 of the 53 wrapper `DPB` and sit on the GPU path every cartridge draws through, so they should be converted last and separately from `mem_eeprom`, which carries the save path already known to be the most fragile thing here. A smaller scope is available and defensible: converting only `gowin_dpb_menu` and `mem_eeprom` removes two of the six wrappers for much less GPU risk, and the licence position is not improved or worsened by partial conversion since the files are simply deleted rather than relicensed. The PLL wrappers should be treated as a separate decision, because `pll_33`'s operating point at FVCO 1809 MHz sits outside apicula's charge-pump model and was measured with a Gowin EDA oracle run, so replacing it means either finding an in-band plan or hand-writing the parameters the oracle produced, which is what `pll_16.v` and `gowin_pll_hdmi.v` already do for two of the clocks. Nothing in this cycle changes what the board does, and reading Gowin's EULA remains the cheapest way to settle whether any of the conversion is required for distribution rather than merely desirable.

#### Files Modified:

- THIRD_PARTY.md

#### Status:

- Build: N/A
- Deployment: N/A
- User Test: N/A

---
## 81 COMMIT Unreleased 2026-11-15T08:43:52-07:00

#### Coming From:

Unreleased 9d958f1

#### Purpose:

Give the repository a licence it actually states, resolve the contradiction entry 80 left inside `THIRD_PARTY.md`, and bring SPDX coverage in line with the claim, without changing what the design does.

#### Outcome:

The repository now carries a root `LICENSE` holding the unmodified GPL-3.0 text, verified byte-identical by sha256 against two independent copies -- `/usr/share/common-licenses/GPL-3` and TinySNES's own `LICENSE`, both `3972dc9744f6499f0f9b2dbf76696f2ae7ad8af9b23dde66d6af86c9dfb36986` at 674 lines -- so the text was checked rather than regenerated from memory. `THIRD_PARTY.md` gained a `## This repository's own licence` section modelled on TinySNES's, stating GPL-3.0-only and recording why the licence is forced rather than chosen: `fpga/gba/src/` is GBATang under GPL-3.0, vendored in-tree and compiled into the same bitstream, so the result is one work and GPL-3.0 is the only licence it can carry, with `-only` rather than `-or-later` matching the absence of an "or later" clause in the GBATang notices. That section replaces the paragraph that had left the question open, which was the contradiction entry 80 introduced: a carve-out at the top of the file saying part of the tree is not GPL, sitting above a closing paragraph saying the licence was undecided and misdescribing the whole of `fpga/gba/src/` as GPL-3.0. The carve-out itself was rewritten to read as an ordinary third-party notice, naming the sixteen Gowin IP-generator files and the nine that are built, saying they are used as build inputs and are not covered by this repository's licence, and dropping the sentence that asserted they could not be relicensed -- which was true and narrow, but had been used to answer a different question and gave a misleading impression about whether the repository could ship at all. The open question is now stated as open: whether Gowin's own terms permit redistributing IP-generator output, which nobody here has read because no Gowin EDA is installed and no EULA text is in the tree. SPDX coverage was brought up to the claim in that section, since it said every file this project wrote carries a header and that was not yet true: seven files gained one, being `tools/check_cartread.py`, `tools/clock_edge_check.py`, `tools/load_gba_rom.py`, `tools/score_phases.py`, `tools/save/tb_save.sv`, `tools/save/tb_iosys.sv` and `fpga/gba/src/memory/gba_save.v`, the last being the only file this project added under `fpga/gba/src/`. The tree now shows 51 `GPL-3.0-only` headers and one `MIT`, `tools/fs_to_bin.py`, which was carried in from TinyTang and keeps its own licence as GPL-3.0 permits; the section names that exception rather than claiming uniformity. Because `gba_save.v` is synthesised RTL and the other six edits touch files the gates read, the claim that none of this changes the design was measured instead of assumed: a pre-change and a post-change synthesis at `TINYGBA_STAGE=synth` with `-DTINYGBA_OVERLAY_OFF` produced netlists that differ only in source-line annotations, with 406 `gba_save.v` references each shifted by exactly one line, and after normalising those the two `modules` objects are identical -- 234 modules, 52,453 cells, identical cell-type counts, everything but the `creator` field compared. Both save testbenches were re-run after the edits and both pass with their must-fail regressions still correctly rejected, and the four Python tools that gained headers were confirmed to exit exactly as their pre-change versions did. One earlier error is corrected here rather than left standing: entry 80 recorded that four of the six memory wrappers have a generic behavioural counterpart, which was wrong -- three do (`mem_iwram`, `vram_lo`, `vram_hi`), `mem_eeprom`'s equivalent is commented out, and `gowin_dpb_menu` and `fb.v` have none -- and the record and the file now say three. A second correction belongs to the same class: this cycle's first draft of the licence section asserted that `.ai/` is covered by the repository licence, which is a decision belonging to the operator rather than to an agent, and the assertion was removed. The wrapper conversion that follows from the licensing question was not started, because it is a separate cycle with real hardware risk and the plan for it changed materially after review. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged, the complete `.ai/` diff was inspected, entry 81 was validated as the eighty-first entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 81 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 161 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

The wrapper conversion is the next cycle and it has an agreed shape, recorded in TCL-066's neighbours and in entry 80: replace all six Gowin memory wrappers with hand-written wrappers of this project's own that instantiate `DPB`, `SP` and `DPX9B` with the same parameters, so the netlist stays identical rather than depending on inference picking the same mapping; a small generator script kept under `tools/` should produce the parameter blocks from depth and width, with `fpga/gba/src/common/dpram_block.v` as the model. The six are `gowin_dpb_menu` at 1 `DPB` and 2048 by 8, `mem_eeprom` at 4 `DPB` with asymmetric 65536 by 1 and 8192 by 8 ports, `mem_iwram` at 16 `SP` and 8192 by 32, `vram_hi` at 16 `DPB` and 8192 by 32, `vram_lo` at 32 `DPB` and 16384 by 32, and `fb.v` at 38 `DPX9B` and 38400 by 18, which is 53 `DPB`, 16 `SP` and 38 `DPX9B` in total. Each conversion must be checked against the counts in TCL-065 and the routing is expected to be identical, so the success criterion is that a `TINYGBA_STAGE=synth` census is unchanged and a full build still passes the timing gate before anything goes to the board. Order the work menu first, then the EEPROM, then IWRAM, then `fb`, and the two VRAMs last and separately, because they hold 48 of the 53 wrapper `DPB` and sit on the GPU path every cartridge draws through; a failure there is expensive to attribute and the EEPROM carries the save path, which is already the most fragile part of this machine. The last step needs the board and the operator, since neither a census nor a timing gate can say whether a picture draws or a save round-trips. Two items remain open and neither is urgent: whether Gowin's terms permit redistributing its generated output, which reading the EULA would settle and which this cycle deliberately did not answer, and whether `.ai/` should be covered by the repository licence, which is the operator's decision and is currently unstated.

#### Files Modified:

- LICENSE
- THIRD_PARTY.md
- fpga/gba/src/memory/gba_save.v
- tools/check_cartread.py
- tools/clock_edge_check.py
- tools/load_gba_rom.py
- tools/score_phases.py
- tools/save/tb_iosys.sv
- tools/save/tb_save.sv

#### Status:

- Build: N/A
- Deployment: N/A
- User Test: N/A

---
## 82 COMMIT Unreleased 2026-11-15T09:19:20-07:00

#### Coming From:

Unreleased cb3c0e2

#### Purpose:

Begin replacing the Gowin memory wrappers with this project's own RTL, starting with the OSD text page, and establish whether the remaining four can be converted by the same method.

#### Outcome:

One wrapper is converted and verified; the second was attempted four times and abandoned, and the reason is worth more than the conversion. `fpga/gba/src/iosys/gowin_dpb_menu.v` is gone, replaced by `fpga/gba/src/iosys/menu_ram.v`, with `textdisp.v` and the build file list pointed at it and a new `tools/gen_mem_wrappers.py` that extracts primitives' parameter blocks and initial contents so they are copied mechanically rather than retyped. That last part matters more than it sounds: the block is not only the 32x28 character buffer, it holds a 14x9 logo and the 8x8 font in 28 non-zero `INIT_RAM_*` words, and a wrapper emitted without them builds cleanly and then draws a blank text page. Equivalence was established by a side-by-side module containing both the old and new wrappers, which synthesises to 2 `DPB` and nothing else, and by the full build's census being unchanged at 66 `DPB`, 16 `SP`, 43 `DPX9B`, 125 block RAM and 66 distributed RAM, with both carrying the same 28 non-zero initial words at `BIT_WIDTH_0=8` (TCL-067). Two toolchain facts were paid for along the way. A parameter list of roughly seventy entries must be applied with `defparam` rather than `DPB #(...)`: the `#()` form works on a three-parameter toy and fails on this instance, after which slang parses `DPB` as a user-defined primitive and emits twenty errors, which is why nand2mario's one-parameter `dpram_block.v` can use it and Gowin's generated wrappers cannot. And `mem_eeprom`, the second wrapper, defeated the method. It is four `DPB` blocks with 27 `MUX2` and 4 `DFFRE` around them, banking on the top address bits and registering the output select by one cycle to match block RAM latency. Three restatements were built against it -- static banks with `BLKSELA` tied to the instance index, then the same with the original's `~wrea` gating, then the vendor's actual structure with dynamic `BLKSELA` and per-instance `BLK_SEL_n` -- giving 52,379, 52,262 and 52,350 cells against the 52,540 of the tree without it, with the last moving two flip-flops from `DFFRE` to `DFF` rather than matching in kind. None of that is evidence: the same tree varies by several hundred LUTs between builds with no source change, because ABC picks a different optimisation boundary, which is the effect TCL-056 recorded when the identical netlist-class moved between 48 and 181 MHz. Against that noise floor a 190-cell discrepancy cannot separate a real structural error from arithmetic, and a match would have been luck. The intended check, simulation, is unavailable: `tools/sim/gowin_cells_sim.v` declares `DPB`, `SP` and `DPX9B` with empty bodies and oss-cad-suite's own `cells_sim.v` has no `DPB` module at all, so nothing in this toolchain can simulate a memory. The attempt was reverted rather than shipped, and the other four wrappers were not started (TCL-068). Two things came out of reading the remaining wrappers that shape what comes next. Every one of them puts its generated logic in the same shape -- a look-up table decoding upper address bits per bank, as `vram_lo`'s `LUT4` with `INIT=16'h0001` on `ada[10..13]` does, a registered select, and a multiplexer tree -- so a single parameterised template could cover them if the correctness question were answerable. And Gowin drives `BLKSEL` dynamically as a bank select while yosys's own techmap always ties it to zero, so the vendor's intent is to treat that input as an enable and the inference path treats it as static configuration; that difference is the substance of the missing model rather than a detail. `THIRD_PARTY.md` was updated to fifteen Gowin files with eight in the build, the menu having left that set. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged, the complete `.ai/` diff was inspected, entry 82 was validated as the eighty-second entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 82 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 163 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

The next cycle is the simulation model, not another wrapper, because until it exists the remaining four cannot be converted on evidence. `tools/sim/gowin_cells_sim.v` needs `DPB`, `SP` and `DPX9B` implemented rather than declared: the `BIT_WIDTH`, `READ_MODE`, `WRITE_MODE` and `RESET_MODE` settings the wrappers use, one-cycle read latency, synchronous and asynchronous reset, the `INIT_RAM_*` initial contents, and `BLKSEL` as the dynamic bank select Gowin uses it as. That model is this project's own approximation of a vendor primitive and must say so, and its fidelity should be checked first against a memory whose behaviour is already known on hardware -- the OSD text page is the obvious candidate, since `menu_ram` is this tree's own and the font either appears or does not. With it, each remaining wrapper becomes a cycle-by-cycle comparison of old against new under random stimulus, which catches an off-by-one latency, a wrong enable or a transposed port, none of which a census can see. The order to attempt is `mem_eeprom` first, because it is four blocks and has save testbenches already, then `mem_iwram`, then `fb.v`, and the two VRAMs last, since they carry 48 of the 53 remaining `DPB` on the GPU path every cartridge draws through. Before any of that, the OSD change itself is unverified on hardware: `menu_ram` has never drawn a text page, so a build and a `tangload` with a cartridge that prints to the OSD would confirm the one conversion that has been made. Separately and independent of this work, the `defparam` finding means any future hand-written wrapper here should use that form; and reading Gowin's EULA, which nobody here has done, would still settle whether any of this conversion is required for distribution rather than merely desirable.

#### Files Modified:

- THIRD_PARTY.md
- fpga/gba/src/iosys/menu_ram.v
- fpga/gba/src/iosys/textdisp.v
- tools/build_tinygba.sh
- tools/gen_mem_wrappers.py

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---
## 83 COMMIT Unreleased 2026-11-15T09:20:27-07:00

#### Coming From:

Unreleased 8167f52

#### Purpose:

Correct two counting errors in entry 82's cycle and finish the file removal that entry described, so that the tree and `THIRD_PARTY.md` agree on how many Gowin files remain.

#### Outcome:

Three corrections, all mechanical, all in the cycle committed as `8167f52`. First, `fpga/gba/src/iosys/gowin_dpb_menu.v` was left in the tree by that commit and is now deleted: the replacement `menu_ram.v` is in the build and nothing references the old file, but leaving it meant the tree still carried sixteen Gowin-headed files while `THIRD_PARTY.md` had been edited to say fifteen, so the file count and the document disagreed. Deleting it makes both true at fifteen files, of which eight are in the shipped build -- the five remaining memory wrappers and the three PLL wrappers -- and seven are not, being six duplicates in the unused `plla/` directory and `pll/pll_74.v`. Git history retains the superseded file, which is the point of removing it from the working tree rather than keeping it for diffing as `pll_74.v` was kept: the licensing question this work exists to answer is settled by the file being gone, not by it being unbuilding. Second, TCL-068 said "the remaining four memory wrappers" and then named five, which is an error of arithmetic inside a record that exists to be quoted. Third, the same sentence said those wrappers carry "53 of the 66 `DPB`", a figure arrived at by including the menu's single `DPB`, which is no longer one of them; the correct count is 52, being four in `mem_eeprom`, sixteen in `vram_hi` and thirty-two in `vram_lo`, and the record now says so with the split shown. Nothing else changed: no RTL, no build script, no other record, and the fourteen files left as they were. The core-syntax audit was re-run over the whole `.ai/` diff because this commit edits a settled entry: `.ai/core.md` and `.ai/core-syntax.md` were re-read and `.ai/core.md` confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, entry 83 was validated as the eighty-third entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 83 entries against the 100-entry limit with no gaps in its numbering, the reference store was confirmed at 163 records with no duplicate ids and every status inside the three-value vocabulary, and the corrected TCL-068 was re-read in full after editing.

#### Next Steps:

Unchanged from entry 82 and unaffected by these corrections: the next cycle writes behavioural models for `DPB`, `SP` and `DPX9B` into `tools/sim/gowin_cells_sim.v`, since without them the remaining five wrappers cannot be converted on evidence, and the OSD text page `menu_ram` replaced has still never been drawn on hardware, so a build and a cartridge that prints to the OSD remains the cheap confirmation of the one conversion already made. The lesson worth carrying from this cycle is small and specific: a document that states a count and a tree that contains one are two facts that drift the moment either changes, and the only reliable way to catch it is to recount from the tree after the edit rather than trusting the edit. That is what found this, and it was found only because the deletion had been left undone.

#### Files Modified:

- fpga/gba/src/iosys/gowin_dpb_menu.v

#### Status:

- Build: N/A
- Deployment: N/A
- User Test: N/A

---
## 84 COMMIT Unreleased 2026-11-15T09:28:17-07:00

#### Coming From:

Unreleased 5d39131

#### Purpose:

Give the block RAM primitives a behavioural model so a memory wrapper can be checked by simulation, and use it to replace the EEPROM wrapper with this project's own RTL.

#### Outcome:

The second memory wrapper is converted and this time the substitution is proved by simulation, which is what entry 82 said was missing. `tools/sim/gowin_bram_sim.v` now models `DPB`, `SP`, `SPX9` and `DPX9B` rather than declaring them: the width-to-depth relation of a 16 Kbit block, the 64 `INIT_RAM_*` words, one-cycle read latency, `OCE` output gating, `RESET_MODE`, byte strobes taken from a 16-bit port's address bits [1:0], and `BLKSEL` compared against each instance's `BLK_SEL`. That last is the semantic the vendor's wrappers depend on and the one that made the primitive impossible to restate from reasoning: `mem_iwram` drives `BLKSEL` from `{ad[12],ad[11],ad[10]}` while pinning its instances to `BLK_SEL` 0 through 15, so the block acts only when the two agree, whereas yosys's own inference ties every `BLKSEL` to `3'b000` and never uses it. `MUX2` and `DFFRE` were modelled alongside so that a wrapper can be simulated without pulling in the whole cell library. `fpga/gba/src/memory/mem_eeprom.v` is gone, replaced by `fpga/gba/src/memory/eeprom_ram.v`, which follows the vendor's structure deliberately: four blocks, each told its identity by `BLK_SEL_n` and told the current bank by `BLKSEL` from the top address bits, port A 1 bit over 65536 addresses and port B 8 bits over 8192 as two views of the same storage, and an output multiplexer whose select is registered one cycle ahead of the data and gated by the read enables so a write does not redirect it. The `.ipc` and `.mod` descriptors went with the file. `tools/sim/tb_eeprom_equiv.sv` instantiates both wrappers side by side and compares both outputs on every clock edge over 12000 random cycles plus a directed pass over every bank, giving 24018 samples and 48036 comparisons with no mismatch, and `tools/sim/run_mem_equiv_tb.sh` runs that and then requires two deliberate defects to fail: gating the bank register on `cea` alone rather than `cea & ~wrea` produces 1603 mismatches and selecting the mux from the live address rather than the registered one produces 1872, so the test is demonstrably able to see both the latency and the gating class of fault. That gate matters more than the passing result: the first attempt at this wrapper, reverted in entry 82, had exactly the write-gating defect the first injected case reproduces. The build's census is unchanged at 66 `DPB`, 16 `SP`, 43 `DPX9B`, 125 block RAM and 66 distributed RAM, and both save testbenches still pass with their must-fail regressions rejected. `THIRD_PARTY.md` now lists fourteen Gowin files with seven in the build. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 84 was validated as the eighty-fourth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 84 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 164 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Four wrappers remain and the model now makes each of them a bounded job rather than a guess: `mem_iwram` at 16 `SP` over 8192 by 32, `fb.v` at 38 `DPX9B` over 38400 by 18, and `vram_hi` then `vram_lo` at 16 and 32 `DPB` over 8192 and 16384 by 32, the two VRAMs last because they hold 48 of the remaining `DPB` on the GPU path every cartridge draws through. Take `mem_iwram` next, but settle one thing before writing it: all sixteen of its instances are driven by the same `BLKSEL` and pinned to `BLK_SEL` values 0 through 15, so two instances share each value and the model's enable-by-match cannot be exactly what the device does -- it will make a wrapper that happens to work because the addresses never collide, rather than one that is right. Whether the model should carry a `BLK_SEL` that selects a group rather than an instance is a question about the primitive that simulation cannot answer on its own, and the honest options are to widen the model's `BLK_SEL` semantics with a comment saying it is a reading, or to convert `fb.v` first since its 38 instances span distinct groups in a way that can be checked. What must not happen is arithmetic on cell counts standing in for a simulation pass: entry 82 established that a cell census moves by hundreds of LUTs for reasons unrelated to the change. Independently, none of this work has been on hardware: `menu_ram` has still never drawn an OSD text page and `eeprom_ram` has never round-tripped a save, so a build with both and a cartridge that both prints to the OSD and writes its save would settle two conversions at once, and BRD-092's round trip is the measurement to repeat rather than to assume. The three PLL wrappers remain out of scope and unchanged.

#### Files Modified:

- THIRD_PARTY.md
- fpga/gba/src/memory/eeprom_ram.v
- fpga/gba/src/memory/gba_eeprom.sv
- fpga/gba/src/memory/mem_eeprom.v
- fpga/gba/src/memory/mem_eeprom.ipc
- fpga/gba/src/memory/mem_eeprom.mod
- tools/build_tinygba.sh
- tools/sim/gowin_bram_sim.v
- tools/sim/run_mem_equiv_tb.sh
- tools/sim/tb_eeprom_equiv.sv

#### Status:

- Build: PASS
- Deployment: NOT RUN
- User Test: NOT RUN

---
## 85 COMMIT Unreleased 2026-11-15T11:23:49-07:00

#### Coming From:

Unreleased f8da3f9

#### Purpose:

Put the two replaced memory wrappers on hardware in an image where both are live, prove the OSD text page draws, and settle by seed sweep whether the production configuration's clock-plane failure was placement luck or a property of enabling the overlay.

#### Outcome:

Both conversions are verified on hardware and the production configuration is not harder to place. `build/hw2`, an `OVERLAY_OFF` image carrying `menu_ram` and `eeprom_ram`, passed every gate with `clk67` at 195.886 MHz, no hold violations and no relaxation, was uploaded to the card as `tinygba_hw2.bin` and read back to the same digest before loading, and on it Super Mario Advance 2 ran with a correct picture while the EEPROM round-tripped byte for byte: the canonical pattern was placed as a `.sav`, `gbaload` reported `restoring 8192 bytes of EEPROM` and `save restored, 8192 bytes of EEPROM`, and the dump fetched back was sha256 `3faac63d133ee546e983a131136bc44c9d3c0910d1c6b143d60509ef90a386e7`, identical to what went in (BRD-096). That image suppresses the overlay by design, so the OSD was untested by it; the production image `build/hw3` built for that purpose failed its clock-plane gate with `NO PLANE PIP: 'clk67' crosses no bridge pip, so it is on general routing`, and since every historical build in the tree has `clk67` on `SPINE25/TOP1=good` and every one of them was `OVERLAY_OFF`, that single failure could not distinguish seed luck from the overlay path costing `clk67` its plane pip. A seed sweep answered it. `tools/sweep_tinygba_seeds.sh` reports hold only, which its own header says is not the whole criterion, so `tools/sweep_build_seeds.py` was written to run the same two gates the build runs, `clock_plane_report.py` non-strict and `timing_gate.py`, against each seed's routed netlist; its parsing was validated first against `build/hw3`, which it reproduced as a plane failure with the same text, before twelve seeds of the production netlist were launched eight at a time. Six reached place and route before the run was stopped, and five of the six were deployable -- seeds 1, 3, 4, 6 and 8, each with `clk67` on a measured-good spine at 170 to 202 MHz against 67.002, zero hold violations and no relaxation -- while seed 11 failed place and route outright (TCL-071). Seed 3 was taken as the best on the highest total margin across all four clocks at 7.27 of constraint and the cleanest plane report, `SPINE25/TOP1=good` with no unmeasured entry beside it, and `build/prod3` was packaged from that seed's routed netlist with `TINYGBA_STAGE=pack`. Its `.bin` sha256 `b375e05911b26df18151cf51cee56119a66313653fd9add867ca6a3e98c9b006` was uploaded as `tinygba_prod3.bin`, read back byte-identical, and loaded, after which the FPGA answered `core 3`; the routed netlist holds 110 `DP` cells against the `OVERLAY_OFF` image's 109, the difference being the OSD text page, so the replaced memory is demonstrably present rather than optimised away. On the board the text page drew `MENURAM REPLACES GOWIN DPB`, the alphabet in both cases and the digits, and the GBATang logo with them, and both font and logo are initial contents rather than run-time writes, which is exactly the data a wrapper emitted without the `INIT_RAM` words would have lost (BRD-097). The same image then ran the cartridge: BIOS booted, the intro drew in full colour, and `osd off` returned the picture undistorted. That evidence is agent-side -- captures and console output, plus the operator's description of the sequence on screen -- and the operator has not reported acceptance of the result, so User Test is recorded as not run rather than passed. One behaviour is recorded because it reads as a fault and is not: turning the overlay on after a cartridge has started composites the text page over the running machine, which presents as the game being replaced by a black page with yellow text, and hiding the overlay restores it. Two mistakes of my own cost time and are recorded. A production build was retried at seed 5 rather than reasoned about, and the answer was a sweep, so that build was killed; and the sweep's first launch died with all eight placements at the same line of their logs because `nohup ... &` from a shell that later exits takes its children with it, which looks like eight independent failures and is one process-group kill. A third error was in the record rather than the work: the first draft of TCL-071 cited `build/hw3/timing-gate.log` for a 5-violation hold count that does not exist, because that build exited at the clock-plane gate and never ran the timing gate -- the count came from running the gate by hand -- and the citation and the sentence were both corrected before commit. `tools/memory_baseline.json` was updated for the intended EEPROM cell rename that the generate loop produced, and the active log was confirmed to need no correction for the `menu_ram` change, which the memory-placement gate cannot see at all because its baseline covers no `iosys` paths, recorded in TCL-070. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 85 was validated as the eighty-fifth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 85 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 168 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Four memory wrappers remain and each is now a bounded job: `mem_iwram` at 16 `SP`, `fb.v` at 38 `DPX9B`, and `vram_hi` then `vram_lo` at 16 and 32 `DPB`. Take `mem_iwram` next but settle its `BLKSEL` question first, since its sixteen instances share one `BLKSEL` across only eight distinct `BLK_SEL` values and the model's enable-by-match cannot be exactly right for that wrapper -- either widen the model's reading with a comment saying so, or convert `fb.v` before it, whose instances span the groups in a way that can be checked. Whatever the order, each conversion needs its own equivalence testbench in the shape of `tb_eeprom_equiv.sv` with at least two injected defects that must fail, and a hardware check afterwards, since simulation under a model of the primitive is not a substitute for the board. `tools/sweep_build_seeds.py` should be used rather than the hold-only sweep whenever a placement is being chosen, and a sweep should be launched detached. Two gate gaps recorded in TCL-070 are worth closing before the remaining conversions, because both would hide a memory change: the memory-placement baseline covers no `iosys` paths at all, so the `menu_ram` substitution was invisible to it, and the register-parity baseline is 946 flops out of date, so a real regression of that size could pass inside its 10 per cent budget. The eight unresolved sweep seeds were censored, not failed, and only a fresh sweep would give a failure rate; nothing here needs one. Finally, the three PLL wrappers remain out of scope and unchanged, and reading Gowin's EULA would still settle whether any of this conversion is required for distribution rather than merely desirable.

#### Files Modified:

- tools/memory_baseline.json
- tools/sweep_build_seeds.py

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 86 COMMIT Unreleased 2026-11-15T11:57:05-07:00

#### Coming From:

Unreleased 8c3e540

#### Purpose:

Replace the IWRAM memory wrapper with this project's own RTL, prove the substitution by simulation with injected defects, and confirm it on the board against the diagnostic suite that exists to test that region.

#### Outcome:

The third of six memory wrappers is converted and verified both in simulation and on hardware. `fpga/gba/src/memory/mem_iwram.v` is gone, replaced by `fpga/gba/src/memory/iwram_ram.v`, with the `.ipc` and `.mod` descriptors removed with it; thirteen Gowin-headed files remain in the tree of which six are built. The structure is worth recording because it is not what the instance count suggests and it retires a concern raised before the work started: sixteen `SP` blocks are not sixteen banks but eight banks of two halfword slices, since IWRAM is 32 bits wide and a block holds 16 at its widest, so instances 0 to 7 carry the low half of the word and 8 to 15 the high, which is why two instances always share a `BLK_SEL` value. TCL-069 had flagged this as a case where the simulation model's enable-by-match could not be right; it is right, and the reading that doubted it was wrong. The address splits three ways -- bits [12:10] are the bank and are what `BLKSEL` carries, bits [9:4] are the word address inside a block, and bits [1:0] are the byte write strobes which the vendor passes straight through as `byte_en[1:0]` and `byte_en[3:2]` -- and the bank select is registered on the launching edge gated by `ce & ~wre`, the same discipline `eeprom_ram` uses (TCL-072). Simulation compared both wrappers side by side over 20000 random cycles with freely chosen strobes plus a directed pass writing every bank at one offset and another sweeping all sixteen strobe combinations at one address: 20050 samples, no mismatch, and three injected defects each rejected -- bank register gated on `ce` alone gives 2874 mismatches, transposed halfwords 6100, and the high half's strobe driven from `byte_en[1:0]` 4949, none of which a cell census could see. `tools/sim/run_mem_equiv_tb.sh` was generalised to take a memory name or `all` and now carries both memories' defect lists. It also had to learn something: a converted wrapper's original is deleted from the tree, so the EEPROM comparison can no longer be re-run, and the script now says so rather than failing on a missing file -- and that claim was checked by extracting `mem_eeprom.v` from git history and running the same testbench against it, which still passes at 24018 samples. On the board, `build/iw3` was placed at seed 3, checked deployable by `tools/sweep_build_seeds.py`, and packaged; its routed netlist carried 66 `DPB`, 16 `SP`, 43 `DPX9B`, 125 block RAM and 66 distributed RAM, identical to the image with the Gowin wrapper, and the memory-placement gate reported only the intended rename of sixteen `sp_inst_N` cells to `bank_i[N].u_lo` and `.u_hi`. The RetroRegen GBA Test Suite v1.5 then reported `RESULT: ALL REGIONS PASS` with IWRAM 32K cells PASS, EWRAM 256K, VRAM 96K, PRAM 1K and OAM 1K all passing in 1377 ms -- the same verdict BRD-069 records for the pre-conversion core -- and Super Mario Advance 2 ran on the same image at 97455 distinct colours (BRD-098). Driving the suite's menu needed a correction: `tools/gba_input.py` opens `/dev/ttyUSB1` and is therefore a one-wire tool, unusable here, so the joystick frames were sent over `fpgapipe`; and the first attempt moved nothing because `BUTTONS` in that tool is a table of bit positions rather than masks, so `DOWN` is 5 and `A` is 8, and reconstructing the frame from a guessed layout produced a cursor that did not respond -- which reads exactly like a dead input path. Two smaller corrections were made before commit rather than after. TCL-072 had said the replacement was not verified on hardware, written before the board test, and it now records the test it received. And the earlier EEPROM comparison was re-established from git history so that the record of that conversion rests on something re-runnable rather than on a claim that it once passed. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 86 was validated as the eighty-sixth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 86 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 170 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Three wrappers remain: `fb.v` at 38 `DPX9B`, `vram_hi` at 16 `DPB` and `vram_lo` at 32 `DPB`. Take `fb.v` next. It is the one with no behavioural counterpart in the tree and it is 18 bits wide with no byte strobes, so it does not fit the pattern the other three followed and its testbench needs a stimulus that crosses its bank structure rather than one borrowed from the 32-bit memories; `tools/sim/gowin_bram_sim.v` already models `DPX9B` but that model has never been exercised, so validating it against `fb.v`'s own wiring is part of the job. The two VRAMs go last because they are the pair with a generic behavioural counterpart already in the tree and because they account for 48 of the remaining `DPB` on the GPU path, which is the most expensive place to be wrong. Each conversion should follow the shape now established: restate the vendor structure after reading its `DI`, `DO` and address wiring rather than counting instances, prove it in simulation against the original with at least two injected defects that must fail, confirm the primitive census is unchanged, then check on hardware -- for the VRAMs that means a retail cartridge and the screen test, not only the memory suite. Before the remaining work, the two gate gaps in TCL-070 should close, since both would hide exactly this kind of change: the memory-placement baseline covers no `iosys` paths and the register-parity baseline is 946 flops stale. Nothing about the persistence question has changed and BRD-094 still stands -- the store decays rather than clears, so persistence remains unmeasurable on this board -- and reading Gowin's EULA would still settle whether any of the conversion is required for distribution rather than desirable.

#### Files Modified:

- THIRD_PARTY.md
- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/memory/iwram_ram.v
- fpga/gba/src/memory/mem_iwram.ipc
- fpga/gba/src/memory/mem_iwram.mod
- fpga/gba/src/memory/mem_iwram.v
- tools/build_tinygba.sh
- tools/memory_baseline.json
- tools/sim/run_mem_equiv_tb.sh
- tools/sim/tb_iwram_equiv.sv

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 87 COMMIT Unreleased 2026-11-15T12:37:32-07:00

#### Coming From:

Unreleased 8b6a4ff

#### Purpose:

Replace the framebuffer wrapper, which is structurally unlike the three already converted, and remove the toolchain shim that existed only to serve it.

#### Outcome:

The fourth of six memory wrappers is converted and verified in simulation and on hardware. `fpga/gba/src/fb.v` -- 6327 lines, 38 `DPX9B`, 648 `MUX2`, 38 `LUT5` -- is gone, replaced by `fb_ram.v`, with its descriptors removed. Two structural facts made it unlike the others. Eighteen bits of data is two nine-bit slices, so each bank is a pair of blocks and 38400 words over 19 banks at 2048 words per block gives the 38. And `BLK_SEL_n` is only three bits wide, so it cannot name nineteen banks at all; the vendor therefore does not name them, and instead gives every instance the same `BLK_SEL = 3'b001` and its own one-hot decode of the bank field on `BLKSEL` bit 0, so a block acts when the two agree and exactly one bank acts at a time. That one-hot decode is what the 38 `LUT5` cells were for (TCL-073). Simulation compared both wrappers over 20000 random cycles on two independent clocks plus a directed pass over all nineteen banks, 24078 samples with no mismatch, and three injected defects were rejected: bank register gated on `ce` alone gives 5871 mismatches, transposed halves 2552, and a bank field cut to three bits so only eight banks are distinguishable 4485. That last one is the defect this memory is most exposed to and the one a census could never show. The simulation also caught a real fault in my first draft, which fed a single 27-bit concatenation into the 18-bit data port and so gave both slices the low nine bits: it built cleanly and would have drawn wrong colours. Removing `fb.v` then broke the build in a way worth recording, because it retired the last `LUT5` instantiation in the tree: `tools/build_tinygba.sh` strips `LUT5` from its cell-library shim and `tools/cells_behavioral.v` supplied a behavioural definition, and with nothing instantiating the cell so that both the strip and the definition still applied, yosys pulled in the real library copy and failed with `Re-definition of module 'LUT5'`. The fix is that both went, each with a comment saying the definition must return if a `LUT5` instantiation ever does; a shim kept for a consumer that no longer exists is not free, and the file's prose was corrected too since it still described supplying both primitives. On hardware both candidate seeds were deployable and the image was taken at seed 3: the routed netlist held 66 `DPB`, 16 `SP`, 43 `DPX9B`, 125 block RAM and 66 distributed RAM, identical to before the change, with the memory-placement gate reporting 38 `dpx9b_inst_N` cells becoming 38 `bank_i[N].u_lo`/`.u_hi` and the count unchanged, and once loaded Super Mario Advance 2 drew its world map correctly at 101838 distinct colours (BRD-099). Four of six wrappers are now verified on hardware: the OSD font for `menu_ram`, the save round trip for `eeprom_ram`, the diagnostic suite for `iwram_ram`, and a correct full-colour frame for `fb_ram`, which is the strongest of the four because a framebuffer fault is immediately visible rather than a wrong value. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 87 was validated as the eighty-seventh entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 87 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 172 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Two wrappers remain and they are the pair to do together: `vram_lo` at 16384 by 32 in 32 `DPB` and `vram_hi` at 8192 by 32 in 16 `DPB`, both with byte enables and both already carrying a generic behavioural counterpart under `ifdef VERILATOR`. They are 32-bit like `iwram_ram`, so the halfword split and the strobe handling can follow that conversion, but each has more than eight banks -- 16 for `vram_hi` and 32 for `vram_lo` -- which means the `BLK_SEL` width problem TCL-073 records applies to them too and must be read from their own wiring rather than assumed from `iwram_ram`'s indexed scheme. They go last because they are 48 of the remaining `DPB` on the GPU path every cartridge draws through, so the hardware check is the same one used here: a retail cartridge and a correct full-colour frame, not only the memory suite. Each needs its own testbench in the shape established, with at least two injected defects, one of which should be the `BLK_SEL` width failure. Before that work, and now overdue, the two gate gaps in TCL-070 should close: the memory-placement baseline covers no `iosys` paths and the register-parity baseline is 946 flops stale, so both would hide exactly this kind of change -- and this cycle showed the placement gate doing its job well for the three memories it can see, which makes the blind spot worse rather than better. Three PLL wrappers remain out of scope and unchanged. Nothing about the persistence question has changed: BRD-094 still stands, the store decays rather than clears, so persistence remains unmeasurable on this board.

#### Files Modified:

- THIRD_PARTY.md
- fpga/gba/src/fb.ipc
- fpga/gba/src/fb.mod
- fpga/gba/src/fb.v
- fpga/gba/src/fb_ram.v
- fpga/gba/src/gba2hdmi.sv
- tools/build_tinygba.sh
- tools/cells_behavioral.v
- tools/memory_baseline.json
- tools/sim/gowin_bram_sim.v
- tools/sim/run_mem_equiv_tb.sh
- tools/sim/tb_fb_equiv.sv

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 88 COMMIT Unreleased 2026-11-15T13:04:51-07:00

#### Coming From:

Unreleased 8c22d0b

#### Purpose:

Close the placement-gate gap that entry 87 called overdue, after establishing what the gap actually was rather than acting on the earlier diagnosis of it.

#### Outcome:

Neither placement gate was gating the configuration this project ships, and the earlier diagnosis of why was partly wrong. Both gates key on a configuration name derived from the `-DTINYGBA_*` defines; a production build defines none of them, so its key is `default`, and neither baseline file had a `default` entry -- the memory census held `TINYGBA_FETCHTRACE+TINYGBA_STALLTRACE` and `TINYGBA_OVERLAY_OFF`, and the parity baseline held `TINYGBA_OVERLAY_OFF` and `TINYGBA_STATUS_TEST`. Every production image this project has deployed was therefore never checked by either. TCL-070 had recorded this as an `iosys` coverage gap in the census tool, and that was wrong: the tool covers `iosys` correctly and finds `iosys.disp.menu_mem.u_menu` in a production netlist, and the reason no `iosys` path appeared was simply that the baseline being compared against had no production entry at all (TCL-074). The two gates also disagreed about what a missing baseline means, which is what made the gap silent: `synth_parity` returns 2 and the build prints `(no baseline for this configuration)` and continues, while `memory_census --check` returned 0, indistinguishable from a pass. Three baselines were recorded -- `default` at 12479 flops and 149 block RAM with a 124-array census, `TINYGBA_OVERLAY_OFF` corrected from 11471 flops and 156 block RAM to 12417 and 148, and `TINYGBA_STATUS_TEST` corrected from 9100 to 10004 flops -- and the staleness was worth finding on its own: `STATUS_TEST` had been passing at `+904 flops (+9.9%)` against a ten per cent budget, one tenth of a point from failing on changes that were entirely deliberate. `memory_census.py` now returns 2 for a missing baseline under `--check`, matching the parity gate's convention, and the build handles exit 2 as an informational warning exactly as it already did for gate 1b, with 1 still a failure. A production build now reports `change +0 flops` and `census matches the baseline for 'default'`, where before it was invisible to both, and an injected one-entry baseline change still returns 1 with a DIFFERS report, so the gate is live rather than merely present. The build's own comment had claimed that an ungated configuration was "reported and skipped rather than silently passing", which was not true and is now corrected to describe what happens and why diagnostics are exempt. Diagnostic configurations are deliberately still ungated, since there are twenty such defines and most are used once by hand; that is now stated in the warning and distinguishable by exit code rather than implied by a pass. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 88 was validated as the eighty-eighth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 88 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 173 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

The two VRAMs are the remaining conversions and are the same job: `vram_lo` at 16384 by 32 in 32 `DPB` and `vram_hi` at 8192 by 32 in 16 `DPB`, both with byte enables and both already carrying a generic behavioural counterpart under `ifdef VERILATOR`. Both are 32-bit like `iwram_ram`, so the halfword split and the strobe handling can follow that conversion, but both have more than eight banks -- 16 and 32 -- so the `BLK_SEL` width problem TCL-073 records applies to each and must be read from its own wiring rather than assumed from `iwram_ram`'s indexed scheme. Each needs its own testbench in the established shape with at least two injected defects, one of which should be the `BLK_SEL` width failure, and the hardware check is a retail cartridge and a correct full-colour frame rather than only the memory suite, since the VRAMs are 48 of the remaining `DPB` on the GPU path. The gate work in this cycle makes that safer than it would have been: a VRAM change now has a production baseline to move, so an unintended placement change in the shipped configuration will be caught, which it would not have been yesterday. Two things remain open and unchanged. The three PLL wrappers are out of scope and unbuilt copies of two of them sit in an unused `plla/` directory. And reading Gowin's EULA would still settle whether any of the wrapper conversion is required for distribution rather than merely desirable -- nothing in this cycle bears on that, and the persistence question is likewise untouched, since BRD-094's finding that the store decays rather than clears stands.

#### Files Modified:

- tools/build_tinygba.sh
- tools/memory_baseline.json
- tools/memory_census.py
- tools/synth_baseline.json

#### Status:

- Build: PASS
- Deployment: N/A
- User Test: N/A

---
## 89 COMMIT Unreleased 2026-11-15T13:44:28-07:00

#### Coming From:

Unreleased da86a46

#### Purpose:

Convert the two VRAM wrappers, which completes the memory-system replacement begun in entry 82, and verify them on the board.

#### Outcome:

All six memory wrappers are this project's own RTL and the machine passes every region on the board. `gpu/vram_hi.v` and `gpu/vram_lo.v` are gone, replaced by `vram_hi_ram.v` and `vram_lo_ram.v`, with their descriptors removed; ten Gowin-headed files remain of which three are built, and all three are PLL wrappers, so no memory in the shipped design is Gowin-generated. The two wrappers turned out to need different bank schemes, and neither could have been inferred from the other: `vram_hi` has sixteen blocks and uses the indexed scheme -- eight banks of two halfword slices, instances 0..7 carrying the low halfword and 8..15 the high, two instances sharing a `BLK_SEL` because they are the halves of one bank -- while `vram_lo` has thirty-two blocks in sixteen banks, more than the three bits of `BLK_SEL` can name, so like the framebuffer it gives every instance the same `BLK_SEL = 3'b001` and its own one-hot decode of the four-bit bank field on `BLKSEL` bit 0, which is what its 32 `LUT4` cells were for (TCL-075, TCL-076). The settling test is `BLK_SEL_0` rather than the instance count: `iwram_ram` and `vram_hi` both have sixteen instances and both are indexed, while `vram_lo` has thirty-two and is one-hot. Both are dual-port with independent clocks, so each port's bank select is registered on its own clock and gated by that port's `~wre & ce`; a single shared register would be wrong whenever the two clocks are unrelated, which they are by construction here. Each was proved separately in simulation against its original with three injected defects that must fail -- for `vram_hi` the bank register gated on `ce` alone gives 5078 mismatches, transposed halves 8891, and the high halfword's strobe driven from `byte_en[1:0]` 7845; for `vram_lo` the same three give 4545, 5121 and 7459, the last being a bank field cut to three bits so banks 8..15 alias onto 0..7. The strobe-split defect is worth naming because a first draft of `vram_hi_ram` had exactly it: sending one strobe pair to both halves builds cleanly and writes the wrong bytes in the upper halfword, and no cell count moves. On hardware both candidate seeds were deployable at zero hold, the routed netlist held 67 `DPB`, 16 `SP` and 43 `DPX9B` unchanged with `change +0 flops` and exactly 96 changed census paths -- 48 removed, 48 added -- and the RetroRegen suite reported `RESULT: ALL REGIONS PASS` with VRAM 96K cells PASS and its decoder PASS in 1377 ms, the same figure as BRD-069 and BRD-098, and Super Mario Advance 2 drew its world map at 89735 distinct colours on the same image (BRD-100). Two mistakes of my own cost time. A build was launched with a stray `-DTINYGBA_BOOTTRACE_TYPO=0` define in the list, which would have polluted the configuration key every gate uses, and had to be killed and re-run; and on the way to `vram_lo` I had recorded intending to read its wiring rather than assume `iwram_ram`'s scheme, which was right, and then the first reading of it was still tentative until `BLK_SEL_0` was checked and found to be a single repeated value. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 89 was validated as the eighty-ninth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 89 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 176 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

The memory-system work is finished, so what remains is a scope question rather than a task. Three PLL wrappers -- `pll/pll_12.v`, `pll/pll_27.v` and `pll/pll_33.v` -- are still Gowin-generated and still built, and they are now the only vendor-generated RTL in the design. Replacing them is not the same job as the memories: `pll_33`'s operating point at FVCO 1809 MHz sits outside apicula's charge-pump model, which is why a Gowin EDA oracle run was needed to measure it in the first place, so a hand-written replacement means either finding an in-band plan or restating the parameters the oracle produced, and `pll_16.v` and `gowin_pll_hdmi.v` are the precedent for how that is written. Six files in an unused `plla/` directory are duplicates of unbuilt wrappers and could simply be deleted whenever the tree is next tidied, which removes six of the ten remaining Gowin-headed files at no risk. Two questions stand open and neither is advanced by more conversion work: whether Gowin's terms permit redistributing IP-generator output, which reading the EULA would settle and which has now been deferred through eight cycles, and whether persistence is testable at all on this board, which BRD-094 answered in the negative because the store decays rather than clears. The two diagnostic configurations without memory baselines, and the twenty diagnostic defines generally, remain deliberately ungated; if a VRAM regression confined to `TINYGBA_PIXTEST` or `TINYGBA_SDRAM_TEST` mattered, the fix is a diagnostic build plus a baseline update, which is now a cheap and well-understood act.

#### Files Modified:

- THIRD_PARTY.md
- fpga/gba/src/gpu/gba_gpu_drawer.v
- fpga/gba/src/gpu/vram_hi.ipc
- fpga/gba/src/gpu/vram_hi.mod
- fpga/gba/src/gpu/vram_hi.v
- fpga/gba/src/gpu/vram_hi_ram.v
- fpga/gba/src/gpu/vram_lo.ipc
- fpga/gba/src/gpu/vram_lo.mod
- fpga/gba/src/gpu/vram_lo.v
- fpga/gba/src/gpu/vram_lo_ram.v
- tools/build_tinygba.sh
- tools/memory_baseline.json
- tools/sim/run_mem_equiv_tb.sh
- tools/sim/tb_vram_hi_equiv.sv
- tools/sim/tb_vram_lo_equiv.sv

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 90 COMMIT Unreleased 2026-11-15T13:54:16-07:00

#### Coming From:

Unreleased 435435e

#### Purpose:

Attempt to read Gowin's EULA, which eight cycles of records have named as the action that would settle whether redistributing its IP-generator output is permitted.

#### Outcome:

The attempt did not settle the question, and what it established is that the question cannot be settled from this workspace. There is no Gowin EDA installation on this machine: a filesystem search for a licence file under any path containing `owin` returns nothing, and no `/opt`, `/usr/local` or home-directory Gowin tree exists, which is consistent with TCL-065's finding that the vendor flow was run once as an offline oracle under a setup whose licence acceptance is not reproducible from this tree. The public licence page at `https://www.gowinsemi.com/en/support/license/` was fetched and returns HTTP 200 with 142,556 bytes, but its extracted text is an application form rather than terms: it is headed `Apply License` and offers `Register / Member Login`, and it contains thirteen occurrences of `license`, none of `EULA`, none of `redistribut` and none of `generated`. It is a page for requesting a licence to use the EDA, not a document granting or restricting redistribution of what the EDA emits. Three further candidate URLs were probed and returned no usable content before the attempt was stopped at the operator's instruction. So the terms are behind a registration wall (TCL-077). That makes the standing recommendation, which has appeared in every entry's Next Steps since entry 80, an action this agent cannot take, and it should stop being carried forward as though it were a cheap next step. What remains true without the document is what TCL-065 established: the sixteen original Gowin-headed files carried `All rights reserved` with no grant, the six memory wrappers have since been replaced so no memory in the shipped design is vendor-generated, and three PLL wrappers remain. What cannot be said is whether redistributing those three is permitted, and this entry does not assert either a permission or a prohibition. The practical position is sharper than before rather than fuzzier: the conversion work already done removed the question for the entire memory system, and replacing the three PLL wrappers would remove it completely, whereas confirming the licence would leave the files in place. No source, build script or tool was changed in this cycle. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 90 was validated as the ninetieth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 90 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 177 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Whoever can obtain the EULA -- meaning whoever holds or can create a Gowin account and accept the EDA licence -- should read it and record what it says, because an agent should neither guess at it nor assert a permission or a prohibition it has not read. Short of that, the three remaining PLL wrappers are the only vendor-generated RTL in the shipped design, and replacing them is a known-shaped job with a precedent: `pll_16.v` and `gowin_pll_hdmi.v` are hand-written already, and `pll_33`'s FVCO 1809 MHz operating point sits outside apicula's charge-pump model, so a replacement means either finding an in-band plan or restating the parameters the Gowin EDA oracle produced, which TCL-002 records. Six files in the unused `plla/` directory are duplicates of unbuilt wrappers and could be deleted at zero risk whenever the tree is next tidied, removing six of the ten remaining Gowin-headed files. A further question this cycle did not touch is whether distributing a bitstream built from this tree differs from distributing its source, which is a separate matter from what the EULA says about the emitted files. Nothing about the machine changed: the memory-system conversion finished in entry 89 with all six wrappers this project's own RTL and the diagnostic suite passing every region, and BRD-094's finding that the save store decays rather than clears still stands.

#### Files Modified:

- None.

#### Status:

- Build: N/A
- Deployment: N/A
- User Test: N/A

---
## 91 COMMIT Unreleased 2026-11-15T14:06:54-07:00

#### Coming From:

Unreleased a25da1c

#### Purpose:

Record the answer to the licensing question that entries 80 to 90 carried open, after another agent obtained Gowin's End User Licence Agreement and the clauses were checked directly against its text.

#### Outcome:

The redistribution question is answered, and the answer is that the thirteen Gowin-headed files may be kept and redistributed with their headers intact. Entry 90 had concluded that the terms were behind a registration wall and could not be read from this workspace; that was true of the routes tried there and false in general, and the document was obtained by another agent through a path not reproduced here. The clauses were then verified against the extracted text by hand rather than accepted on the other agent's summary, and their reading holds. The agreement's operative word is `Software`, defined in §1(1) as "the computer program(s) furnished to you by Gowin"; a file the tools emit is not one of those programs, so it is not `Software` and §3's prohibitions do not reach it -- and all seven of them bind the Software explicitly, including the two that matter here, not reverse engineering *the Software* and not publishing benchmarks *of the Software*. §4 vests ownership of "the Software and all copies thereof" in Gowin and claims nothing about designs or generated files. §5(4) goes the other way and treats output as the user's: after termination "you are not required to destroy output data which you obtained using the Software ... and may continue to use it". §2 limits the Software to designing "only for Gowin Devices", which this project satisfies with its GW5AST target. A search of Gowin's own clauses for `distribut`, `transfer` and `sublicens` returns four hits, every one about the Software and none about output, so the agreement neither permits nor forbids redistributing generated files -- it simply does not address them (TCL-078). Two further points came out of the reading that the earlier cycles had wrong or missed. §4 requires that Gowin's "trademark, copyright notice and logo" not be deleted or modified, which means the headers must stay exactly as generated and confirms that the twelve replaced files could not have been relabelled into compliance -- replacing rather than relicensing was the only sound treatment, which TCL-065 had concluded for a different reason. And the two grey areas named during the reading are narrower than they look but not empty: §3(1)'s ban on reverse engineering applies to the Software, while reading PLL settings out of a bitstream examines output that §5(4) expressly permits continued use of, so the `gowin_unpack` readback TCL-002 relied on is not that prohibition; but §3(3) forbids publishing benchmarking results of the Software *or using such results for any other software development activities*, which is broad enough that a vendor-versus-open-flow performance comparison would be uncomfortable to publish, and the tree was checked and publishes no such comparison, so the risk is prospective rather than present. Three limits are recorded with the finding: it is a reading and not legal advice; it is the 2026.03 text while the files in this tree were generated in 2024 under an earlier version that was not available, so the 2024 terms are assumed rather than read; and the extracted text's authenticity rests on its content and its Arm licence appendices rather than on a verified download, which is stated in the record rather than glossed. `THIRD_PARTY.md` now carries the substance in place of the sentence saying the EULA had not been established, and TCL-077 is annotated as superseded rather than rewritten. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 91 was validated as the ninety-first entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 91 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 178 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Nothing in the code follows from this, which is the useful part: the conversion work was done for provenance and clarity rather than because the licence required it, and that is now on the record instead of being assumed. The three PLL wrappers may stay, with their headers intact, and the six duplicate files in the unused `plla/` directory may be deleted at any time as ordinary tidying. Two things remain worth doing and neither is urgent. If the 2024 version of the agreement can be obtained, it should be read against the 2026.03 one, because that is the version that governed the generation of the files in this tree and this record assumes rather than reads it; and the extracted text should be retained or cited more durably than a scratch directory if the project intends to rely on it, since a record that depends on a temporary path is one cleanup away from being unverifiable. On the machine itself the work stands where entry 89 left it: all six memory wrappers are this project's own RTL, the diagnostic suite passes every region on the board, and the persistence question remains answered negatively by BRD-094, whose finding that the save store decays rather than clears has not changed.

#### Files Modified:

- THIRD_PARTY.md

#### Status:

- Build: N/A
- Deployment: N/A
- User Test: N/A

---
## 92 COMMIT Unreleased 2026-11-15T14:27:47-07:00

#### Coming From:

Unreleased c4f2df4

#### Purpose:

Find out whether a cartridge can actually write its own save on the board, which every earlier save record tested only through the host's transport path and none tested through the path a game uses.

#### Outcome:

It cannot, and that is the finding. A new probe, `tools/roms/saveprobe.s`, writes a known pattern through the cartridge SRAM window at `0x0E000000` as a game would and paints two squares: whether the canonical pattern was already present when it started, and whether writing a *different* pattern and reading it back succeeded. Under mGBA 0.10.5 both squares are green with mGBA's own `.sav` in place, so the probe is sound. On the board, with `gbaload` reporting `save hardware = SRAM` and `save restored, 32768 bytes of SRAM`, the first square is green and the second is red: the CPU reads the SRAM window correctly, finding the 32768-byte pattern the host had just restored, but a pattern the CPU wrote itself is not there when it reads it back. Writes to the cartridge SRAM window are silently dropped while reads from it work (BRD-101). That is the first evidence that separates a game-written save from transport, because BRD-092 proved the host could move bytes through the RISC-V port, which never consults `gba_memory`'s write gate at all, and nothing had tested the path a cartridge uses. The consequence is larger than one probe: no cartridge with an SRAM save has ever been able to save on this board, and the four SRAM titles in the sweep -- Metroid Fusion, Metroid Zero Mission, Castlevania and Fire Emblem -- boot and play while silently failing to persist, which is why it went unnoticed, since a dropped SRAM write is invisible unless something reads it back. The leading hypothesis, not yet confirmed, is `gba_memory.sv`'s `isreadonly()` gate: for regions `0x0E` and `0x0F` it forces `sdram_wr = 0` and `sdram_rd = 1` unless `config_backup_type` is flash512K, flash1M or SRAM, so a wrong `config_backup_type` would turn every CPU write into a read that returns the old contents -- exactly what the probe sees, and invisible to the host restore path for the same reason. The alternative is that the write reaches SDRAM and the read returns a buffered value, which the same evidence also fits. One diagnostic build forcing `isreadonly(0x0E)` false would separate them. The probe itself had a defect found the hard way and fixed before either result was recorded: its first version tested the write by writing the canonical pattern and reading it back, which goes green whenever the window already holds that pattern -- and on the second board run, after a restore, both squares went green for exactly that reason. It now writes a pattern differing by one, and both the mGBA pass and the board failure were re-taken with that version. Two operational notes are recorded because they cost time: `pkill -f mgba-qt` matches the invoker's own command line and kills the calling shell, so processes are stopped with `pkill -x`; and an early capture grabbed the whole X root window rather than mGBA's window, which was the operator's desktop and not this work's to read, so captures are now taken with `import -window <id>` against the mGBA window only. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 92 was validated as the ninety-second entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 92 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 179 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary.

#### Next Steps:

Settle the hypothesis before anything else, because everything about battery saves depends on it: build one diagnostic image on a scratch tree with `isreadonly(0x0E)` forced false, load `saveprobe`, and read the two squares. If the second turns green the write gate was the fault and the fix is to establish why `config_backup_type` is not `BACKUP_SRAM` at the moment the CPU runs -- the loader sends stage 3 and `gbaload` prints the type it sent, so the question is whether the core received it, and the way to answer that is to have the probe report `config_backup_type` through the status band or an MMIO word rather than by inference. If it stays red, the fault is downstream in the SDRAM write path and the place to look is `sdram_gba`'s byte-write handling for the cart-RAM area, where `hi = !cpu_be[1:0]` and `cpu_ready <= cpu_be[3:2] == 0 | cpu_be[1:0] == 0` decide how a single-lane byte write is issued. Either outcome should be recorded as the next entry, and once a CPU write lands, the full chain becomes testable in the order it should be: probe writes, `gbasave`, power cycle, `gbaload` with the `.sav`, probe reports the pattern came back -- and unlike the EEPROM that BRD-094 found decays rather than clears, SRAM lives in SDRAM and a power cycle should genuinely clear it, so a real negative control is available here for the first time. Only after that is automatic capture worth building, since an auto-save that dumps a window the CPU cannot write would preserve nothing. Nothing about the six converted memory wrappers is implicated: the diagnostic suite still passes every region, and this is the CPU write gate rather than the storage.

#### Files Modified:

- tools/roms/saveprobe.s

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 93 COMMIT Unreleased 2026-11-15T15:27:16-07:00

#### Coming From:

Unreleased 6c1f5d8

#### Purpose:

Settle the two causes entry 92 left open -- whether the CPU's store to the cartridge SRAM window is dropped or merely read back stale, and whether `gba_memory.sv`'s `isreadonly()` gate is the reason -- so that the fix targets the right module.

#### Outcome:

Both questions are answered, and the answer is not the one entry 92 leaned toward. The store never lands at all, and the gate is not the cause.

The first question was settled by reading the window through the *host* instead of the CPU, since the RISC-V port does not share the CPU's read timing and so cannot inherit a stale-read artefact. With the save planted as 32768 zero bytes -- a pattern the probe never writes -- the probe ran, and `gbasave` returned 32768 bytes identical to the planted file, differing from the canonical pattern in 32640 places. The window is therefore byte-for-byte unchanged: the store is absent from SDRAM, not merely hidden from the CPU by a buffer. That measurement invalidated an earlier attempt at the same test in this session, which planted the *old* save containing the canonical pattern and then reported that the dump matched it; `gbaload`'s own "restoring 32768 bytes of SRAM" line is what exposed the confound, because the host restored the pattern the dump was being compared against, and the run proved nothing. The zeros substitution is what makes the comparison mean something (BRD-102).

The second question was settled by a diagnostic build. A new `TINYGBA_SRAM_WR_DIAG` define makes `isreadonly()` return 0 for regions `0x0E` and `0x0F` and changes nothing else; it is an `ifdef` with no default so no existing image is touched, and the build script's configuration key gives it its own gate baselines. On that image, with the capture card working and the production image reproducing the failure first as a control (both squares red with zeros planted, sq0 `(226,0,0)`, sq1 `(226,0,0)`), the diagnostic build gives square 0 GREEN `(18,255,0)` and square 1 RED `(226,0,0)` when the *canonical* pattern is planted. Square 0 green is the load-bearing part: it proves the CPU's read of the window returns the host-restored data on this image, so the probe ran, the read path works, and a red square 1 is specifically a failed write rather than a machine that never executed. With the gate forced open and reads demonstrably working, the write is still lost -- and a host dump taken 20 seconds after load, long past the fill, is still all zeros. `isreadonly()` is therefore exonerated: the fault is below it, in the SDRAM controller's CPU write path (BRD-103).

Two corrections belong in this entry rather than being quietly dropped. The commit message for 6c1f5d8 states that the diagnostic image's HDMI is dark and attributes that to the clock-plane gate placing `clk16` and `clk50` on unmeasured pips; that attribution was wrong. The capture card itself had stopped producing frames -- it was showing its own "GUERMOOK No Video" slate, which is a card-side message and not a core output -- and the same dark screen appeared for the production image that had worked forty minutes earlier, which is what made the clock-plane reading untenable. Once the card was back, the production image reproduced the failure and the diagnostic image ran normally, so no clock-plane conclusion was ever warranted and none is drawn. The other is a timing observation recorded as an observation only: on the diagnostic build the probe's 32768-byte fill took longer than three seconds and was complete within eight, where on the production image the same fill completed inside three; with the gate open each byte is a real store rather than a discarded one, so this is consistent with the gate having been shut in production, but it is a wall-clock difference on two separately placed images and nothing is concluded from it. Two limits are recorded: the timing question above is open, and the probe halts after its fill, so nothing in this cycle distinguishes "the store was never issued" from "the store was issued and discarded below the gate" -- both are below `isreadonly()` and both live in `sdram_gba`.

#### Next Steps:

The place to look is now narrow and named. `sdram_gba`'s CPU write path decides a store with `hi = !cpu_be[1:0]`, issues `SDRAM_DQM <= ~ds_latch[p][3:2]` or `~ds_latch[p][1:0]` depending on that bit, and selects the byte lanes from `ds_latch`, while `cpu_ready <= cpu_be[3:2] == 0 | cpu_be[1:0] == 0` decides when the CPU may proceed; and `gba_memory` forces a single byte lane for the whole `0x0E` window with `sdram_be = 4'b1 << ram_addr[1:0]` whenever `ram_addr[27:25] == 3'b111`, which is correct for a `strb` and wrong for a halfword or word store to SRAM -- that is a real defect, but not this one, because the probe writes bytes and for a byte the CPU's own `ram_be` is already that same one-hot value. The cheapest discriminating experiment is an extension of the probe rather than another place-and-route run: have it write a byte and a word at known offsets, read each back immediately, and paint one square per case, so that "nothing written" and "written to the wrong lane or wrong offset" separate on screen in one load. A word write that lands while byte writes do not would point at the lane logic; neither landing would point at the request never reaching the controller. Doing that in the ROM costs an assembly and an `objcopy`, not a twenty-minute build, and it should be run on the production image first so the failing configuration is the one being measured. Only after a store lands does the full chain entry 92 named become testable -- probe writes, `gbasave`, power cycle, `gbaload`, pattern returns -- with the genuine negative control that SRAM in SDRAM finally allows. The board was left running the diagnostic image with a zero-filled save planted, so the production image should be restored before any operator use.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: PASS

---
## 94 COMMIT Unreleased 2026-11-15T15:43:21-07:00

#### Coming From:

Unreleased 199ab1d

#### Purpose:

Record the probe-tooling work committed in 199ab1d, which entry 93 did not cover, and correct an inaccuracy in the record it introduced.

#### Outcome:

Two defects in how this project builds the probe ROMs it draws conclusions from were found and fixed, and both were found the hard way.

The first is that the binary behind two board records had no build recipe. `build/test/saveprobe.gba` is the image that produced BRD-101 and BRD-103, and reproducing it from `tools/roms/saveprobe.s` took three guesses -- the pad length, the header complement, and whether the assembler target mattered -- with the first two producing a file differing at byte 0xBD. `tools/make_probe_bin.py` now assembles a `.s` into a padded image, asserts the fixed 0x96 at 0xB2 and computes the header complement, and it reproduces that local file byte for byte. The correction this entry exists to make is that the earlier text called that file "committed"; it was never committed, because `build/` is gitignored from line 1 of `.gitignore` and no `.gba` is tracked anywhere in the tree. So the check is against a scratch artifact that happens to be the one the board results came from, which is a real but weaker provenance than the record claimed, and TCL-080 now says so rather than leaving the stronger claim standing (TCL-080).

The second is more dangerous and is the reason the tooling is worth a commit of its own. The GNU assembler accepts some instructions it only warns about and encodes them anyway: `mul r8, r9, r8` has Rd equal to Rm, which ARM7TDMI leaves UNPREDICTABLE, and `as` assembled it with the message `Rd and Rm should be different in mul` and exit status zero. The probe built from it drew nine status squares and nine bit strips in exactly the right places, in exactly the right colours, and reported garbage values for stores that a one-case ROM wrote and read back correctly. That is the worst shape a measurement fault can take: not a crash, not an empty screen, but a plausible instrument reporting a failing machine. `make_probe_bin.py` now assembles with `--fatal-warnings`, so this class of mistake stops the build. One limit is recorded with the finding: `tools/roms/savewprobe.s`, the nine-case width and lane probe written during this work, assembles cleanly under the new rule and is still wrong -- it reports red for stores to EWRAM that a one-case ROM in `saveprobe.s`'s idiom reports green for -- so it is committed marked NOT VALIDATED, it has not been run on the board, and no result has been taken from it. The banner in that file records what was ruled out so the next pass does not repeat it: the addressing (the literal pool was read out of the built image byte by byte and holds `0x020100`, `0x020101` and so on), the store and load encodings (disassembled and correct), the `mul` fault (fixed, and the result did not change), and the VRAM clear (removed, and the result did not change). What remains different between the working one-case ROM and the failing nine-case one is the `status` call and the sequence of cases, which is where the next pass should look. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 94 was validated as the ninety-fourth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 94 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 183 records with no duplicate ids, every record in canonical field order, and every status inside the three-value vocabulary. A discipline fault is also recorded: TCL-080 was appended in 199ab1d without a log entry of its own, which is what this entry repairs, and it should not have taken the operator asking for a commit to surface it.

#### Next Steps:

Nothing on the machine changes from this. The place to look for the dropped SRAM store remains `sdram_gba`'s CPU write path, since BRD-103 exonerated `isreadonly()`, and the cheapest instrument for that is a probe whose results can be trusted. The first task is therefore to finish `savewprobe.s`: reduce it to the one-case shape that is known to work, confirm green, then add cases back one at a time until it breaks, which localises the fault in the probe in a handful of four-kilobyte builds rather than a synthesis run. Only then is a width-and-lane result worth taking to the board, and only after that does the twenty-minute place-and-route cycle on the controller make sense. Two smaller things follow from this entry. The `gba_memory` single-byte-lane behaviour for the whole `0x0E` window is a real defect for halfword and word stores and should be fixed on its own merits, with the note that it cannot explain the byte-store failure being chased. And if probe binaries are going to keep being the evidence for board claims, the question of whether a specific probe image should be tracked in the repository -- small, and the thing that makes a result reproducible later -- is one for the operator rather than for another silent decision.

#### Files Modified:

- tools/make_probe_bin.py
- tools/roms/savewprobe.s

#### Status:

- Build: PASS
- Deployment: N/A
- User Test: N/A

---
## 95 COMMIT Unreleased 2026-11-15T17:25:47-07:00

#### Coming From:

Unreleased 4bd7383

#### Purpose:

Record the simulation-harness repairs made after the operator observed that every simulation in this session had been running the free BIOS while every board result used the retail one, and record honestly that the controller-side tracing that followed produced no trustworthy answer before the cycle was stopped.

#### Outcome:

Three faults were found in how this project's simulation is run and instrumented. Two were repaired and one was rolled back, and the honest summary is that the cycle consumed a great deal of effort without locating the dropped store. The first fault was the operator's observation. `tools/sim/build_gba_sim.sh` never set `TINYGBA_BIOS_HEX`, so `gba_memory.sv` fell back to the vendored cult-of-gba image, while every board result in this repository was taken with the retail BIOS that `tools/build_tinygba.sh` passes explicitly. Every simulation run in this session was therefore a different machine from the one on the bench and none of it was comparable. The harness now resolves the retail image to an absolute path and refuses to build without it, printing why; `TINYGBA_SIM_BIOS=cultofgba` is the explicit opt-out and announces that results will not be comparable. A stale copy of the free image is no longer left in the run directory, which is how one could outlive a change to the script (TCL-081). The second fault was that the SDL window is the model's control panel: SPACE pauses the simulation and ESC quits it, and the window sits on the operator's desktop. A trace run came back with every stage at zero because the simulation had been stopped by a SPACE at `sim_time=864300`, which in the log is indistinguishable from "the CPU never issued the store". A `-headless` flag and `TINYGBA_SIM_HEADLESS` environment variable now build no window at all: frames still count and dump to PPM, every `$display` still prints, and nothing outside the model can pause, resume or quit the run. The source list had also rotted -- it still named `mem_eeprom.v`, deleted in the wrapper conversion, and lacked `rv_sdram_adapter.v` -- so the harness could not elaborate the current top at all; both are fixed and `TINYGBA_SDRAM_RTL` now builds and runs against the real controller for the first time since that conversion (TCL-081). The third fault was mine and is the substance of this entry. Six staged traces were added to `gba_memory` and `sdram_gba` to find where the store dies, and they produced three successive false readings. Verilog precedence was the first: `a == b & c < d` parses as `a == (b & (c < d))` because `==` and `<` bind tighter than `&`, so several trace conditions were silently comparing the wrong operands. Second, `cpu_addr` does not hold a byte address in this design -- `tosdram` packs the region into the top bits and the cartridge window arrives as `0x810000` -- so an address slice taken from the wrong field never matched, and having "corrected" it once I broke a filter that had been working. Third, the counters were capped at a handful of prints and the loader's 128 KB fill of the same window consumed the entire budget before the CPU ever ran, so the interesting events were never reached. Each of these was found only after the previous reading had been believed, and no result from the staged traces is trustworthy. They were removed rather than debugged a fourth time, with the reasons left in the source (BRD-104). What does survive, because independent traces agreed and neither contradicted itself: the CPU's store to `0x0E000000` arrives at `gba_memory` with the probe's own data and `be=0001`, `isreadonly` evaluates false, and `gba_memory` forms a correct SDRAM write for it -- `wr=1, addr=810000`, byte lane correct. That is consistent with BRD-102 and BRD-103 and adds the one thing they did not have: the request as formed, above the controller. Whether `sdram_gba` consumes it is explicitly open and no claim is made about it in any record. Three things are recorded as unresolved rather than tidied away. The retail BIOS boots far slower in simulation than the free one -- 59 frames to reach the probe against 12 -- so each measurement attempt costs about five minutes of wall clock, which is why the cycle ran long. A final experiment that would have been the cheapest possible check -- dumping frames from the headless simulation to see whether the probe's squares are red or green in the model, which is a direct observation rather than an inference from counters -- was launched and then stopped with the cycle, so it has not been run. And the deeper problem is now clear: the probe infrastructure, not the RTL, is where this hunt has been losing time, and a simulation that draws the squares would settle in one run what a day of counters did not. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01` with the complete `.ai/` diff inspected and confirmed to be additions only, entry 95 was validated as the ninety-fifth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, and the active log was confirmed at 95 entries against the 100-entry limit with no gaps in its numbering, while the reference store was confirmed at 185 records with no duplicate ids, every record in canonical field order and every status inside the three-value vocabulary. Two conformance failures were found and corrected here rather than left standing: entry 95's own changes had been committed in two separate commits before this entry existed, which breaks the rule that an entry belongs to the same commit as the changes it describes, and those commits were squashed into one for that reason; and entry 94 listed `.ai/core-reference.md` under Files Modified, which the syntax rules prohibit, so that line was removed as the mechanical correction those rules allow, with this entry as the explanation they require. A repeat discipline failure is also recorded: entries 94 and 95 both exist because engineering commits were made without their log entry, which is the third time in this session that the log lagged the code.

#### Next Steps:

The first thing to do is the experiment that was stopped: run the probe under `-headless` with `-p` and read the two squares from the dumped PPM. That is a direct measurement of the model's behaviour with no instrumentation to be wrong about, and it either reproduces the board's red square in simulation -- which puts the fault in RTL and makes waveforms usable -- or shows green, which puts the fault in something the board has and the model does not, and the candidates named in entry 92's Next Steps become the short list again. Ten minutes, not a day. Before any further tracing, the instrument must be validated against a known event, which is the standard TCL-041 and TCL-080 already set for probes: a counter that reports zero has to be shown capable of reporting non-zero before its silence means anything. Specifically, a trace of an EWRAM store -- which every game performs constantly and which is known to work -- should print from the same code path as the cartridge-window trace; if it does not, the trace is broken and its silence about `0x0E` says nothing. The board is left on the production image with the canonical save planted, and the last deployed diagnostic image is `build/sdiag3/tinygba.bin`, whose gate-open result BRD-103 records. Nothing about the six converted memory wrappers is implicated and the diagnostic suite was not re-run this cycle.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/memory/sdram_gba.v
- tools/sim/build_gba_sim.sh
- tools/sim/sim_main.cpp

#### Status:

- Build: PASS
- Deployment: N/A
- User Test: N/A

---

## 96 COMMIT Unreleased 2026-11-15T22:25:19-07:00

#### Coming From:

Unreleased 64c42ce

#### Purpose:

Find why a CPU store to the cartridge SRAM window is lost, by getting the simulation to reproduce the board's red square and then tracing the store to the pins.

#### Outcome:

The simulation now reproduces the board's failure and the first cause is found and fixed, but the fault is not yet cleared. The reproduction is the cycle's main result: with `-DTINYGBA_SDRAM_RTL` and the retail BIOS, `saveprobe` runs to 155,443,407 cartridge fetch cycles with 63,261,975 halted (25.3%), renders exactly 512 nonzero pixels, and paints BOTH squares red `(252,0,0)`. Square 0 red is correct behaviour in the model because no save is planted, and square 1 red is `verify_alt` reporting mismatches -- the same signature BRD-103 recorded on hardware. That settles the fork entry 95 left open: the fault is in RTL and the model is a usable instrument for it. Tracing the store to the pin-level part (`fpga/gba/diag/sdram_model.v`, whose WR/RD command decode already existed but had no way to be turned on selectively) showed the store never arriving as an SDRAM write at all: the run issued 4,096 WR commands, all from the loader's fill, while `sdram_gba`'s flash path consumed the probe's own data 65,480 times -- `flash write: 0000 1 08`, `0001 2 27`, `0002 4 46`, `0003 8 65`, which is the probe's alternative pattern `(i*31+8) & 0xFF` byte for byte across its two 32 KiB fills. The cause is a truncated signal, not a sequencer defect. `config_backup_type` is driven by `gba_memory` as a 3-bit value but was never declared in `gbatang_top.sv`, so Verilog gave it an implicit one-bit net and every consumer saw only bit 0: SRAM `3'b011` reached `sdram_gba` as `3'b001`, which is FLASH512K. `is_flash` therefore evaluated true, and because `tosdram` maps the whole cartridge-RAM window to `10'h204` the flash gate opened on every CPU store, the flash interpreter found no matching opcode at `f_addr` 0 and discarded the byte, and the store vanished while `cpu_ready` was still raised so the CPU believed it had succeeded. That is exactly the silent drop BRD-101 describes. The truncation is visible in the generated model as `bufp->chgBit(...)` against a 3-bit `chgCData` port, and was then confirmed at runtime rather than by inspection: a temporary `FLASHGATE` print in the broken build reports `cfg=1 is_flash=1` while the loader's own line reports `backup type=  3`. The fix is one declaration, `wire [2:0] config_backup_type;` in `gbatang_top.sv`; after it the same run issues zero flash writes against 65,480 before, and the one-bit trace line is gone from the generated model. The probe result did not change: square 1 is still red, so a second cause remains below this one and the store still does not persist. Three instrument faults in this cycle are recorded because each produced a wrong reading first. A controller binary 11 minutes older than `gba_memory.sv` was run and produced 61,853 flash writes that I briefly read as a design alarm; rebuilt from HEAD the same run was correct, which is the stale-binary trap again. I then reported zero flash writes for a run I had grepped in its first seconds, when its final count was 65,536 -- the same premature-measurement error entry 95 records. And the first selective pin trace flooded with 2.9 million `cs deasserted` lines because that print was gated on `TRACE` rather than `TRACE > 1`, hiding the writes it existed to reveal; the model now takes 0 silent, 1 writes only, 2 every command. A separate observation is recorded without conclusion: the behavioural-array build, rebuilt from the same tree, no longer boots any cartridge (0 cartridge fetches, 87.4 to 93.5% halted, white screen) while the controller build boots normally, which inverts the historical relationship between those two configurations and makes the array unusable as a control until it is explained. Two files left over from the previous session, `tools/roms/saveprobe_iw.s` and `tools/save/pipe_save_dump.py`, remain untracked and unvalidated; `gba.aud`, the simulation's audio dump, is now ignored as the generated artifact it is. No bitstream was built and nothing was deployed, so no hardware result exists for this cycle. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 96 was validated as the ninety-sixth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 96 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 186 records with no duplicate ids, every record in canonical field order and every status inside the three-value vocabulary.

#### Next Steps:

Find the second cause, because the truncation fix alone does not make the store persist: square 1 is still red with zero flash writes, so the request now goes somewhere else and is still lost. The instrument for it already exists and should be used before any new trace is written -- rebuild with `-DTINYGBA_SDRAM_RTL -DTINYGBA_SDRAM_PINTRACE` and confirm whether the probe's byte stores now appear as WR commands at the pins with the right DQM and address, which the run that would have answered it was stopped before reaching. If they appear, the fault is in the read-back or in `gba_memory`'s assembly of `cpu_rdata`; if they still do not, it is still in `sdram_gba`'s CPU write path, and BRD-103's note that `gba_memory` forces a single byte lane across the whole `0x0E` window -- `sdram_be = 4'b1 << ram_addr[1:0]` whenever `ram_addr[27:25] == 3'b111` -- is the next thing to fix on its own merits. Do not re-derive the truncation or re-run the flash path; both are measured and the runtime print is in the tree. The width fix must be treated as unverified on hardware: it changes what `sdram_gba` receives for every backup type, and the next build for the board needs an explicit check that `backup type=  3` reaches the controller as 3 rather than 1, because a flash-type cartridge is the configuration most likely to move under it. The array-versus-controller inversion should be settled before any future cycle relies on the array as a reference, since every pre-BRD-105 simulation result in this log that used it assumed it booted. And the four false readings this cycle produced -- a stale binary, a premature grep, a flooding trace, and an inherited assumption that the array worked -- are the same class the log already records three times; the standing rule that a trace must be shown to fire on a known-good event before its silence or its noise means anything is what would have caught all four.

#### Files Modified:

- .gitignore
- fpga/gba/diag/gba_sdram_rtl.v
- fpga/gba/diag/sdram_model.v
- fpga/gba/src/gbatang_top.sv
- fpga/gba/src/memory/sdram_gba.v

#### Status:

- Build: PASS
- Deployment: N/A
- User Test: N/A

---
## 97 COMMIT Unreleased 2026-11-16T09:43:51-07:00

#### Coming From:

Unreleased 181bf2f

#### Purpose:

Find why a CPU store to the cartridge SRAM window is still lost after the `config_backup_type` width fix, and establish whether that fix is safe on the board, by repairing the simulation instrument before trusting it again.

#### Outcome:

The store was never lost in the way the previous cycle concluded, because the instrument that said so was corrupting its own evidence. `fpga/gba/diag/sdram_model.v` decides whether a die drives the shared 16-bit `SDRAM_DQ` bus with a priority list that tests a pending read before the write branch, so a die still holding read data keeps driving while the other die is written; the wrapper puts die0 on `SDRAM_nCS` and die1 on `~SDRAM_nCS` on that one bus, and cart RAM is on die1. A temporary `BUSOBS` print reporting the pin, the controller's own `dq_out`, and both dies' `dq_oen` at the same instant settled it on the probe's first store: the controller drove `0808` correctly, die0 was driving stale read data `e156`, and the pin read `e95e`, which is `0x0808 | 0xe156` exactly; all 1024 corrupted writes in the run were explained by that wired-OR and none needed another cause (BRD-106). Gating the model's drive on a chip select latched at command time -- not a combinational gate, which suppresses reads because the controller drops `nCS` before the read data appears, a wrong turn that cost one build -- makes the probe's verification square green `(0,252,0)` while square 0 stays red for the correct reason that the simulation plants no save. The controller is therefore exonerated: the request forms as `wr=1, addr=810000, be=0001`, `din_latch[0]` and `dq_out` both hold the CPU's own byte, and `dq_oen` is driving, so BRD-104's open question about whether a Write command reaches the pins was an artefact of the trace rather than a fact about the machine. Two further instrument faults were found and are recorded: the wrapper traced and dumped die0 only while cart RAM lives on die1, which is why one run printed 4096 `sdram: WR` lines -- all the loader's fill -- where the same code tracing die1 printed 266240 (TCL-082), and the dump fires at a fixed early cycle that samples the loader's cartridge-ROM fill. My own readings were wrong three more times in the same class: a `DCAS` print filtered by address hid other commands, `08080808` was treated as probe-unique when the loader writes it too, and results from two differently configured builds were compared against each other, which is the error entry 96 named and this cycle repeated. All diagnostics used the entry-73 restore-trap pattern and the tree was confirmed byte-identical to `HEAD` after every one. On the board the width fix is exonerated and a larger problem surfaced: four bitstreams were loaded in one session with the same commands and the same probe, and `build/prod3` and `build/sdiag3`, both recorded as seed 3, render the probe's green-then-red squares -- reproducing BRD-103 and proving board, capture and probe sound -- while `build/wrfix_board` at the default seed 1 and `build/nowfix`, which is `HEAD` with only the width declaration removed, both render a uniform black field inside the `(43,43,43)` pillarbox and never boot the BIOS, with every build gate passing and `hold 0` (BRD-107). So the width fix is not what breaks the board, since removing it changes nothing, and the default seed is now the leading suspect without being established, because no seed-1 image from the same commit as a working seed-3 image has been tested. Nothing on the machine is fixed by this cycle: the store is still lost on hardware, the probe's square 1 is still red on images that boot, and the root cause is still open. What the cycle bought is an instrument that stops inventing evidence. No RTL was changed and no source was left modified. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 97 was validated as the ninety-seventh entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 97 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 189 records with 189 unique ids, no duplicates, every record in canonical field order, and every status inside the three-value vocabulary, being 174 `VERIFIED`, 8 `MEASURED` and 7 `LEAD`.

#### Next Steps:

Settle the seed question before any further hardware claim, because every black-screen reading in this project is now unattributable until a matched pair exists: build the current tree at seed 3, load it with the same probe, and compare it against the seed-1 image already captured, which costs one placement and one capture and decides whether the default seed is unsafe or the two black images share some other cause. Then fix the harness properly rather than by patch, since it will be used again for exactly this question: give die1 the same `TRACE` parameter die0 has, gate each die's bus drive on a chip select latched at command time, and make the memory dump cover both dice at a time chosen relative to the event being measured instead of a fixed early cycle. With that in place the outstanding hardware question is answerable and is unchanged from BRD-101: on an image that boots, the probe's square 1 is red, so the CPU's store to `0x0E000000` still does not verify, and it is now known not to be a pin-trace artefact, not the flash gate, not `isreadonly()`, and not the controller's data path for a single byte. The full chain entry 92 named stays untested behind it. Two files remain untracked from the previous session, `tools/roms/saveprobe_iw.s` and `tools/save/pipe_save_dump.py`, still unvalidated and not committed here. Do not quote a timing or placement result without naming its seed, and do not deploy a default-seed image without capturing what it draws.

#### Files Modified:

None.

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 98 COMMIT Unreleased 2026-11-16T11:07:31-07:00

#### Coming From:

Unreleased 6d14c9b

#### Purpose:

Find why three bitstreams drew a black screen, and in doing so settle whether the cartridge SRAM store still fails after the `config_backup_type` width fix.

#### Outcome:

The black screens were the free BIOS, and the store works. `tools/build_tinygba.sh` assembled its synthesis defines from `TINYGBA_DEFINES` alone and never set `TINYGBA_BIOS_HEX`, so `gba_memory.sv` took its `ifdef` fallback and loaded the vendored Cult-of-GBA image, which does not boot a retail cartridge. Nothing failed and nothing warned: the build compiled, all nine gates passed, the bitstream packed and loaded, and the board drew a uniform black field inside its `(43,43,43)` pillarbox. Every image that had ever booted supplied the define by hand, and the synthesis logs still show it -- `build/prod3/synth.log` and `build/sdiag3/synth.log` each contain one `-DTINYGBA_BIOS_HEX="build/test/official_bios.hex"`, while `build/wrfix_board/synth.log` and `build/nowfix/synth.log` contain none. Rather than infer, the BIOS inside each netlist was read out of the `INIT_RAM_*` parameters of the eight `DPB` cells named `mem_bios`: `prod3` and `sdiag3` share signature `a599090b2107db6d`, `wrfix_board` and `nowfix` share `5953aaf13e0e7692`, and a third synthesis passing the retail image explicitly reproduces `a599090b2107db6d` exactly (BRD-108). That refutes BRD-107's seed hypothesis outright and, with it, entry 97's claim that the store still fails on images that boot -- both booting images predated the fix, so no board image had ever carried it. Three mechanisms now make the fault impossible to repeat: `gba_memory.sv` has no fallback and fails elaboration on a `$readmemh` of a file named `gba_bios_DELETED_pass_TINYGBA_BIOS_HEX.hex`, `tools/build_tinygba.sh` resolves the retail image itself and exits 2 when it is absent, `tools/sim/build_gba_sim.sh` lost its `TINYGBA_SIM_BIOS=cultofgba` opt-out, and the free image and its git entry are deleted (TCL-083). A `$fatal` and a `` `error `` were both tried first and rejected: the project's slang build refuses `$fatal` in an initial block and does not recognise `` `error `` at all, which is why the failure is a missing-file read rather than a directive. With the mechanism in place, `build/head_retail_s1` was built at the default placement seed 1, `.bin` sha256 `83afd2c9ee0a77e106f7ea8eb754dbf46e8ac783ed694279d9935544d1840bf4`, every gate passing with `hold 0`, and its netlist confirmed to carry the retail BIOS signature before it was loaded. On the board, with a 32768-byte file of ZEROS planted as the save so that square 0 could not be satisfied by stale contents, `saveprobe` painted square 0 RED `(226,0,0)` and square 1 GREEN `(18,255,0)`: the CPU wrote its own pattern through `0x0E000000` and read all 32768 bytes back matching. Against BRD-103, which measured square 1 RED on `build/sdiag3` -- retail BIOS, same probe, `config_backup_type` still one bit -- this is a matched hardware A/B whose only functional difference is the width declaration, so the dropped store is closed and BRD-105's mechanism is confirmed on hardware (BRD-109). A later read of the window over `fpgapipe` returned the canonical pattern, which is the expected final state because the probe restores canonical as its last action, and that measurement incidentally validates `tools/save/pipe_save_dump.py`, which is committed here as the first of the two files left untracked from the previous session. Four of my own errors are recorded because each produced a wrong reading first: I captured the board fourteen seconds into an eighty-eight-second load and read the resulting black as a build fault; I tested `nowfix` without a cartridge and compared it against `prod3` with one, when `prod3` without a cartridge is black too; I read a LUT4 `INIT` parameter as though it were the BIOS block RAM and drew a conclusion from it before finding the `INIT_RAM_*` fields; and I reported a `$fatal` guard as working when the toolchain had rejected it. No RTL logic was changed: the only source change is the BIOS selection, which alters a block-RAM image and no logic. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 98 was validated as the ninety-eighth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 98 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 192 records with 192 unique ids, no duplicates, every record in canonical field order, and every status inside the three-value vocabulary, being 177 `VERIFIED`, 8 `MEASURED` and 7 `LEAD`.

#### Next Steps:

The store works, so the chain entry 92 named is finally testable and is the next thing to run, in this order: have the probe write, `gbasave` the window, power cycle, `gbaload` with the `.sav`, and have the probe report the pattern came back, with the genuine negative control that SRAM in SDRAM now allows -- a power cycle without the restore should leave square 0 red where it was green. Then re-take the save measurements this defect invalidated rather than merely doubted: BRD-092's four-type round trip and BRD-094's EEPROM power-cycle result were both taken through a `config_backup_type` that reached `rv_sdram_adapter` as one bit, where `is_eeprom = config_backup_type == 4` could never be true, so neither is evidence about the EEPROM store and both need re-running on a post-fix image. `tools/roms/savewprobe.s` is still marked NOT VALIDATED and should either be finished or dropped, and `tools/roms/saveprobe_iw.s` remains untracked and unvalidated, deliberately not committed here. Two seed questions are now open but not urgent: seed 1 is shown to boot with the retail BIOS, and seed 3 failed the clock-plane gate on the current tree, so the seed-sensitivity story from earlier cycles should be treated as unmeasured rather than settled. The log is at 98 of 100 entries, so the rollover is the next cycle's housekeeping whatever it contains. Do not build without a BIOS image present, and do not treat a black screen as a placement fault until the bitstream's BIOS signature has been read.

#### Files Modified:

- fpga/gba/src/memory/gba_memory.sv
- fpga/gba/src/memory/gba_bios_cultofgba.hex
- tools/build_tinygba.sh
- tools/sim/build_gba_sim.sh
- tools/save/pipe_save_dump.py
- README.md

#### Status:

- Build: PASS
- Deployment: PASS
- User Test: NOT RUN

---
## 99 COMMIT Unreleased 2026-11-16T11:36:42-07:00

#### Coming From:

Unreleased 919a466

#### Purpose:

Run the persistence chain that the closed store defect made testable -- probe write, `gbasave`, real power cycle, `gbaload`, probe re-read -- with a negative control, and delete the second unreferenced BIOS image.

#### Outcome:

A cartridge save round-trips across a real power cycle, and that closes the last open question in the save path. The power cut was made by `~/Desktop/reboot_in 2_wire.py`, which drives a relay sequence over LXMF -- every contact open, one second, VBUS alone for ten seconds so the board boots with the data pair still open, then all four -- and the node acknowledged all three steps, so this was a genuine loss of power and not an in-system reset; that matters because SRAM lives in SDRAM and only a real cut clears it. Four steps, each captured. With 32768 bytes of ZEROS planted, `saveprobe` drew square 0 RED `(226,0,0)` and square 1 GREEN `(18,255,0)`, meaning canonical was absent at start and the CPU's own write verified. A host read of the live window over `fpgapipe` then returned 32768 bytes matching the canonical pattern, sha256 `611253a4...`, which is the first measurement that shows the CPU's 32 KiB write actually sitting in SDRAM rather than merely being acknowledged. `gbasave` wrote that window to the card, the board was power-cycled, `tangload` and `gbaload` restored the file, and the probe drew BOTH squares GREEN: a pattern the CPU had written before the cut came back after it. The negative control is what makes that mean anything -- zeros planted again, a second power cycle, zeros restored, and the probe returned to the baseline of square 0 RED and square 1 GREEN, so the green square 0 was attributable to the restored file and not to SDRAM surviving the cut. Square 1 was green in all three runs, so the write path was working throughout and the only variable was what was planted or restored (BRD-110). This also answers BRD-094's question by a route BRD-094 did not expect: rather than waiting for the EEPROM to decay into a blank store, SRAM in SDRAM gives a reliable blank after a power cut, and so a genuine negative control exists and was used. Two limits are recorded with the result. This is an SRAM cartridge only -- the EEPROM, flash512K and flash1M paths are untested in this chain, and BRD-092's four-type round trip and BRD-094's EEPROM power-cycle result were both measured while `config_backup_type` reached `rv_sdram_adapter` as one bit, where `is_eeprom = config_backup_type == 4` could never be true, so neither is evidence about those stores. And this is a probe writing through the cartridge window, not a retail title saving its own game. Separately, `fpga/gba/src/memory/gba_bios_normmatt.hex` was deleted: a 40,960-byte hex image with no reference in any source, script, constraint or document, so it could never be loaded and was dead weight of the same kind as the free BIOS. No RTL logic was changed and no bitstream was rebuilt for this cycle, because the image under test was already the post-fix one. Three of my own errors are worth recording for the next session: I captured the board once before a load had finished and read the black as a build fault; I compared a build tested without a cartridge against one tested with it, when the no-cartridge state is black for both; and I nearly recorded a `$fatal` BIOS guard as working when the toolchain had rejected it. The core-syntax audit was run: `.ai/core.md` and `.ai/core-syntax.md` were re-read, `.ai/core.md` was confirmed unchanged at md5 `1145a377cae5b553567ab6946ed78c01`, the complete `.ai/` diff was inspected, entry 99 was validated as the ninety-ninth entry with six canonical sections in order, a one-sentence Purpose, prose in Outcome and Next Steps, an allowed Status triple and a trailing `---`, the active log was confirmed at 99 entries against the 100-entry limit with no gaps in its numbering, and the reference store was confirmed at 193 records with 193 unique ids, no duplicates, every record in canonical field order, and every status inside the three-value vocabulary, being 178 `VERIFIED`, 8 `MEASURED` and 7 `LEAD`.

#### Next Steps:

The next entry is number 100, so the rollover is due and should be done deliberately rather than as a side effect: archive the active log into `archived_logs` with the current timestamp, clear it, and open it with a handoff entry numbered 1 that names the archive and summarises the live state. Before or after that, the work that now matters is the save types this chain did not touch. Re-run BRD-092's four-type round trip and BRD-094's EEPROM power-cycle measurement on a post-fix image, because both were taken through a one-bit `config_backup_type` where the EEPROM decode could never be true and so neither says anything about the EEPROM store; the same relay sequence now makes that test cheap, since it supplies the real power cut those records need. Then an in-game save in a retail title, which is the one thing that would show a cartridge using this path rather than a probe: an SRAM title such as Metroid Fusion and, once the EEPROM and flash paths are re-measured, Emerald, whose flash1M configuration reached the controller as `BACKUP_NONE` before the width fix and is the case most likely to move. `tools/roms/savewprobe.s` is still marked NOT VALIDATED and `tools/roms/saveprobe_iw.s` is still untracked; both should be finished or dropped rather than carried. Do not treat the SRAM result as covering the other save types, and do not describe BRD-092 or BRD-094 as established until they are re-taken.

#### Files Modified:

- fpga/gba/src/memory/gba_bios_normmatt.hex

#### Status:

- Build: N/A
- Deployment: PASS
- User Test: NOT RUN

---
